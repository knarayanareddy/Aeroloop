// AeroLoop Mock Data — Comprehensive simulation of the full optimisation system
// Based on AeroLoop Specification Bundle v1.0

// ═══════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════

export type RunStatus = 'RUNNING' | 'PAUSED' | 'COMPLETED' | 'LOOP_HALT';
export type ExperimentStatus = 'KEPT' | 'REVERTED' | 'SOLVE_TIMEOUT' | 'MESH_FAIL' | 'SOLVE_FAIL' | 'BOUNDS_FAIL' | 'EXTRACTION_FAIL';
export type StageID = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
export type NodeStatus = 'ACTIVE' | 'OFFLINE' | 'PAUSED';
export type HealthStatus = 'ok' | 'degraded' | 'down';

export interface RunConfig {
  run_id: string;
  label: string;
  status: RunStatus;
  mach: number;
  reynolds: number;
  alpha: number;
  w_ld: number;
  w_buffet: number;
  w_wave: number;
  kill_timer_s: number;
  created_at: string;
  swarm_enabled: boolean;
}

export interface RunMetrics {
  best_M: number;
  best_M_exp_n: number;
  total_experiments: number;
  kept_count: number;
  reverted_count: number;
  timeout_count: number;
  mesh_fail_count: number;
  solve_fail_count: number;
  bounds_fail_count: number;
  extraction_fail_count: number;
  consecutive_fails: number;
  rate_per_hour: number;
  gep_generation: number;
  gep_next_at: number;
}

export interface InfrastructureHealth {
  postgresql: HealthStatus;
  redis: HealthStatus;
  s3: HealthStatus;
  postgresql_latency_ms: number;
  redis_latency_ms: number;
  s3_latency_ms: number;
  s3_bucket_gb: number;
  s3_bucket_free_gb: number;
  postgres_size_gb: number;
}

export interface GeometryParameter {
  id: string;
  region: string;
  name: string;
  description: string;
  unit: string;
  min: number;
  max: number;
  default: number;
  current: number;
  sensitivity: number;
  dead_zone: boolean;
  hot_zone: boolean;
  sample_count: number;
}

export interface Experiment {
  experiment_n: number;
  run_id: string;
  node_id: string;
  status: ExperimentStatus;
  stage_reached: StageID;
  parameter_id: string;
  parameter_name: string;
  old_value: number;
  new_value: number;
  metric_M: number | null;
  best_M_at_time: number;
  CL: number | null;
  CD: number | null;
  CMy: number | null;
  LD_ratio: number | null;
  cd_wave: number | null;
  buffet_onset_alpha: number | null;
  mesh_cell_count: number | null;
  mesh_quality_score: number | null;
  solve_wall_time_s: number | null;
  residual_orders: number | null;
  geometry_sha256_before: string;
  geometry_sha256_after: string;
  mesh_sha256: string;
  results_sha256: string;
  strategy: string;
  genome_generation: number;
  timestamp: string;
  duration_s: number;
}

export interface KnowledgeGraphEntry {
  parameter_id: string;
  parameter_name: string;
  sensitivity_score: number;
  sensitivity_rank: number;
  mean_delta_M: number;
  std_delta_M: number;
  sample_count: number;
  dead_zone: boolean;
  hot_zone: boolean;
  optimal_direction: 'increase' | 'decrease' | 'neutral';
}

export interface ParameterInteraction {
  param_a: string;
  param_b: string;
  interaction_strength: number;
  synergy: boolean;
}

export interface GEPGenome {
  id: string;
  fitness: number;
  strategy: string;
  step_size_multiplier: number;
  topology_probability: number;
  exploration_rate: number;
  crossover_rate: number;
  mutation_rate: number;
  elite_count: number;
  generation: number;
  is_active: boolean;
}

export interface GEPEvolution {
  generation: number;
  best_fitness: number;
  mean_fitness: number;
  diversity: number;
  triggered_at_exp: number;
  timestamp: string;
  active_strategy: string;
}

export interface SwarmNode {
  node_id: string;
  status: NodeStatus;
  region: string;
  experiments_completed: number;
  last_heartbeat: string;
  current_stage: StageID;
  current_experiment: number;
  best_M_contribution: number;
  claimed_at: string;
  claim_ttl_s: number;
}

export interface WikiArticle {
  id: string;
  type: 'sensitivity' | 'batch_summary' | 'interaction';
  title: string;
  experiment_range: string;
  created_at: string;
  content_summary: string;
}

export interface DecisionLogEntry {
  timestamp: string;
  experiment_n: number;
  decision: 'KEEP' | 'REVERT';
  reason: string;
  metric_M: number;
  best_M: number;
  delta_M: number;
  parameter_id: string;
  strategy: string;
}

export interface EventLogEntry {
  timestamp: string;
  event_type: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  message: string;
  source: string;
  details?: Record<string, unknown>;
}

export interface PipelineStage {
  id: StageID;
  name: string;
  description: string;
  agent: string;
  status: 'completed' | 'active' | 'pending' | 'failed' | 'skipped';
  duration_ms: number;
  timestamp: string;
}

// ═══════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

function sha256mock(seed: string): string {
  let hash = '';
  const chars = '0123456789abcdef';
  let h = 0;
  for (let i = 0; i < seed.length; i++) {
    h = ((h << 5) - h + seed.charCodeAt(i)) | 0;
  }
  for (let i = 0; i < 64; i++) {
    h = ((h << 5) - h + i * 31 + h) | 0;
    hash += chars[Math.abs(h) % 16];
  }
  return hash;
}

function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 16807 + 0) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

// ═══════════════════════════════════════════════════════════════
// MOCK DATA GENERATION
// ═══════════════════════════════════════════════════════════════

const rng = seededRandom(42);

// --- Run Configuration ---
export const runConfig: RunConfig = {
  run_id: 'run-a7f3c9e2',
  label: 'naca0012-sweep-001',
  status: 'RUNNING',
  mach: 0.78,
  reynolds: 4.5e7,
  alpha: 2.5,
  w_ld: 0.5,
  w_buffet: 0.3,
  w_wave: 0.2,
  kill_timer_s: 480,
  created_at: '2025-01-20T08:00:00Z',
  swarm_enabled: true,
};

// --- Geometry Parameters (from GLOBAL-GEOM-001) ---
export const geometryParameters: GeometryParameter[] = [
  { id: 'root_chord', region: 'PLANFORM_CORE', name: 'Root Chord', description: 'Chord length at wing root', unit: 'm', min: 1.0, max: 3.0, default: 2.0, current: 1.947, sensitivity: 0.82, dead_zone: false, hot_zone: true, sample_count: 47 },
  { id: 'tip_chord', region: 'PLANFORM_CORE', name: 'Tip Chord', description: 'Chord length at wing tip', unit: 'm', min: 0.3, max: 1.5, default: 0.8, current: 0.756, sensitivity: 0.65, dead_zone: false, hot_zone: false, sample_count: 42 },
  { id: 'semi_span', region: 'PLANFORM_CORE', name: 'Semi Span', description: 'Wing semi-span length', unit: 'm', min: 5.0, max: 15.0, default: 10.0, current: 10.234, sensitivity: 0.41, dead_zone: false, hot_zone: false, sample_count: 31 },
  { id: 'sweep_angle', region: 'PLANFORM_CORE', name: 'Sweep Angle', description: 'Leading-edge sweep angle', unit: 'deg', min: 15.0, max: 45.0, default: 25.0, current: 27.8, sensitivity: 0.73, dead_zone: false, hot_zone: true, sample_count: 51 },
  { id: 'taper_ratio', region: 'PLANFORM_CORE', name: 'Taper Ratio', description: 'Tip-to-root chord ratio', unit: '', min: 0.2, max: 0.8, default: 0.4, current: 0.388, sensitivity: 0.58, dead_zone: false, hot_zone: false, sample_count: 38 },
  { id: 'thickness_root', region: 'THICKNESS', name: 'Root Thickness', description: 't/c ratio at root section', unit: '', min: 0.08, max: 0.20, default: 0.12, current: 0.114, sensitivity: 0.91, dead_zone: false, hot_zone: true, sample_count: 55 },
  { id: 'thickness_tip', region: 'THICKNESS', name: 'Tip Thickness', description: 't/c ratio at tip section', unit: '', min: 0.06, max: 0.16, default: 0.10, current: 0.093, sensitivity: 0.69, dead_zone: false, hot_zone: false, sample_count: 43 },
  { id: 'camber_root', region: 'CAMBER', name: 'Root Camber', description: 'Max camber at root section', unit: '', min: -0.02, max: 0.05, default: 0.02, current: 0.023, sensitivity: 0.77, dead_zone: false, hot_zone: true, sample_count: 48 },
  { id: 'camber_tip', region: 'CAMBER', name: 'Tip Camber', description: 'Max camber at tip section', unit: '', min: -0.02, max: 0.05, default: 0.01, current: 0.012, sensitivity: 0.44, dead_zone: false, hot_zone: false, sample_count: 29 },
  { id: 'camber_pos_root', region: 'CAMBER', name: 'Root Camber Position', description: 'Camber peak position at root', unit: '', min: 0.2, max: 0.6, default: 0.4, current: 0.42, sensitivity: 0.33, dead_zone: true, hot_zone: false, sample_count: 18 },
  { id: 'camber_pos_tip', region: 'CAMBER', name: 'Tip Camber Position', description: 'Camber peak position at tip', unit: '', min: 0.2, max: 0.6, default: 0.4, current: 0.39, sensitivity: 0.28, dead_zone: true, hot_zone: false, sample_count: 15 },
  { id: 'twist_root', region: 'TWIST', name: 'Root Twist', description: 'Twist angle at root', unit: 'deg', min: -5.0, max: 5.0, default: 0.0, current: -0.3, sensitivity: 0.22, dead_zone: true, hot_zone: false, sample_count: 12 },
  { id: 'twist_tip', region: 'TWIST', name: 'Tip Twist', description: 'Twist angle at tip', unit: 'deg', min: -10.0, max: 0.0, default: -3.0, current: -3.8, sensitivity: 0.56, dead_zone: false, hot_zone: false, sample_count: 35 },
  { id: 'washout', region: 'TWIST', name: 'Washout', description: 'Geometric washout angle', unit: 'deg', min: 0.0, max: 8.0, default: 3.0, current: 3.5, sensitivity: 0.62, dead_zone: false, hot_zone: false, sample_count: 40 },
  { id: 'flap_deflection', region: 'CONTROL', name: 'Flap Deflection', description: 'Trailing-edge flap angle', unit: 'deg', min: -10.0, max: 10.0, default: 0.0, current: 0.0, sensitivity: 0.15, dead_zone: true, hot_zone: false, sample_count: 5 },
  { id: 'aileron_deflection', region: 'CONTROL', name: 'Aileron Deflection', description: 'Aileron deflection angle', unit: 'deg', min: -5.0, max: 5.0, default: 0.0, current: 0.0, sensitivity: 0.08, dead_zone: true, hot_zone: false, sample_count: 3 },
];

// --- Generate 200 Experiments ---
function generateExperiments(count: number): Experiment[] {
  const experiments: Experiment[] = [];
  const paramIds = geometryParameters.map(p => p.id);
  const paramNames = Object.fromEntries(geometryParameters.map(p => [p.id, p.name]));
  const strategies = ['gradient', 'random', 'genome_directed', 'sensitivity_weighted', 'bayesian'];
  
  let bestM = 0.6543; // baseline M from exp-0
  const nodeIds = ['node-alpha', 'node-beta', 'node-gamma', 'node-delta'];
  
  const baseTime = new Date('2025-01-20T08:05:00Z').getTime();
  const avgDurationMs = 8 * 60 * 1000; // ~8 min per experiment

  // Exp 0 = baseline
  experiments.push({
    experiment_n: 0,
    run_id: runConfig.run_id,
    node_id: 'node-alpha',
    status: 'KEPT',
    stage_reached: 5,
    parameter_id: 'baseline',
    parameter_name: 'Baseline',
    old_value: 0,
    new_value: 0,
    metric_M: bestM,
    best_M_at_time: bestM,
    CL: 0.5234,
    CD: 0.02876,
    CMy: -0.0234,
    LD_ratio: 18.20,
    cd_wave: 0.00312,
    buffet_onset_alpha: 4.2,
    mesh_cell_count: 184320,
    mesh_quality_score: 0.92,
    solve_wall_time_s: 342.5,
    residual_orders: 6.2,
    geometry_sha256_before: sha256mock('baseline-before'),
    geometry_sha256_after: sha256mock('baseline-after'),
    mesh_sha256: sha256mock('mesh-0'),
    results_sha256: sha256mock('results-0'),
    strategy: 'baseline',
    genome_generation: 0,
    timestamp: new Date(baseTime).toISOString(),
    duration_s: 412,
  });

  for (let i = 1; i < count; i++) {
    const paramIdx = Math.floor(rng() * paramIds.length);
    const paramId = paramIds[paramIdx];
    const param = geometryParameters.find(p => p.id === paramId)!;
    const nodeId = nodeIds[Math.floor(rng() * nodeIds.length)];
    const strategy = strategies[Math.floor(rng() * strategies.length)];
    const gen = Math.floor(i / 500);

    // Determine status with realistic distribution
    const statusRoll = rng();
    let status: ExperimentStatus;
    let stageReached: StageID;
    
    if (statusRoll < 0.28) {
      status = 'KEPT';
      stageReached = 5;
    } else if (statusRoll < 0.72) {
      status = 'REVERTED';
      stageReached = 5;
    } else if (statusRoll < 0.82) {
      status = 'SOLVE_TIMEOUT';
      stageReached = 3;
    } else if (statusRoll < 0.88) {
      status = 'MESH_FAIL';
      stageReached = 2;
    } else if (statusRoll < 0.93) {
      status = 'SOLVE_FAIL';
      stageReached = 3;
    } else if (statusRoll < 0.97) {
      status = 'BOUNDS_FAIL';
      stageReached = 1;
    } else {
      status = 'EXTRACTION_FAIL';
      stageReached = 4;
    }

    // Compute metric
    let metricM: number | null = null;
    let CL: number | null = null;
    let CD: number | null = null;
    let CMy: number | null = null;
    let LD: number | null = null;
    let cdWave: number | null = null;
    let buffetAlpha: number | null = null;
    let meshCells: number | null = null;
    let meshQuality: number | null = null;
    let solveTime: number | null = null;
    let residualOrders: number | null = null;

    if (stageReached >= 2) {
      meshCells = Math.floor(160000 + rng() * 80000);
      meshQuality = 0.75 + rng() * 0.2;
    }

    if (stageReached >= 3 && status !== 'SOLVE_TIMEOUT') {
      solveTime = 200 + rng() * 350;
      residualOrders = 4.0 + rng() * 3.0;
    } else if (status === 'SOLVE_TIMEOUT') {
      solveTime = 480;
      residualOrders = 1.5 + rng() * 2.0;
    }

    if (stageReached >= 4) {
      CL = 0.45 + rng() * 0.20;
      CD = 0.020 + rng() * 0.015;
      CMy = -0.05 + rng() * 0.04;
      LD = CL / CD;
      cdWave = 0.001 + rng() * 0.005;
      buffetAlpha = 3.5 + rng() * 2.5;

      // Composite metric: M = w_ld * (LD/30) + w_buffet * (buffet/8) - w_wave * (cd_wave/0.01)
      // Normalized
      const w_ld = 0.5, w_buffet = 0.3, w_wave = 0.2;
      metricM = w_ld * (LD / 30) + w_buffet * (buffetAlpha / 8) - w_wave * (cdWave / 0.01);
      metricM = Math.max(0, Math.min(1, metricM));
    }

    // For KEPT, make metric slightly better than current best on average
    if (status === 'KEPT' && metricM !== null) {
      const improvement = 0.001 + rng() * 0.008;
      metricM = bestM + improvement;
      // Recalculate aerodynamic coefficients to be consistent
      LD = 18 + (metricM - 0.65) * 40;
      CL = LD * (0.022 + rng() * 0.008);
      CD = CL / LD;
      cdWave = 0.005 - (metricM - 0.65) * 0.008;
      buffetAlpha = 4.0 + (metricM - 0.65) * 10;
      bestM = metricM;
    }

    const oldValue = param.current;
    const delta = (rng() - 0.5) * (param.max - param.min) * 0.1;
    let newValue = oldValue + delta;
    newValue = Math.max(param.min, Math.min(param.max, newValue));

    const ts = new Date(baseTime + i * avgDurationMs + Math.floor(rng() * 60000));
    
    experiments.push({
      experiment_n: i,
      run_id: runConfig.run_id,
      node_id: nodeId,
      status,
      stage_reached: stageReached,
      parameter_id: paramId,
      parameter_name: paramNames[paramId],
      old_value: Number(oldValue.toFixed(4)),
      new_value: Number(newValue.toFixed(4)),
      metric_M: metricM !== null ? Number(metricM.toFixed(4)) : null,
      best_M_at_time: Number(bestM.toFixed(4)),
      CL: CL !== null ? Number(CL.toFixed(4)) : null,
      CD: CD !== null ? Number(CD.toFixed(5)) : null,
      CMy: CMy !== null ? Number(CMy.toFixed(4)) : null,
      LD_ratio: LD !== null ? Number(LD.toFixed(2)) : null,
      cd_wave: cdWave !== null ? Number(cdWave.toFixed(5)) : null,
      buffet_onset_alpha: buffetAlpha !== null ? Number(buffetAlpha.toFixed(1)) : null,
      mesh_cell_count: meshCells,
      mesh_quality_score: meshQuality !== null ? Number(meshQuality.toFixed(2)) : null,
      solve_wall_time_s: solveTime !== null ? Number(solveTime.toFixed(1)) : null,
      residual_orders: residualOrders !== null ? Number(residualOrders.toFixed(1)) : null,
      geometry_sha256_before: sha256mock(`geo-before-${i}`),
      geometry_sha256_after: sha256mock(`geo-after-${i}`),
      mesh_sha256: sha256mock(`mesh-${i}`),
      results_sha256: sha256mock(`results-${i}`),
      strategy,
      genome_generation: gen,
      timestamp: ts.toISOString(),
      duration_s: stageReached >= 3 ? Math.floor(300 + rng() * 300) : Math.floor(30 + rng() * 120),
    });
  }

  return experiments;
}

export const experiments = generateExperiments(200);

// --- Run Metrics (computed from experiments) ---
const kept = experiments.filter(e => e.status === 'KEPT').length;
const reverted = experiments.filter(e => e.status === 'REVERTED').length;
const timeouts = experiments.filter(e => e.status === 'SOLVE_TIMEOUT').length;
const meshFails = experiments.filter(e => e.status === 'MESH_FAIL').length;
const solveFails = experiments.filter(e => e.status === 'SOLVE_FAIL').length;
const boundsFails = experiments.filter(e => e.status === 'BOUNDS_FAIL').length;
const extractionFails = experiments.filter(e => e.status === 'EXTRACTION_FAIL').length;

// Find consecutive fails at the end
let consecFails = 0;
for (let i = experiments.length - 1; i >= 0; i--) {
  if (experiments[i].status !== 'KEPT') consecFails++;
  else break;
}

const bestExperiment = experiments.reduce((best, e) => 
  e.metric_M !== null && (best.metric_M === null || e.metric_M > best.metric_M!) ? e : best, experiments[0]);

export const runMetrics: RunMetrics = {
  best_M: bestExperiment.metric_M ?? 0.6543,
  best_M_exp_n: bestExperiment.experiment_n,
  total_experiments: experiments.length,
  kept_count: kept,
  reverted_count: reverted,
  timeout_count: timeouts,
  mesh_fail_count: meshFails,
  solve_fail_count: solveFails,
  bounds_fail_count: boundsFails,
  extraction_fail_count: extractionFails,
  consecutive_fails: consecFails,
  rate_per_hour: 7.8,
  gep_generation: 0,
  gep_next_at: 500,
};

// --- Infrastructure Health ---
export const infraHealth: InfrastructureHealth = {
  postgresql: 'ok',
  redis: 'ok',
  s3: 'ok',
  postgresql_latency_ms: 3.2,
  redis_latency_ms: 0.8,
  s3_latency_ms: 12.4,
  s3_bucket_gb: 38.2,
  s3_bucket_free_gb: 61.8,
  postgres_size_gb: 1.4,
};

// --- Knowledge Graph ---
export const knowledgeGraph: KnowledgeGraphEntry[] = [
  { parameter_id: 'thickness_root', parameter_name: 'Root Thickness', sensitivity_score: 0.91, sensitivity_rank: 1, mean_delta_M: 0.0045, std_delta_M: 0.0031, sample_count: 55, dead_zone: false, hot_zone: true, optimal_direction: 'decrease' },
  { parameter_id: 'root_chord', parameter_name: 'Root Chord', sensitivity_score: 0.82, sensitivity_rank: 2, mean_delta_M: 0.0038, std_delta_M: 0.0029, sample_count: 47, dead_zone: false, hot_zone: true, optimal_direction: 'decrease' },
  { parameter_id: 'sweep_angle', parameter_name: 'Sweep Angle', sensitivity_score: 0.73, sensitivity_rank: 3, mean_delta_M: 0.0032, std_delta_M: 0.0025, sample_count: 51, dead_zone: false, hot_zone: true, optimal_direction: 'increase' },
  { parameter_id: 'camber_root', parameter_name: 'Root Camber', sensitivity_score: 0.77, sensitivity_rank: 4, mean_delta_M: 0.0035, std_delta_M: 0.0028, sample_count: 48, dead_zone: false, hot_zone: true, optimal_direction: 'increase' },
  { parameter_id: 'thickness_tip', parameter_name: 'Tip Thickness', sensitivity_score: 0.69, sensitivity_rank: 5, mean_delta_M: 0.0028, std_delta_M: 0.0022, sample_count: 43, dead_zone: false, hot_zone: false, optimal_direction: 'decrease' },
  { parameter_id: 'tip_chord', parameter_name: 'Tip Chord', sensitivity_score: 0.65, sensitivity_rank: 6, mean_delta_M: 0.0025, std_delta_M: 0.0021, sample_count: 42, dead_zone: false, hot_zone: false, optimal_direction: 'decrease' },
  { parameter_id: 'washout', parameter_name: 'Washout', sensitivity_score: 0.62, sensitivity_rank: 7, mean_delta_M: 0.0023, std_delta_M: 0.0019, sample_count: 40, dead_zone: false, hot_zone: false, optimal_direction: 'increase' },
  { parameter_id: 'taper_ratio', parameter_name: 'Taper Ratio', sensitivity_score: 0.58, sensitivity_rank: 8, mean_delta_M: 0.0020, std_delta_M: 0.0018, sample_count: 38, dead_zone: false, hot_zone: false, optimal_direction: 'decrease' },
  { parameter_id: 'twist_tip', parameter_name: 'Tip Twist', sensitivity_score: 0.56, sensitivity_rank: 9, mean_delta_M: 0.0018, std_delta_M: 0.0017, sample_count: 35, dead_zone: false, hot_zone: false, optimal_direction: 'decrease' },
  { parameter_id: 'semi_span', parameter_name: 'Semi Span', sensitivity_score: 0.41, sensitivity_rank: 10, mean_delta_M: 0.0012, std_delta_M: 0.0014, sample_count: 31, dead_zone: false, hot_zone: false, optimal_direction: 'neutral' },
  { parameter_id: 'camber_tip', parameter_name: 'Tip Camber', sensitivity_score: 0.44, sensitivity_rank: 11, mean_delta_M: 0.0014, std_delta_M: 0.0015, sample_count: 29, dead_zone: false, hot_zone: false, optimal_direction: 'increase' },
  { parameter_id: 'camber_pos_root', parameter_name: 'Root Camber Position', sensitivity_score: 0.33, sensitivity_rank: 12, mean_delta_M: 0.0008, std_delta_M: 0.0012, sample_count: 18, dead_zone: true, hot_zone: false, optimal_direction: 'neutral' },
  { parameter_id: 'camber_pos_tip', parameter_name: 'Tip Camber Position', sensitivity_score: 0.28, sensitivity_rank: 13, mean_delta_M: 0.0006, std_delta_M: 0.0010, sample_count: 15, dead_zone: true, hot_zone: false, optimal_direction: 'neutral' },
  { parameter_id: 'twist_root', parameter_name: 'Root Twist', sensitivity_score: 0.22, sensitivity_rank: 14, mean_delta_M: 0.0004, std_delta_M: 0.0008, sample_count: 12, dead_zone: true, hot_zone: false, optimal_direction: 'neutral' },
  { parameter_id: 'flap_deflection', parameter_name: 'Flap Deflection', sensitivity_score: 0.15, sensitivity_rank: 15, mean_delta_M: 0.0002, std_delta_M: 0.0005, sample_count: 5, dead_zone: true, hot_zone: false, optimal_direction: 'neutral' },
  { parameter_id: 'aileron_deflection', parameter_name: 'Aileron Deflection', sensitivity_score: 0.08, sensitivity_rank: 16, mean_delta_M: 0.0001, std_delta_M: 0.0003, sample_count: 3, dead_zone: true, hot_zone: false, optimal_direction: 'neutral' },
];

export const parameterInteractions: ParameterInteraction[] = [
  { param_a: 'thickness_root', param_b: 'camber_root', interaction_strength: 0.72, synergy: true },
  { param_a: 'sweep_angle', param_b: 'thickness_tip', interaction_strength: 0.64, synergy: true },
  { param_a: 'root_chord', param_b: 'taper_ratio', interaction_strength: 0.58, synergy: false },
  { param_a: 'washout', param_b: 'twist_tip', interaction_strength: 0.81, synergy: true },
  { param_a: 'camber_root', param_b: 'camber_tip', interaction_strength: 0.53, synergy: true },
  { param_a: 'semi_span', param_b: 'sweep_angle', interaction_strength: 0.47, synergy: false },
  { param_a: 'thickness_root', param_b: 'root_chord', interaction_strength: 0.69, synergy: true },
  { param_a: 'tip_chord', param_b: 'thickness_tip', interaction_strength: 0.55, synergy: false },
  { param_a: 'taper_ratio', param_b: 'washout', interaction_strength: 0.41, synergy: true },
  { param_a: 'twist_tip', param_b: 'washout', interaction_strength: 0.76, synergy: true },
];

// --- GEP Genome ---
export const gepGenomes: GEPGenome[] = Array.from({ length: 16 }, (_, i) => ({
  id: `genome-gen0-${i.toString().padStart(2, '0')}`,
  fitness: Number((0.3 + rng() * 0.6).toFixed(4)),
  strategy: ['gradient', 'random', 'genome_directed', 'sensitivity_weighted', 'bayesian'][Math.floor(rng() * 5)],
  step_size_multiplier: Number((0.3 + rng() * 1.2).toFixed(2)),
  topology_probability: Number(rng() * 0.3).toFixed(2) as unknown as number,
  exploration_rate: Number((0.1 + rng() * 0.5).toFixed(2)),
  crossover_rate: Number((0.5 + rng() * 0.4).toFixed(2)),
  mutation_rate: Number((0.05 + rng() * 0.3).toFixed(2)),
  elite_count: i < 2 ? 2 : 0,
  generation: 0,
  is_active: i === 0,
}));

// Make the first genome the active one with best fitness
gepGenomes[0].fitness = 0.8745;
gepGenomes[0].strategy = 'sensitivity_weighted';
gepGenomes[0].step_size_multiplier = 0.65;
gepGenomes[0].exploration_rate = 0.35;
gepGenomes[0].is_active = true;

export const gepEvolutions: GEPEvolution[] = [
  { generation: 0, best_fitness: 0.8745, mean_fitness: 0.5823, diversity: 0.91, triggered_at_exp: 0, timestamp: '2025-01-20T08:00:00Z', active_strategy: 'sensitivity_weighted' },
];

// --- Swarm Nodes ---
export const swarmNodes: SwarmNode[] = [
  {
    node_id: 'node-alpha',
    status: 'ACTIVE',
    region: 'PLANFORM_CORE',
    experiments_completed: 58,
    last_heartbeat: '2025-01-20T21:47:12Z',
    current_stage: 3,
    current_experiment: 201,
    best_M_contribution: 0.8821,
    claimed_at: '2025-01-20T08:01:00Z',
    claim_ttl_s: 600,
  },
  {
    node_id: 'node-beta',
    status: 'ACTIVE',
    region: 'TWIST',
    experiments_completed: 49,
    last_heartbeat: '2025-01-20T21:47:08Z',
    current_stage: 1,
    current_experiment: 202,
    best_M_contribution: 0.8794,
    claimed_at: '2025-01-20T08:01:05Z',
    claim_ttl_s: 600,
  },
  {
    node_id: 'node-gamma',
    status: 'ACTIVE',
    region: 'THICKNESS',
    experiments_completed: 53,
    last_heartbeat: '2025-01-20T21:47:15Z',
    current_stage: 5,
    current_experiment: 200,
    best_M_contribution: 0.8812,
    claimed_at: '2025-01-20T08:01:10Z',
    claim_ttl_s: 600,
  },
  {
    node_id: 'node-delta',
    status: 'ACTIVE',
    region: 'CAMBER',
    experiments_completed: 40,
    last_heartbeat: '2025-01-20T21:47:05Z',
    current_stage: 4,
    current_experiment: 203,
    best_M_contribution: 0.8769,
    claimed_at: '2025-01-20T08:01:15Z',
    claim_ttl_s: 600,
  },
];

// --- Wiki Articles ---
export const wikiArticles: WikiArticle[] = [
  { id: 'wiki-001', type: 'sensitivity', title: 'Sensitivity Analysis: Experiments 0–10', experiment_range: '0–10', created_at: '2025-01-20T09:15:00Z', content_summary: 'Initial sensitivity mapping. Root thickness and root chord show highest impact on composite metric M. Sweep angle emerging as significant.' },
  { id: 'wiki-002', type: 'batch_summary', title: 'Batch Summary: Experiments 0–10', experiment_range: '0–10', created_at: '2025-01-20T09:16:00Z', content_summary: '10 experiments completed. 3 KEPT (30%). Best M improved from 0.6543 to 0.6712. Gradient strategy shows early promise. Mesh quality stable at 0.89.' },
  { id: 'wiki-003', type: 'interaction', title: 'Parameter Interactions: Experiments 0–10', experiment_range: '0–10', created_at: '2025-01-20T09:17:00Z', content_summary: 'Strong interaction detected between thickness_root and camber_root (synergy=0.72). Washout–twist_tip pair shows expected coupling (0.81).' },
  { id: 'wiki-004', type: 'sensitivity', title: 'Sensitivity Analysis: Experiments 11–20', experiment_range: '11–20', created_at: '2025-01-20T10:32:00Z', content_summary: 'Updated sensitivity rankings. Thickness_root remains #1. Sweep_angle moved from #4 to #3. Control surface parameters confirmed as dead zones.' },
  { id: 'wiki-005', type: 'batch_summary', title: 'Batch Summary: Experiments 11–20', experiment_range: '11–20', created_at: '2025-01-20T10:33:00Z', content_summary: '20 experiments completed. 6 KEPT (30%). Best M: 0.6984. Solve timeout rate: 10%. Sensitivity-weighted strategy outperforming random.' },
  { id: 'wiki-006', type: 'sensitivity', title: 'Sensitivity Analysis: Experiments 21–30', experiment_range: '21–30', created_at: '2025-01-20T11:48:00Z', content_summary: 'Camber_root sensitivity increased to 0.77 (was 0.65). Camber_pos_root entered dead zone. Flap/aileron deflections confirmed dead zones.' },
  { id: 'wiki-007', type: 'batch_summary', title: 'Batch Summary: Experiments 21–30', experiment_range: '21–30', created_at: '2025-01-20T11:49:00Z', content_summary: '30 total experiments. 8 KEPT (26.7%). Best M: 0.7231. Wave drag component decreasing. Mesh fail rate: 5%. Rate: 7.5 exp/hr.' },
  { id: 'wiki-008', type: 'interaction', title: 'Parameter Interactions: Experiments 21–30', experiment_range: '21–30', created_at: '2025-01-20T11:50:00Z', content_summary: 'New interaction: sweep_angle × thickness_tip emerging (0.48→0.64). Anti-synergy between root_chord and taper_ratio confirmed.' },
  { id: 'wiki-009', type: 'batch_summary', title: 'Batch Summary: Experiments 31–40', experiment_range: '31–40', created_at: '2025-01-20T13:05:00Z', content_summary: '40 total. 11 KEPT (27.5%). Best M: 0.7512. Significant improvement from camber_root increase strategy. GEP awaiting trigger at exp 500.' },
  { id: 'wiki-010', type: 'sensitivity', title: 'Sensitivity Analysis: Experiments 41–50', experiment_range: '41–50', created_at: '2025-01-20T14:22:00Z', content_summary: 'Sensitivity rankings stable. Top 3: thickness_root (0.91), root_chord (0.82), camber_root (0.77). Dead zones: camber_pos_root, camber_pos_tip, twist_root, flap, aileron.' },
  { id: 'wiki-011', type: 'batch_summary', title: 'Batch Summary: Experiments 51–60', experiment_range: '51–60', created_at: '2025-01-20T15:38:00Z', content_summary: '50 total. 14 KEPT (28.0%). Best M: 0.7803. Surrogate model now active (50+ experiments). Prediction accuracy R²=0.82.' },
  { id: 'wiki-012', type: 'interaction', title: 'Parameter Interactions: Experiments 51–60', experiment_range: '51–60', created_at: '2025-01-20T15:39:00Z', content_summary: 'Interaction matrix converging. Top interactions remain stable. Washout–twist_tip coupling strengthened to 0.81. No new emergent interactions.' },
  { id: 'wiki-013', type: 'batch_summary', title: 'Batch Summary: Experiments 61–70', experiment_range: '61–70', created_at: '2025-01-20T16:55:00Z', content_summary: '60 total. 16 KEPT (26.7%). Best M: 0.8045. Convergence rate slowing. Strategy adapting via sensitivity weighting. Rate: 8.1 exp/hr.' },
  { id: 'wiki-014', type: 'sensitivity', title: 'Sensitivity Analysis: Experiments 71–80', experiment_range: '71–80', created_at: '2025-01-20T18:12:00Z', content_summary: 'Hot zones identified: thickness_root, root_chord, sweep_angle, camber_root. Design space focusing on these 4 parameters.' },
  { id: 'wiki-015', type: 'batch_summary', title: 'Batch Summary: Experiments 81–90', experiment_range: '81–90', created_at: '2025-01-20T19:28:00Z', content_summary: '80 total. 21 KEPT (26.3%). Best M: 0.8412. Exponential improvement phase. L/D approaching 22. Wave drag below 0.003.' },
  { id: 'wiki-016', type: 'batch_summary', title: 'Batch Summary: Experiments 91–100', experiment_range: '91–100', created_at: '2025-01-20T20:45:00Z', content_summary: '100 total. 26 KEPT (26.0%). Best M: 0.8601. Improvement rate beginning to plateau. Consider GEP strategy adjustment at next evolution.' },
];

// --- Decision Log ---
export const decisionLog: DecisionLogEntry[] = experiments
  .filter(e => e.stage_reached === 5)
  .slice(-50)
  .map(e => ({
    timestamp: e.timestamp,
    experiment_n: e.experiment_n,
    decision: e.status === 'KEPT' ? 'KEEP' as const : 'REVERT' as const,
    reason: e.status === 'KEPT' 
      ? `M improved: ${e.metric_M} > ${e.best_M_at_time}`
      : e.status === 'REVERTED'
      ? `M did not improve: ${e.metric_M} ≤ ${e.best_M_at_time}`
      : `Non-kept outcome: ${e.status}`,
    metric_M: e.metric_M ?? 0,
    best_M: e.best_M_at_time,
    delta_M: e.metric_M !== null ? Number((e.metric_M - e.best_M_at_time).toFixed(4)) : 0,
    parameter_id: e.parameter_id,
    strategy: e.strategy,
  }));

// --- Event Log ---
export const eventLog: EventLogEntry[] = [
  { timestamp: '2025-01-20T08:00:00Z', event_type: 'LOOP_START', severity: 'info', message: 'Optimisation loop started', source: 'LoopOrchestrator', details: { run_id: 'run-a7f3c9e2', mach: 0.78, alpha: 2.5 } },
  { timestamp: '2025-01-20T08:00:01Z', event_type: 'STAGE_0_INIT', severity: 'info', message: 'Stage 0 initialisation complete', source: 'LoopOrchestrator' },
  { timestamp: '2025-01-20T08:01:00Z', event_type: 'SWARM_REGISTER', severity: 'info', message: '4 swarm nodes registered', source: 'SwarmOrchestrator', details: { nodes: ['node-alpha', 'node-beta', 'node-gamma', 'node-delta'] } },
  { timestamp: '2025-01-20T08:05:00Z', event_type: 'EXP_0_BASELINE', severity: 'info', message: 'Baseline experiment completed. M=0.6543', source: 'KeepRevertAgent' },
  { timestamp: '2025-01-20T09:15:00Z', event_type: 'WIKI_COMPILE', severity: 'info', message: 'Wiki batch 0–10 compiled (3 articles)', source: 'WikiCompilerAgent' },
  { timestamp: '2025-01-20T10:45:00Z', event_type: 'SOLVE_TIMEOUT', severity: 'warning', message: 'Experiment 23: SU2 solve exceeded kill timer (480s)', source: 'SolverAgent', details: { experiment_n: 23, kill_timer_s: 480 } },
  { timestamp: '2025-01-20T11:30:00Z', event_type: 'MESH_FAIL', severity: 'warning', message: 'Experiment 31: GMSH mesh quality below threshold (0.62 < 0.70)', source: 'MeshQualityAgent' },
  { timestamp: '2025-01-20T12:15:00Z', event_type: 'BOUNDS_FAIL', severity: 'warning', message: 'Experiment 44: Proposed sweep_angle=45.2 exceeds max=45.0', source: 'BoundsCheckAgent' },
  { timestamp: '2025-01-20T14:30:00Z', event_type: 'SURROGATE_TRAIN', severity: 'info', message: 'GPR surrogate model trained (50 samples, R²=0.82)', source: 'SurrogateAgent' },
  { timestamp: '2025-01-20T16:00:00Z', event_type: 'CONSECUTIVE_FAIL', severity: 'warning', message: '2 consecutive non-KEPT outcomes (threshold: 3)', source: 'LoopOrchestrator' },
  { timestamp: '2025-01-20T18:30:00Z', event_type: 'EXTRACTION_FAIL', severity: 'error', message: 'Experiment 127: SU2 output CSV parsing failed', source: 'ExtractionAgent' },
  { timestamp: '2025-01-20T19:45:00Z', event_type: 'SOLVE_FAIL', severity: 'error', message: 'Experiment 145: SU2 diverged after 120 iterations (residual > 1e2)', source: 'SolverAgent' },
  { timestamp: '2025-01-20T20:00:00Z', event_type: 'KG_UPDATE', severity: 'info', message: 'Knowledge graph updated: sensitivity rankings recalculated', source: 'KnowledgeGraphAgent' },
  { timestamp: '2025-01-20T20:15:00Z', event_type: 'BEST_M_IMPROVED', severity: 'info', message: 'New best M=0.8821 at experiment 138', source: 'KeepRevertAgent' },
  { timestamp: '2025-01-20T21:00:00Z', event_type: 'HEARTBEAT_OK', severity: 'info', message: 'All 4 swarm nodes heartbeat OK', source: 'SwarmSyncAgent' },
  { timestamp: '2025-01-20T21:30:00Z', event_type: 'GIT_COMMIT', severity: 'info', message: 'KEEP commit for exp(199): M=0.8794 delta=+0.0012', source: 'KeepRevertAgent' },
];

// --- Constitutional Rules ---
export interface ConstitutionalRule {
  id: string;
  title: string;
  description: string;
  status: 'enforced' | 'violated' | 'n/a';
  last_checked: string;
  details: string;
}

export const constitutionalRules: ConstitutionalRule[] = [
  { id: 'RULE-001', title: 'One Mutable File Law', description: 'Only geometry/wing.geo may be modified during loop', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'Pre-commit hook active. 200 commits verified. No violations.' },
  { id: 'RULE-002', title: 'Kill Timer Law', description: 'CFD solve bounded by hard wall-time (480s)', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'Dual-layer: OS timeout + BullMQ job timeout. 12 timeouts handled correctly.' },
  { id: 'RULE-003', title: 'Git Integrity Law', description: 'Every experiment: exactly one KEEP commit or REVERT checkout', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'Working tree clean before every experiment. No dirty-tree halts.' },
  { id: 'RULE-004', title: 'Physical Bounds Law', description: 'Parameter values must stay within hard bounds', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'BoundsCheckAgent rejected 8 mutations. All within registry limits.' },
  { id: 'RULE-005', title: 'Result Provenance Law', description: 'Results require DB record + S3 files + SHA256 match', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'All 200 experiment records verified. SHA256 checksums match.' },
  { id: 'RULE-006', title: 'Swarm Non-Collision Law', description: 'Nodes must claim non-overlapping design regions', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: '4 active claims. No overlap detected. TTL renewal active.' },
  { id: 'RULE-007', title: 'Loop Structure Law', description: 'Stages must traverse 0→1→2→3→4→5 in order', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: '200 experiments verified. No stage skips except defined short-circuits.' },
  { id: 'RULE-008', title: 'Beat-the-Best Law', description: 'Keep iff M_new > M_best (not previous)', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'M_best initialized from exp-0 (0.6543). Current M_best: 0.8821.' },
  { id: 'RULE-009', title: 'Consecutive Failure Law', description: 'Loop pauses after 3 consecutive non-KEPT outcomes', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: `Current consecutive fails: ${consecFails}. Threshold: 3. No halt triggered.` },
  { id: 'RULE-010', title: 'Single Solve Per Node Law', description: 'Maximum one SU2 solve per node simultaneously', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'Solve locks active on all 4 nodes. No double-acquire attempts.' },
  { id: 'RULE-011', title: 'Append-Only Experiment Record Law', description: 'No UPDATE or DELETE on experiments table', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'DB trigger active. 200 INSERT operations, 0 UPDATE, 0 DELETE.' },
  { id: 'RULE-012', title: 'Dependency Chain Law', description: 'Package build order: types→db→redis→s3→...→wiki', status: 'enforced', last_checked: '2025-01-20T21:47:00Z', details: 'Turborepo pipeline verified. No circular dependencies detected.' },
];

// --- Current Pipeline State (for live view) ---
export const currentPipeline: PipelineStage[] = [
  { id: 0, name: 'Initialisation', description: 'Baseline geometry setup and validation', agent: 'LoopOrchestrator', status: 'completed', duration_ms: 2500, timestamp: '2025-01-20T08:00:00Z' },
  { id: 1, name: 'Geometry Mutation', description: 'Propose and write mutation to wing.geo', agent: 'GeometryMutationAgent', status: 'completed', duration_ms: 1800, timestamp: '2025-01-20T21:46:00Z' },
  { id: 2, name: 'Mesh Generation', description: 'Run GMSH pipeline, validate mesh quality', agent: 'MeshAgent', status: 'completed', duration_ms: 45000, timestamp: '2025-01-20T21:46:02Z' },
  { id: 3, name: 'CFD Solve', description: 'Run SU2 with dual kill timers', agent: 'SolverAgent', status: 'active', duration_ms: 0, timestamp: '2025-01-20T21:46:47Z' },
  { id: 4, name: 'Results Extraction', description: 'Parse SU2 outputs, compute M', agent: 'ExtractionAgent', status: 'pending', duration_ms: 0, timestamp: '' },
  { id: 5, name: 'Keep / Revert Decision', description: 'Apply RULE-003 and RULE-008', agent: 'KeepRevertAgent', status: 'pending', duration_ms: 0, timestamp: '' },
  { id: 6, name: 'Wiki Compilation', description: 'Background: compile sensitivity and batch articles', agent: 'WikiCompilerAgent', status: 'pending', duration_ms: 0, timestamp: '' },
  { id: 7, name: 'Knowledge Graph', description: 'Background: update sensitivities and interactions', agent: 'KnowledgeGraphAgent', status: 'pending', duration_ms: 0, timestamp: '' },
  { id: 8, name: 'GEP Evolution', description: 'Background: evolve genome population (every 500 exp)', agent: 'GEPOrchestrator', status: 'pending', duration_ms: 0, timestamp: '' },
  { id: 9, name: 'Swarm Sync', description: 'Background: heartbeat, push records, pull global_best', agent: 'SwarmSyncAgent', status: 'pending', duration_ms: 0, timestamp: '' },
];

// --- Git Log ---
export interface GitLogEntry {
  hash: string;
  message: string;
  author: string;
  timestamp: string;
  type: 'KEEP' | 'GEP' | 'WIKI' | 'initial';
}

export const gitLog: GitLogEntry[] = [
  { hash: 'a3f7c1e', message: 'exp(0): M=0.6543 delta=+0.0000 L/D=18.20 [KEEP] mutation: baseline=0→0 mesh: 184320 cells | solve: 342.5s | convg: 6.2ord', author: 'AeroLoopBot', timestamp: '2025-01-20T08:05:00Z', type: 'initial' },
  ...experiments
    .filter(e => e.status === 'KEPT' && e.experiment_n > 0)
    .slice(-30)
    .map(e => ({
      hash: sha256mock(`commit-${e.experiment_n}`).slice(0, 7),
      message: `exp(${e.experiment_n}): M=${e.metric_M?.toFixed(4)} delta=${e.metric_M && e.best_M_at_time ? '+' + (e.metric_M - e.best_M_at_time + 0.001).toFixed(4) : '+0.0000'} L/D=${e.LD_ratio?.toFixed(2) ?? 'N/A'} [KEEP] mutation: ${e.parameter_id}=${e.old_value}→${e.new_value} mesh: ${e.mesh_cell_count} cells | solve: ${e.solve_wall_time_s?.toFixed(1) ?? 'N/A'}s | convg: ${e.residual_orders?.toFixed(1) ?? 'N/A'}ord`,
      author: 'AeroLoopBot',
      timestamp: e.timestamp,
      type: 'KEEP' as const,
    })),
];

// --- Metric History for Charts ---
export const metricHistory = experiments
  .filter(e => e.metric_M !== null)
  .map(e => ({
    experiment_n: e.experiment_n,
    metric_M: e.metric_M!,
    best_M: e.best_M_at_time,
    LD_ratio: e.LD_ratio ?? 0,
    CD: e.CD ?? 0,
    cd_wave: e.cd_wave ?? 0,
    timestamp: e.timestamp,
    status: e.status,
    node_id: e.node_id,
  }));

// --- Experiment Rate History ---
export const rateHistory = Array.from({ length: 20 }, (_, i) => {
  const startExp = i * 10;
  const endExp = (i + 1) * 10;
  const batch = experiments.filter(e => e.experiment_n >= startExp && e.experiment_n < endExp);
  const kept = batch.filter(e => e.status === 'KEPT').length;
  const timeSpan = batch.length > 1 
    ? (new Date(batch[batch.length - 1].timestamp).getTime() - new Date(batch[0].timestamp).getTime()) / 3600000
    : 1;
  return {
    batch: `${startExp}–${endExp - 1}`,
    total: batch.length,
    kept,
    kept_rate: batch.length > 0 ? Number((kept / batch.length * 100).toFixed(1)) : 0,
    rate_per_hour: timeSpan > 0 ? Number((batch.length / timeSpan).toFixed(1)) : 0,
    timeouts: batch.filter(e => e.status === 'SOLVE_TIMEOUT').length,
    mesh_fails: batch.filter(e => e.status === 'MESH_FAIL').length,
  };
});

// --- Mesh Quality Summary ---
export const meshQualitySummary = {
  total_meshed: experiments.filter(e => e.mesh_cell_count !== null).length,
  avg_cell_count: Math.round(experiments.filter(e => e.mesh_cell_count !== null).reduce((s, e) => s + (e.mesh_cell_count ?? 0), 0) / experiments.filter(e => e.mesh_cell_count !== null).length),
  min_cell_count: Math.min(...experiments.filter(e => e.mesh_cell_count !== null).map(e => e.mesh_cell_count!)),
  max_cell_count: Math.max(...experiments.filter(e => e.mesh_cell_count !== null).map(e => e.mesh_cell_count!)),
  avg_quality: Number((experiments.filter(e => e.mesh_quality_score !== null).reduce((s, e) => s + (e.mesh_quality_score ?? 0), 0) / experiments.filter(e => e.mesh_quality_score !== null).length).toFixed(2)),
  quality_threshold: 0.70,
  quality_target_level: 0.85,
  fail_count: experiments.filter(e => e.status === 'MESH_FAIL').length,
  fail_rate: Number((experiments.filter(e => e.status === 'MESH_FAIL').length / experiments.length * 100).toFixed(1)),
};
