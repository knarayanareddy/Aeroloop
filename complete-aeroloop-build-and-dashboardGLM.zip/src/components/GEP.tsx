import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Dna, Trophy, Users, RefreshCw } from 'lucide-react';
import { gepGenomes, gepEvolutions, runMetrics } from '../data/mockData';

export default function GEP() {
  const sortedGenomes = [...gepGenomes].sort((a, b) => b.fitness - a.fitness);
  const activeGenome = gepGenomes.find(g => g.is_active)!;
  const eliteCount = 2;
  const totalPop = 16;

  // Selection breakdown: 2 elites + 4 crossover + 8 mutation + 2 random = 16
  const selectionBreakdown = [
    { label: 'Elites (top-2)', count: 2, color: 'bg-emerald-500' },
    { label: 'Crossover offspring', count: 4, color: 'bg-blue-500' },
    { label: 'Mutation offspring', count: 8, color: 'bg-violet-500' },
    { label: 'Random immigrants', count: 2, color: 'bg-amber-500' },
  ];

  const genomeFitnessData = sortedGenomes.map((g, i) => ({
    rank: i + 1,
    fitness: g.fitness,
    strategy: g.strategy,
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2"><Dna className="w-5 h-5 text-orange-400" /> GEP Genome Evolver (Stage 8)</h3>
            <p className="text-sm text-slate-400 mt-1">
              Gene Expression Programming — evolves optimisation strategy every 500 experiments.
              Population: {totalPop} | Elites: {eliteCount} | Selection: 2+4+8+2={totalPop}
            </p>
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-500">Next Evolution</div>
            <div className="text-lg font-bold text-orange-400">Exp #{runMetrics.gep_next_at}</div>
            <div className="text-xs text-slate-500">{runMetrics.gep_next_at - runMetrics.total_experiments} experiments away</div>
          </div>
        </div>
      </div>

      {/* Current Active Genome */}
      <div className="bg-gradient-to-r from-orange-500/10 to-amber-500/5 rounded-xl p-6 border border-orange-500/20">
        <h4 className="text-sm font-semibold text-orange-300 mb-4 flex items-center gap-2">
          <Trophy className="w-4 h-4" /> Active Genome (Generation {activeGenome.generation})
        </h4>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          <GenomeGeneCard label="Fitness" value={activeGenome.fitness.toFixed(4)} color="orange" />
          <GenomeGeneCard label="Strategy" value={activeGenome.strategy} color="cyan" />
          <GenomeGeneCard label="Step Size" value={activeGenome.step_size_multiplier.toFixed(2)} color="blue" />
          <GenomeGeneCard label="Topology Prob" value={activeGenome.topology_probability.toFixed(2)} color="violet" />
          <GenomeGeneCard label="Exploration" value={activeGenome.exploration_rate.toFixed(2)} color="emerald" />
          <GenomeGeneCard label="Crossover" value={activeGenome.crossover_rate.toFixed(2)} color="pink" />
          <GenomeGeneCard label="Mutation" value={activeGenome.mutation_rate.toFixed(2)} color="amber" />
        </div>
      </div>

      {/* Population Fitness Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-800/60 rounded-xl p-5 border border-slate-700/50">
          <h4 className="text-sm font-semibold text-slate-300 mb-4">Population Fitness Distribution</h4>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={genomeFitnessData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="rank" tick={{ fill: '#94a3b8', fontSize: 11 }} label={{ value: 'Rank', position: 'insideBottom', offset: -5, fill: '#64748b' }} />
              <YAxis domain={[0, 1]} tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px', color: '#e2e8f0' }} />
              <Bar dataKey="fitness" radius={[4, 4, 0, 0]}>
                {genomeFitnessData.map((_, idx) => (
                  <Cell key={idx} fill={idx < 2 ? '#10b981' : idx < 6 ? '#3b82f6' : idx < 14 ? '#8b5cf6' : '#f59e0b'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
            <span className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded-sm bg-emerald-500" /> Elite</span>
            <span className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded-sm bg-blue-500" /> Top-6</span>
            <span className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded-sm bg-violet-500" /> Mid</span>
            <span className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded-sm bg-amber-500" /> Low</span>
          </div>
        </div>

        {/* Selection Breakdown */}
        <div className="bg-slate-800/60 rounded-xl p-5 border border-slate-700/50">
          <h4 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-400" /> Selection Breakdown (FR-8-004)
          </h4>
          <div className="space-y-4">
            {selectionBreakdown.map(s => (
              <div key={s.label}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-slate-300">{s.label}</span>
                  <span className="text-xs text-slate-400 font-bold">{s.count}/{totalPop}</span>
                </div>
                <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${s.color}`} style={{ width: `${(s.count / totalPop) * 100}%` }} />
                </div>
              </div>
            ))}
            <div className="mt-4 pt-4 border-t border-slate-700/50">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Total Population</span>
                <span className="font-bold text-white">16</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-2">
                AC-8-004: Selection breakdown is 2 elites + 4 crossover + 8 mutation + 2 random = 16.
                Elites = top-2 by fitness. No duplicate genomes allowed in population.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Full Population Table */}
      <div className="bg-slate-800/60 rounded-xl border border-slate-700/50 overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-700/50 flex items-center justify-between">
          <h4 className="text-sm font-semibold text-slate-300">Full Population (Generation 0)</h4>
          <span className="text-xs text-slate-500">Sorted by fitness</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Rank</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">ID</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Fitness</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Strategy</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Step Size</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Topo Prob</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Explore</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Crossover</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Mutation</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Status</th>
              </tr>
            </thead>
            <tbody>
              {sortedGenomes.map((genome, idx) => (
                <tr key={genome.id} className={`border-b border-slate-700/30 hover:bg-slate-800/40 ${genome.is_active ? 'bg-orange-500/5' : ''}`}>
                  <td className="px-4 py-2.5">
                    <span className={`font-mono text-sm ${idx < 2 ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
                      #{idx + 1}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-300">{genome.id}</td>
                  <td className="px-4 py-2.5 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <div className="w-10 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${genome.fitness * 100}%` }} />
                      </div>
                      <span className="text-xs font-mono text-slate-300">{genome.fitness.toFixed(4)}</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-slate-300">{genome.strategy}</td>
                  <td className="px-4 py-2.5 text-xs text-center text-slate-400 font-mono">{genome.step_size_multiplier.toFixed(2)}</td>
                  <td className="px-4 py-2.5 text-xs text-center text-slate-400 font-mono">{Number(genome.topology_probability).toFixed(2)}</td>
                  <td className="px-4 py-2.5 text-xs text-center text-slate-400 font-mono">{genome.exploration_rate.toFixed(2)}</td>
                  <td className="px-4 py-2.5 text-xs text-center text-slate-400 font-mono">{genome.crossover_rate.toFixed(2)}</td>
                  <td className="px-4 py-2.5 text-xs text-center text-slate-400 font-mono">{genome.mutation_rate.toFixed(2)}</td>
                  <td className="px-4 py-2.5 text-center">
                    {genome.is_active ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-500/20 text-orange-400 border border-orange-500/30">ACTIVE</span>
                    ) : idx < 2 ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">ELITE</span>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Evolution History */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-blue-400" /> Evolution History
        </h4>
        <p className="text-xs text-slate-400 mb-4">
          GEP evolution triggers at experiment 500, 1000, 1500, etc. (AC-8-001). 
          Current generation 0 has been active since initialisation. First evolution at experiment 500.
        </p>
        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700/30">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
            <div>
              <div className="text-xs text-slate-500">Generation</div>
              <div className="text-lg font-bold text-white">0</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Best Fitness</div>
              <div className="text-lg font-bold text-emerald-400">{gepEvolutions[0].best_fitness.toFixed(4)}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Mean Fitness</div>
              <div className="text-lg font-bold text-slate-300">{gepEvolutions[0].mean_fitness.toFixed(4)}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Diversity</div>
              <div className="text-lg font-bold text-blue-400">{gepEvolutions[0].diversity.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Active Strategy</div>
              <div className="text-lg font-bold text-violet-400">{gepEvolutions[0].active_strategy}</div>
            </div>
          </div>
        </div>
        <div className="mt-4 p-3 bg-slate-900/50 rounded-lg border border-slate-700/30">
          <p className="text-xs text-slate-500">
            <strong className="text-slate-400">RULE-061:</strong> GEP genome commit format:{' '}
            <code className="text-orange-300">chore(gep): generation {'{N}'} evolved at exp {'{experiment_n}'}</code>
          </p>
        </div>
      </div>
    </div>
  );
}

function GenomeGeneCard({ label, value, color }: { label: string; value: string; color: string }) {
  const colorMap: Record<string, string> = {
    orange: 'border-orange-500/30 bg-orange-500/5',
    cyan: 'border-cyan-500/30 bg-cyan-500/5',
    blue: 'border-blue-500/30 bg-blue-500/5',
    violet: 'border-violet-500/30 bg-violet-500/5',
    emerald: 'border-emerald-500/30 bg-emerald-500/5',
    pink: 'border-pink-500/30 bg-pink-500/5',
    amber: 'border-amber-500/30 bg-amber-500/5',
  };
  return (
    <div className={`rounded-lg p-3 border ${colorMap[color]}`}>
      <div className="text-xs text-slate-500 mb-1">{label}</div>
      <div className="text-sm font-bold text-white">{value}</div>
    </div>
  );
}
