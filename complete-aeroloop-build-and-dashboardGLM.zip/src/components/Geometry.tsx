import { ArrowUp, ArrowDown, Minus, Flame, Snowflake, Shield } from 'lucide-react';
import { geometryParameters, knowledgeGraph } from '../data/mockData';

const regionColors: Record<string, string> = {
  PLANFORM_CORE: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  THICKNESS: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  CAMBER: 'bg-violet-500/20 text-violet-400 border-violet-500/30',
  TWIST: 'bg-teal-500/20 text-teal-400 border-teal-500/30',
  CONTROL: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
};

const regionDescriptions: Record<string, string> = {
  PLANFORM_CORE: 'Root chord, tip chord, semi-span, sweep, taper — fundamental wing planform shape',
  THICKNESS: 'Root and tip thickness-to-chord ratios — structural and drag characteristics',
  CAMBER: 'Camber magnitude and position at root and tip — lift distribution control',
  TWIST: 'Twist angles and washout — spanwise lift distribution and stall behavior',
  CONTROL: 'Flap and aileron deflections — control surface authority (currently dead zones)',
};

export default function Geometry() {
  const regions = [...new Set(geometryParameters.map(p => p.region))];
  
  // Compute bounds check status for current values
  const boundsStatus = geometryParameters.map(p => ({
    id: p.id,
    withinBounds: p.current >= p.min && p.current <= p.max,
    distanceFromCenter: Math.abs(p.current - (p.min + p.max) / 2) / ((p.max - p.min) / 2),
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white">Geometry Parameter Registry (GLOBAL-GEOM-001)</h3>
        <p className="text-sm text-slate-400 mt-1">
          {geometryParameters.length} parameters across {regions.length} design regions.
          RULE-004: Any mutation outside hard bounds is REJECTED → BOUNDS_FAIL.
        </p>
      </div>

      {/* Regions Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {regions.map(region => {
          const params = geometryParameters.filter(p => p.region === region);
          const activeCount = params.filter(p => !p.dead_zone).length;
          return (
            <div key={region} className={`rounded-xl p-4 border ${regionColors[region]}`}>
              <h4 className="text-sm font-bold mb-1">{region.replace(/_/g, ' ')}</h4>
              <p className="text-xs opacity-70 mb-3">{regionDescriptions[region]}</p>
              <div className="flex items-center justify-between text-xs">
                <span>{params.length} params</span>
                <span>{activeCount} active</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Parameter Table */}
      <div className="bg-slate-800/60 rounded-xl border border-slate-700/50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Region</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Parameter</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Description</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Min</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Current</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Max</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Bounds</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Sensitivity</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Samples</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Zone</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Direction</th>
              </tr>
            </thead>
            <tbody>
              {geometryParameters.map((param, idx) => {
                const kg = knowledgeGraph.find(k => k.parameter_id === param.id);
                const bounds = boundsStatus.find(b => b.id === param.id);
                const delta = param.current - param.default;
                const percentThroughRange = ((param.current - param.min) / (param.max - param.min)) * 100;
                
                return (
                  <tr key={param.id} className={`border-b border-slate-700/30 ${idx % 2 === 0 ? 'bg-slate-800/20' : ''} hover:bg-slate-800/40 transition-colors`}>
                    <td className="px-4 py-2.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${regionColors[param.region]}`}>
                        {param.region.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="font-medium text-slate-200">{param.name}</div>
                      <div className="text-xs text-slate-500 font-mono">{param.id}</div>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-slate-400">{param.description}</td>
                    <td className="px-4 py-2.5 text-xs text-slate-400 font-mono text-center">{param.min} {param.unit}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex flex-col items-center">
                        <span className="font-mono text-white font-medium">{param.current.toFixed(3)}</span>
                        {Math.abs(delta) > 0.001 && (
                          <span className={`text-[10px] ${delta > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                            {delta > 0 ? '+' : ''}{delta.toFixed(3)} from default
                          </span>
                        )}
                        <div className="w-16 h-1 bg-slate-700 rounded-full mt-1 overflow-hidden">
                          <div className="h-full bg-blue-500 rounded-full" style={{ width: `${Math.min(100, Math.max(0, percentThroughRange))}%` }} />
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-slate-400 font-mono text-center">{param.max} {param.unit}</td>
                    <td className="px-4 py-2.5 text-center">
                      {bounds?.withinBounds ? (
                        <Shield className="w-4 h-4 text-emerald-400 inline" />
                      ) : (
                        <Shield className="w-4 h-4 text-red-400 inline" />
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <div className="w-12 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${param.sensitivity > 0.7 ? 'bg-emerald-500' : param.sensitivity > 0.4 ? 'bg-amber-500' : 'bg-red-500'}`}
                            style={{ width: `${param.sensitivity * 100}%` }} 
                          />
                        </div>
                        <span className="text-xs font-mono text-slate-300">{param.sensitivity.toFixed(2)}</span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-slate-400 text-center">{param.sample_count}</td>
                    <td className="px-4 py-2.5 text-center">
                      {param.hot_zone ? (
                        <span className="flex items-center justify-center gap-0.5 text-[10px] text-orange-400"><Flame className="w-3 h-3" /> HOT</span>
                      ) : param.dead_zone ? (
                        <span className="flex items-center justify-center gap-0.5 text-[10px] text-blue-400"><Snowflake className="w-3 h-3" /> DEAD</span>
                      ) : (
                        <span className="text-[10px] text-slate-500">—</span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      {kg?.optimal_direction === 'increase' ? (
                        <ArrowUp className="w-4 h-4 text-emerald-400 inline" />
                      ) : kg?.optimal_direction === 'decrease' ? (
                        <ArrowDown className="w-4 h-4 text-blue-400 inline" />
                      ) : (
                        <Minus className="w-4 h-4 text-slate-500 inline" />
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bounds Enforcement Summary */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-3">RULE-004: Physical Bounds Enforcement</h4>
        <p className="text-xs text-slate-400 mb-4">
          All {geometryParameters.length} parameters are currently within bounds. 
          The BoundsCheckAgent validates every proposed mutation BEFORE writing wing.geo.
          Out-of-bounds proposals are rejected immediately (BOUNDS_FAIL, no file written).
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-800/50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-emerald-400">{geometryParameters.length}</div>
            <div className="text-xs text-slate-500">Total Parameters</div>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-emerald-400">{geometryParameters.filter(p => !p.dead_zone).length}</div>
            <div className="text-xs text-slate-500">Active Parameters</div>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-orange-400">{geometryParameters.filter(p => p.hot_zone).length}</div>
            <div className="text-xs text-slate-500">Hot Zones</div>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-blue-400">{geometryParameters.filter(p => p.dead_zone).length}</div>
            <div className="text-xs text-slate-500">Dead Zones</div>
          </div>
        </div>
      </div>
    </div>
  );
}
