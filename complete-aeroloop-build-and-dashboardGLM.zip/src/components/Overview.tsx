import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, PieChart, Pie, Cell } from 'recharts';
import { Activity, TrendingUp, Clock, Zap, Database, HardDrive, Server, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { runConfig, runMetrics, infraHealth, metricHistory, rateHistory, experiments } from '../data/mockData';

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    RUNNING: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    PAUSED: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    COMPLETED: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    LOOP_HALT: 'bg-red-500/20 text-red-400 border-red-500/30',
  };
  return (
    <span className={`px-3 py-1 rounded-full text-xs font-bold border ${colors[status] || 'bg-gray-500/20 text-gray-400 border-gray-500/30'}`}>
      {status}
    </span>
  );
}

function HealthIndicator({ label, status, latency }: { label: string; status: string; latency: number }) {
  const Icon = status === 'ok' ? CheckCircle2 : status === 'degraded' ? AlertTriangle : XCircle;
  const color = status === 'ok' ? 'text-emerald-400' : status === 'degraded' ? 'text-amber-400' : 'text-red-400';
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-800/50">
      <div className="flex items-center gap-2">
        <Icon className={`w-4 h-4 ${color}`} />
        <span className="text-sm text-slate-300">{label}</span>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-xs text-slate-500">{latency}ms</span>
        <span className={`text-xs font-semibold uppercase ${color}`}>{status}</span>
      </div>
    </div>
  );
}

export default function Overview() {
  const keptRate = ((runMetrics.kept_count / runMetrics.total_experiments) * 100).toFixed(1);
  const recentExps = experiments.slice(-20);
  const recentKept = recentExps.filter(e => e.status === 'KEPT').length;
  const recentRate = ((recentKept / recentExps.length) * 100).toFixed(1);

  const statusDistribution = [
    { name: 'KEPT', value: runMetrics.kept_count, color: '#10b981' },
    { name: 'REVERTED', value: runMetrics.reverted_count, color: '#6b7280' },
    { name: 'TIMEOUT', value: runMetrics.timeout_count, color: '#f59e0b' },
    { name: 'MESH_FAIL', value: runMetrics.mesh_fail_count, color: '#ef4444' },
    { name: 'SOLVE_FAIL', value: runMetrics.solve_fail_count, color: '#dc2626' },
    { name: 'BOUNDS_FAIL', value: runMetrics.bounds_fail_count, color: '#8b5cf6' },
    { name: 'EXTRACT_FAIL', value: runMetrics.extraction_fail_count, color: '#f97316' },
  ];

  return (
    <div className="space-y-6">
      {/* Run Header */}
      <div className="flex items-center justify-between bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-6 border border-slate-700/50">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-2xl font-bold text-white">{runConfig.label}</h2>
            <StatusBadge status={runConfig.status} />
            {runConfig.swarm_enabled && (
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-violet-500/20 text-violet-400 border border-violet-500/30">SWARM</span>
            )}
          </div>
          <div className="flex items-center gap-6 text-sm text-slate-400">
            <span>Mach {runConfig.mach}</span>
            <span>Re {runConfig.reynolds.toExponential(1)}</span>
            <span>α {runConfig.alpha}°</span>
            <span>w<sub>L/D</sub>={runConfig.w_ld} w<sub>buf</sub>={runConfig.w_buffet} w<sub>wave</sub>={runConfig.w_wave}</span>
            <span>Kill Timer: {runConfig.kill_timer_s}s</span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs text-slate-500 mb-1">Run ID</div>
          <div className="text-sm font-mono text-slate-400">{runConfig.run_id}</div>
          <div className="text-xs text-slate-500 mt-1">Started {new Date(runConfig.created_at).toLocaleString()}</div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <KPICard icon={<TrendingUp className="w-5 h-5" />} label="Best M" value={runMetrics.best_M.toFixed(4)} sub={`@ exp-${runMetrics.best_M_exp_n}`} color="emerald" />
        <KPICard icon={<Activity className="w-5 h-5" />} label="Total Experiments" value={runMetrics.total_experiments.toString()} sub={`${runMetrics.kept_count} kept (${keptRate}%)`} color="blue" />
        <KPICard icon={<Zap className="w-5 h-5" />} label="Rate" value={`${runMetrics.rate_per_hour}`} sub="exp/hr (1h rolling)" color="violet" />
        <KPICard icon={<Clock className="w-5 h-5" />} label="Consecutive Fails" value={runMetrics.consecutive_fails.toString()} sub={`threshold: 3`} color={runMetrics.consecutive_fails >= 3 ? 'red' : 'amber'} />
        <KPICard icon={<Server className="w-5 h-5" />} label="GEP Generation" value={runMetrics.gep_generation.toString()} sub={`next @ exp-${runMetrics.gep_next_at}`} color="cyan" />
        <KPICard icon={<Zap className="w-5 h-5" />} label="Recent Keep Rate" value={`${recentRate}%`} sub="last 20 experiments" color="teal" />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Metric History */}
        <div className="lg:col-span-2 bg-slate-800/60 rounded-xl p-5 border border-slate-700/50">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Composite Metric M — Optimisation Trajectory</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={metricHistory.filter((_, i) => i % 3 === 0)}>
              <defs>
                <linearGradient id="metricGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="bestGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="experiment_n" tick={{ fill: '#94a3b8', fontSize: 11 }} label={{ value: 'Experiment #', position: 'insideBottom', offset: -5, fill: '#64748b' }} />
              <YAxis domain={[0.6, 0.95]} tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px', color: '#e2e8f0' }} />
              <Area type="monotone" dataKey="best_M" stroke="#3b82f6" strokeWidth={2} fill="url(#bestGrad)" name="Best M" />
              <Area type="monotone" dataKey="metric_M" stroke="#10b981" strokeWidth={1.5} fill="url(#metricGrad)" name="Metric M" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Status Distribution */}
        <div className="bg-slate-800/60 rounded-xl p-5 border border-slate-700/50">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Experiment Outcome Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={statusDistribution} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={2} dataKey="value">
                {statusDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px', color: '#e2e8f0' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-1 mt-2">
            {statusDistribution.map(s => (
              <div key={s.name} className="flex items-center gap-1.5 text-xs">
                <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: s.color }} />
                <span className="text-slate-400">{s.name}</span>
                <span className="text-slate-300 font-medium ml-auto">{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Rate + Health Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Keep Rate by Batch */}
        <div className="bg-slate-800/60 rounded-xl p-5 border border-slate-700/50">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Keep Rate & Experiment Rate by Batch</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={rateHistory}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="batch" tick={{ fill: '#94a3b8', fontSize: 9 }} angle={-30} textAnchor="end" height={50} />
              <YAxis yAxisId="left" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px', color: '#e2e8f0' }} />
              <Legend wrapperStyle={{ fontSize: 11, color: '#94a3b8' }} />
              <Bar yAxisId="left" dataKey="kept_rate" fill="#10b981" name="Keep Rate %" radius={[2, 2, 0, 0]} />
              <Bar yAxisId="right" dataKey="rate_per_hour" fill="#8b5cf6" name="Rate (exp/hr)" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Infrastructure Health */}
        <div className="bg-slate-800/60 rounded-xl p-5 border border-slate-700/50">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">
            <span className="flex items-center gap-2"><Database className="w-4 h-4" /> Infrastructure Health</span>
          </h3>
          <div className="space-y-2">
            <HealthIndicator label="PostgreSQL" status={infraHealth.postgresql} latency={infraHealth.postgresql_latency_ms} />
            <HealthIndicator label="Redis" status={infraHealth.redis} latency={infraHealth.redis_latency_ms} />
            <HealthIndicator label="S3 (MinIO)" status={infraHealth.s3} latency={infraHealth.s3_latency_ms} />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="bg-slate-800/50 rounded-lg p-3">
              <div className="text-xs text-slate-500 mb-1">S3 Storage</div>
              <div className="flex items-end gap-1">
                <span className="text-lg font-bold text-slate-200">{infraHealth.s3_bucket_gb}</span>
                <span className="text-xs text-slate-500">/ {infraHealth.s3_bucket_gb + infraHealth.s3_bucket_free_gb} GB</span>
              </div>
              <div className="mt-1.5 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(infraHealth.s3_bucket_gb / (infraHealth.s3_bucket_gb + infraHealth.s3_bucket_free_gb)) * 100}%` }} />
              </div>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-3">
              <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><HardDrive className="w-3 h-3" /> PostgreSQL Size</div>
              <div className="flex items-end gap-1">
                <span className="text-lg font-bold text-slate-200">{infraHealth.postgres_size_gb}</span>
                <span className="text-xs text-slate-500">GB</span>
              </div>
              <div className="mt-1.5 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${(infraHealth.postgres_size_gb / 2) * 100}%` }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function KPICard({ icon, label, value, sub, color }: { icon: React.ReactNode; label: string; value: string; sub: string; color: string }) {
  const colorMap: Record<string, string> = {
    emerald: 'from-emerald-500/10 to-emerald-900/10 border-emerald-500/20 text-emerald-400',
    blue: 'from-blue-500/10 to-blue-900/10 border-blue-500/20 text-blue-400',
    violet: 'from-violet-500/10 to-violet-900/10 border-violet-500/20 text-violet-400',
    amber: 'from-amber-500/10 to-amber-900/10 border-amber-500/20 text-amber-400',
    red: 'from-red-500/10 to-red-900/10 border-red-500/20 text-red-400',
    cyan: 'from-cyan-500/10 to-cyan-900/10 border-cyan-500/20 text-cyan-400',
    teal: 'from-teal-500/10 to-teal-900/10 border-teal-500/20 text-teal-400',
  };
  const c = colorMap[color] || colorMap.blue;
  return (
    <div className={`bg-gradient-to-br ${c} rounded-xl p-4 border`}>
      <div className="flex items-center gap-2 mb-2 opacity-60">{icon}<span className="text-xs text-slate-400">{label}</span></div>
      <div className="text-2xl font-bold text-white">{value}</div>
      <div className="text-xs text-slate-400 mt-1">{sub}</div>
    </div>
  );
}
