import { useState, useMemo } from 'react';
import { ChevronDown, ChevronUp, Filter, Search, ExternalLink } from 'lucide-react';
import { experiments, type Experiment, type ExperimentStatus } from '../data/mockData';

const statusColors: Record<ExperimentStatus, string> = {
  KEPT: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  REVERTED: 'bg-slate-600/20 text-slate-400 border-slate-600/30',
  SOLVE_TIMEOUT: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  MESH_FAIL: 'bg-red-500/20 text-red-400 border-red-500/30',
  SOLVE_FAIL: 'bg-red-600/20 text-red-500 border-red-600/30',
  BOUNDS_FAIL: 'bg-violet-500/20 text-violet-400 border-violet-500/30',
  EXTRACTION_FAIL: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
};

const stageNames = ['Init', 'Mutate', 'Mesh', 'Solve', 'Extract', 'Decide', 'Wiki', 'KG', 'GEP', 'Swarm'];

type SortKey = 'experiment_n' | 'metric_M' | 'status' | 'timestamp' | 'solve_wall_time_s' | 'LD_ratio';

export default function Experiments() {
  const [statusFilter, setStatusFilter] = useState<ExperimentStatus | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('experiment_n');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(0);
  const [selectedExp, setSelectedExp] = useState<Experiment | null>(null);
  const pageSize = 25;

  const filtered = useMemo(() => {
    let result = experiments;
    if (statusFilter !== 'ALL') {
      result = result.filter(e => e.status === statusFilter);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(e =>
        e.parameter_id.toLowerCase().includes(q) ||
        e.node_id.toLowerCase().includes(q) ||
        e.strategy.toLowerCase().includes(q) ||
        e.experiment_n.toString().includes(q)
      );
    }
    result = [...result].sort((a, b) => {
      let va: number | string = 0, vb: number | string = 0;
      switch (sortKey) {
        case 'experiment_n': va = a.experiment_n; vb = b.experiment_n; break;
        case 'metric_M': va = a.metric_M ?? -1; vb = b.metric_M ?? -1; break;
        case 'status': va = a.status; vb = b.status; break;
        case 'timestamp': va = a.timestamp; vb = b.timestamp; break;
        case 'solve_wall_time_s': va = a.solve_wall_time_s ?? 0; vb = b.solve_wall_time_s ?? 0; break;
        case 'LD_ratio': va = a.LD_ratio ?? 0; vb = b.LD_ratio ?? 0; break;
      }
      if (va < vb) return sortDir === 'asc' ? -1 : 1;
      if (va > vb) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
    return result;
  }, [statusFilter, searchQuery, sortKey, sortDir]);

  const paged = filtered.slice(page * pageSize, (page + 1) * pageSize);
  const totalPages = Math.ceil(filtered.length / pageSize);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('desc'); }
  };

  const SortIcon = ({ col }: { col: SortKey }) => (
    sortKey === col ? (sortDir === 'asc' ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />) : null
  );

  // Summary stats
  const statusCounts = experiments.reduce((acc, e) => {
    acc[e.status] = (acc[e.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {(['ALL', 'KEPT', 'REVERTED', 'SOLVE_TIMEOUT', 'MESH_FAIL', 'SOLVE_FAIL', 'BOUNDS_FAIL', 'EXTRACTION_FAIL'] as const).map(s => (
          <button
            key={s}
            onClick={() => { setStatusFilter(s); setPage(0); }}
            className={`rounded-lg p-3 border text-left transition-all ${
              statusFilter === s
                ? 'bg-slate-700/60 border-slate-500/50'
                : 'bg-slate-800/40 border-slate-700/30 hover:bg-slate-800/60'
            }`}
          >
            <div className="text-xs text-slate-400 truncate">{s === 'ALL' ? 'Total' : s.replace(/_/g, ' ')}</div>
            <div className="text-lg font-bold text-white">{s === 'ALL' ? experiments.length : (statusCounts[s] || 0)}</div>
            {s !== 'ALL' && (
              <div className="text-xs text-slate-500">{((statusCounts[s] || 0) / experiments.length * 100).toFixed(1)}%</div>
            )}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 bg-slate-800/60 rounded-xl p-4 border border-slate-700/50">
        <Filter className="w-4 h-4 text-slate-400" />
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search by parameter, node, strategy, or experiment #..."
            value={searchQuery}
            onChange={e => { setSearchQuery(e.target.value); setPage(0); }}
            className="w-full bg-slate-900/50 border border-slate-700/50 rounded-lg pl-9 pr-4 py-2 text-sm text-slate-300 placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
          />
        </div>
        <div className="text-sm text-slate-400">
          {filtered.length} experiment{filtered.length !== 1 ? 's' : ''}
        </div>
      </div>

      {/* Table */}
      <div className="bg-slate-800/60 rounded-xl border border-slate-700/50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 cursor-pointer hover:text-slate-300" onClick={() => toggleSort('experiment_n')}>
                  <span className="flex items-center gap-1">Exp # <SortIcon col="experiment_n" /></span>
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Status</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Stage</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Parameter</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Mutation</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 cursor-pointer hover:text-slate-300" onClick={() => toggleSort('metric_M')}>
                  <span className="flex items-center gap-1">M <SortIcon col="metric_M" /></span>
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 cursor-pointer hover:text-slate-300" onClick={() => toggleSort('LD_ratio')}>
                  <span className="flex items-center gap-1">L/D <SortIcon col="LD_ratio" /></span>
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">CL</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">CD</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 cursor-pointer hover:text-slate-300" onClick={() => toggleSort('solve_wall_time_s')}>
                  <span className="flex items-center gap-1">Solve <SortIcon col="solve_wall_time_s" /></span>
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Strategy</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Node</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400"></th>
              </tr>
            </thead>
            <tbody>
              {paged.map(exp => (
                <tr key={exp.experiment_n} className="border-b border-slate-700/30 hover:bg-slate-800/40 transition-colors">
                  <td className="px-4 py-2.5 font-mono text-slate-300">{exp.experiment_n}</td>
                  <td className="px-4 py-2.5">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusColors[exp.status]}`}>
                      {exp.status}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-slate-400">{stageNames[exp.stage_reached]}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-300">{exp.parameter_name}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-400 font-mono">
                    {exp.old_value.toFixed(3)} → {exp.new_value.toFixed(3)}
                  </td>
                  <td className="px-4 py-2.5 font-mono">
                    {exp.metric_M !== null ? (
                      <span className={exp.status === 'KEPT' ? 'text-emerald-400 font-medium' : 'text-slate-300'}>
                        {exp.metric_M.toFixed(4)}
                      </span>
                    ) : <span className="text-slate-600">—</span>}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-slate-300">{exp.LD_ratio?.toFixed(2) ?? '—'}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-400">{exp.CL?.toFixed(4) ?? '—'}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-400">{exp.CD?.toFixed(5) ?? '—'}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-400">
                    {exp.solve_wall_time_s !== null ? `${exp.solve_wall_time_s.toFixed(0)}s` : '—'}
                  </td>
                  <td className="px-4 py-2.5 text-xs text-slate-400">{exp.strategy}</td>
                  <td className="px-4 py-2.5 text-xs text-slate-500 font-mono">{exp.node_id.split('-')[1]}</td>
                  <td className="px-4 py-2.5">
                    <button onClick={() => setSelectedExp(selectedExp?.experiment_n === exp.experiment_n ? null : exp)} className="text-slate-500 hover:text-slate-300">
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-700/50">
          <div className="text-xs text-slate-500">
            Showing {page * pageSize + 1}–{Math.min((page + 1) * pageSize, filtered.length)} of {filtered.length}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
              className="px-3 py-1 rounded text-xs bg-slate-700/50 text-slate-300 disabled:opacity-30 hover:bg-slate-700">Prev</button>
            <span className="text-xs text-slate-500">Page {page + 1} / {totalPages}</span>
            <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1}
              className="px-3 py-1 rounded text-xs bg-slate-700/50 text-slate-300 disabled:opacity-30 hover:bg-slate-700">Next</button>
          </div>
        </div>
      </div>

      {/* Experiment Detail Panel */}
      {selectedExp && (
        <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-bold text-white">Experiment #{selectedExp.experiment_n} — Detail</h4>
            <button onClick={() => setSelectedExp(null)} className="text-slate-500 hover:text-slate-300 text-xs">Close</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h5 className="text-xs font-semibold text-slate-400 mb-2 uppercase">Experiment</h5>
              <div className="space-y-1.5">
                <DetailRow label="Status" value={selectedExp.status} highlight={selectedExp.status === 'KEPT'} />
                <DetailRow label="Stage Reached" value={`${selectedExp.stage_reached} (${stageNames[selectedExp.stage_reached]})`} />
                <DetailRow label="Node" value={selectedExp.node_id} />
                <DetailRow label="Strategy" value={selectedExp.strategy} />
                <DetailRow label="Genome Gen" value={selectedExp.genome_generation.toString()} />
                <DetailRow label="Timestamp" value={new Date(selectedExp.timestamp).toLocaleString()} />
                <DetailRow label="Duration" value={`${selectedExp.duration_s}s`} />
              </div>
            </div>
            <div>
              <h5 className="text-xs font-semibold text-slate-400 mb-2 uppercase">Mutation</h5>
              <div className="space-y-1.5">
                <DetailRow label="Parameter" value={`${selectedExp.parameter_name} (${selectedExp.parameter_id})`} />
                <DetailRow label="Old Value" value={selectedExp.old_value.toFixed(4)} />
                <DetailRow label="New Value" value={selectedExp.new_value.toFixed(4)} />
                <DetailRow label="Delta" value={(selectedExp.new_value - selectedExp.old_value).toFixed(4)} />
              </div>
              <h5 className="text-xs font-semibold text-slate-400 mb-2 mt-4 uppercase">Provenance</h5>
              <div className="space-y-1.5">
                <DetailRow label="Geo SHA (before)" value={selectedExp.geometry_sha256_before.slice(0, 16) + '…'} mono />
                <DetailRow label="Geo SHA (after)" value={selectedExp.geometry_sha256_after.slice(0, 16) + '…'} mono />
                <DetailRow label="Mesh SHA" value={selectedExp.mesh_sha256.slice(0, 16) + '…'} mono />
                <DetailRow label="Results SHA" value={selectedExp.results_sha256.slice(0, 16) + '…'} mono />
              </div>
            </div>
            <div>
              <h5 className="text-xs font-semibold text-slate-400 mb-2 uppercase">Aerodynamics</h5>
              <div className="space-y-1.5">
                <DetailRow label="Composite M" value={selectedExp.metric_M?.toFixed(4) ?? '—'} highlight={selectedExp.status === 'KEPT'} />
                <DetailRow label="Best M at time" value={selectedExp.best_M_at_time.toFixed(4)} />
                <DetailRow label="CL" value={selectedExp.CL?.toFixed(4) ?? '—'} />
                <DetailRow label="CD" value={selectedExp.CD?.toFixed(5) ?? '—'} />
                <DetailRow label="CMy" value={selectedExp.CMy?.toFixed(4) ?? '—'} />
                <DetailRow label="L/D" value={selectedExp.LD_ratio?.toFixed(2) ?? '—'} />
                <DetailRow label="Cd_wave" value={selectedExp.cd_wave?.toFixed(5) ?? '—'} />
                <DetailRow label="Buffet α" value={selectedExp.buffet_onset_alpha?.toFixed(1) ?? '—'} />
              </div>
              <h5 className="text-xs font-semibold text-slate-400 mb-2 mt-4 uppercase">Mesh & Solve</h5>
              <div className="space-y-1.5">
                <DetailRow label="Cell Count" value={selectedExp.mesh_cell_count?.toLocaleString() ?? '—'} />
                <DetailRow label="Mesh Quality" value={selectedExp.mesh_quality_score?.toFixed(2) ?? '—'} />
                <DetailRow label="Solve Time" value={selectedExp.solve_wall_time_s !== null ? `${selectedExp.solve_wall_time_s.toFixed(1)}s` : '—'} />
                <DetailRow label="Residual Orders" value={selectedExp.residual_orders?.toFixed(1) ?? '—'} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DetailRow({ label, value, highlight, mono }: { label: string; value: string; highlight?: boolean; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-slate-500">{label}</span>
      <span className={`${highlight ? 'text-emerald-400 font-bold' : 'text-slate-300'} ${mono ? 'font-mono' : ''}`}>{value}</span>
    </div>
  );
}
