import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Flame, Snowflake, GitBranch, TrendingUp } from 'lucide-react';
import { knowledgeGraph, parameterInteractions } from '../data/mockData';

export default function KnowledgeGraph() {
  const topSensitivities = knowledgeGraph.slice(0, 10);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white">Knowledge Graph (Stage 7)</h3>
        <p className="text-sm text-slate-400 mt-1">
          Sensitivity distributions, parameter interactions, dead/hot zone detection. Updated after every experiment by KnowledgeGraphAgent.
          Surrogate model (GPR) active since experiment 50.
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50">
          <div className="text-xs text-slate-500 mb-1">Parameters Tracked</div>
          <div className="text-2xl font-bold text-white">{knowledgeGraph.length}</div>
        </div>
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50">
          <div className="text-xs text-slate-500 mb-1">Interactions Detected</div>
          <div className="text-2xl font-bold text-white">{parameterInteractions.length}</div>
        </div>
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50">
          <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Flame className="w-3 h-3 text-orange-400" /> Hot Zones</div>
          <div className="text-2xl font-bold text-orange-400">{knowledgeGraph.filter(k => k.hot_zone).length}</div>
        </div>
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50">
          <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Snowflake className="w-3 h-3 text-blue-400" /> Dead Zones</div>
          <div className="text-2xl font-bold text-blue-400">{knowledgeGraph.filter(k => k.dead_zone).length}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sensitivity Chart */}
        <div className="bg-slate-800/60 rounded-xl p-5 border border-slate-700/50">
          <h4 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" /> Parameter Sensitivity Rankings
          </h4>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={topSensitivities} layout="vertical" margin={{ left: 100 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis type="number" domain={[0, 1]} tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis dataKey="parameter_name" type="category" tick={{ fill: '#cbd5e1', fontSize: 11 }} width={95} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px', color: '#e2e8f0' }} />
              <Bar dataKey="sensitivity_score" radius={[0, 4, 4, 0]}>
                {topSensitivities.map((entry, idx) => (
                  <Cell key={idx} fill={
                    entry.hot_zone ? '#f97316' :
                    entry.sensitivity_score > 0.6 ? '#10b981' :
                    entry.sensitivity_score > 0.3 ? '#eab308' :
                    '#6b7280'
                  } />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
            <span className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded-sm bg-orange-500" /> Hot Zone</span>
            <span className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded-sm bg-emerald-500" /> High Sensitivity</span>
            <span className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded-sm bg-yellow-500" /> Medium</span>
            <span className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded-sm bg-gray-500" /> Low</span>
          </div>
        </div>

        {/* Interaction Scatter */}
        <div className="bg-slate-800/60 rounded-xl p-5 border border-slate-700/50">
          <h4 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-violet-400" /> Parameter Interactions
          </h4>
          <div className="space-y-3">
            {parameterInteractions.sort((a, b) => b.interaction_strength - a.interaction_strength).map((ia, idx) => {
              const paramA = knowledgeGraph.find(k => k.parameter_id === ia.param_a);
              const paramB = knowledgeGraph.find(k => k.parameter_id === ia.param_b);
              return (
                <div key={idx} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/30">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-slate-200">{paramA?.parameter_name}</span>
                      <span className="text-xs text-slate-500">↔</span>
                      <span className="text-xs font-medium text-slate-200">{paramB?.parameter_name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${ia.synergy ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                        {ia.synergy ? 'SYNERGY' : 'ANTI-SYNERGY'}
                      </span>
                      <span className="text-sm font-bold text-white">{ia.interaction_strength.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${ia.synergy ? 'bg-emerald-500' : 'bg-red-500'}`} 
                      style={{ width: `${ia.interaction_strength * 100}%` }} 
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Full Sensitivity Table */}
      <div className="bg-slate-800/60 rounded-xl border border-slate-700/50 overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-700/50">
          <h4 className="text-sm font-semibold text-slate-300">Complete Sensitivity Table</h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Rank</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Parameter</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Sensitivity</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Mean ΔM</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Std ΔM</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Samples</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Zone</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Direction</th>
              </tr>
            </thead>
            <tbody>
              {knowledgeGraph.map((entry) => (
                <tr key={entry.parameter_id} className="border-b border-slate-700/30 hover:bg-slate-800/40">
                  <td className="px-4 py-2.5 font-mono text-slate-400 text-center">#{entry.sensitivity_rank}</td>
                  <td className="px-4 py-2.5 text-slate-200 font-medium">{entry.parameter_name}</td>
                  <td className="px-4 py-2.5 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <div className="w-12 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${entry.sensitivity_score > 0.7 ? 'bg-emerald-500' : entry.sensitivity_score > 0.4 ? 'bg-amber-500' : 'bg-red-500'}`}
                          style={{ width: `${entry.sensitivity_score * 100}%` }} 
                        />
                      </div>
                      <span className="text-xs font-mono text-slate-300">{entry.sensitivity_score.toFixed(2)}</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-center text-slate-300">{entry.mean_delta_M.toFixed(4)}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-center text-slate-400">{entry.std_delta_M.toFixed(4)}</td>
                  <td className="px-4 py-2.5 text-xs text-center text-slate-400">{entry.sample_count}</td>
                  <td className="px-4 py-2.5 text-center">
                    {entry.hot_zone ? (
                      <span className="flex items-center justify-center gap-0.5 text-[10px] text-orange-400"><Flame className="w-3 h-3" /> HOT</span>
                    ) : entry.dead_zone ? (
                      <span className="flex items-center justify-center gap-0.5 text-[10px] text-blue-400"><Snowflake className="w-3 h-3" /> DEAD</span>
                    ) : (
                      <span className="text-[10px] text-slate-500">—</span>
                    )}
                  </td>
                  <td className="px-4 py-2.5 text-center text-xs">
                    {entry.optimal_direction === 'increase' ? (
                      <span className="text-emerald-400">↑ Increase</span>
                    ) : entry.optimal_direction === 'decrease' ? (
                      <span className="text-blue-400">↓ Decrease</span>
                    ) : (
                      <span className="text-slate-500">— Neutral</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Surrogate Model Status */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-3">Surrogate Model (GPR) — OI-001</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-800/50 rounded-lg p-3">
            <div className="text-xs text-slate-500 mb-1">Status</div>
            <div className="text-sm font-bold text-emerald-400">Active</div>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-3">
            <div className="text-xs text-slate-500 mb-1">Training Samples</div>
            <div className="text-sm font-bold text-white">150+</div>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-3">
            <div className="text-xs text-slate-500 mb-1">Prediction R²</div>
            <div className="text-sm font-bold text-emerald-400">0.82</div>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-3">
            <div className="text-xs text-slate-500 mb-1">Last Retrained</div>
            <div className="text-sm font-bold text-white">Exp #180</div>
          </div>
        </div>
        <p className="text-xs text-slate-500 mt-3">
          The Gaussian Process Regression surrogate was activated after 50 experiments (as specified in AGENTS.md). 
          It provides pre-mutation predictions to help guide the GeometryMutationAgent's parameter selection.
          Prediction API endpoint pending specification (OI-001).
        </p>
      </div>
    </div>
  );
}
