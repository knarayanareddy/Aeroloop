import { Radio, MapPin, Clock, Activity, Wifi, WifiOff } from 'lucide-react';
import { swarmNodes, runMetrics } from '../data/mockData';

const regionIcons: Record<string, string> = {
  PLANFORM_CORE: '✈️',
  TWIST: '🔄',
  THICKNESS: '📐',
  CAMBER: '🌊',
};

const stageNames = ['Init', 'Mutate', 'Mesh', 'Solve', 'Extract', 'Decide', 'Wiki', 'KG', 'GEP', 'Swarm'];

export default function Swarm() {
  const totalExps = swarmNodes.reduce((s, n) => s + n.experiments_completed, 0);
  const activeNodes = swarmNodes.filter(n => n.status === 'ACTIVE').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white flex items-center gap-2"><Radio className="w-5 h-5 text-blue-400" /> Swarm Coordination (Stage 9)</h3>
        <p className="text-sm text-slate-400 mt-1">
          Multi-node distributed optimisation. RULE-006: Non-overlapping region claims via Redis SETNX with TTL.
          RULE-010: Single solve lock per node. Heartbeat interval: 30s.
        </p>
      </div>

      {/* Swarm Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50 text-center">
          <div className="text-2xl font-bold text-emerald-400">{activeNodes}</div>
          <div className="text-xs text-slate-500">Active Nodes</div>
        </div>
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50 text-center">
          <div className="text-2xl font-bold text-white">{swarmNodes.length}</div>
          <div className="text-xs text-slate-500">Total Nodes</div>
        </div>
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50 text-center">
          <div className="text-2xl font-bold text-blue-400">{totalExps}</div>
          <div className="text-xs text-slate-500">Total Completed</div>
        </div>
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50 text-center">
          <div className="text-2xl font-bold text-violet-400">{runMetrics.best_M.toFixed(4)}</div>
          <div className="text-xs text-slate-500">Global Best M</div>
        </div>
        <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50 text-center">
          <div className="text-2xl font-bold text-amber-400">600s</div>
          <div className="text-xs text-slate-500">Claim TTL</div>
        </div>
      </div>

      {/* Node Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {swarmNodes.map(node => (
          <div key={node.node_id} className={`bg-slate-800/60 rounded-xl p-6 border ${
            node.status === 'ACTIVE' ? 'border-emerald-500/30' : 'border-slate-700/50'
          }`}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{regionIcons[node.region] || '🔧'}</span>
                <div>
                  <h4 className="font-bold text-white">{node.node_id}</h4>
                  <span className={`text-xs font-bold ${node.status === 'ACTIVE' ? 'text-emerald-400' : node.status === 'PAUSED' ? 'text-amber-400' : 'text-red-400'}`}>
                    {node.status}
                  </span>
                </div>
              </div>
              {node.status === 'ACTIVE' ? (
                <Wifi className="w-5 h-5 text-emerald-400" />
              ) : (
                <WifiOff className="w-5 h-5 text-red-400" />
              )}
            </div>

            {/* Region Badge */}
            <div className="mb-4">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
                <MapPin className="w-3 h-3 inline mr-1" />{node.region}
              </span>
            </div>

            {/* Node Metrics */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-slate-800/50 rounded-lg p-3">
                <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Activity className="w-3 h-3" /> Current Stage</div>
                <div className="text-sm font-bold text-white">{stageNames[node.current_stage]} (S{node.current_stage})</div>
              </div>
              <div className="bg-slate-800/50 rounded-lg p-3">
                <div className="text-xs text-slate-500 mb-1">Experiment</div>
                <div className="text-sm font-bold text-white">#{node.current_experiment}</div>
              </div>
              <div className="bg-slate-800/50 rounded-lg p-3">
                <div className="text-xs text-slate-500 mb-1">Completed</div>
                <div className="text-sm font-bold text-emerald-400">{node.experiments_completed}</div>
              </div>
              <div className="bg-slate-800/50 rounded-lg p-3">
                <div className="text-xs text-slate-500 mb-1">Best M Contribution</div>
                <div className="text-sm font-bold text-cyan-400">{node.best_M_contribution.toFixed(4)}</div>
              </div>
            </div>

            {/* Heartbeat & Claim Info */}
            <div className="flex items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-700/30">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Last HB: {new Date(node.last_heartbeat).toLocaleTimeString()}
              </span>
              <span>
                Claimed: {new Date(node.claimed_at).toLocaleTimeString()} | TTL: {node.claim_ttl_s}s
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Region Map */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-4">Design Region Allocation</h4>
        <p className="text-xs text-slate-400 mb-4">
          RULE-006: Nodes claim non-overlapping design regions via atomic Redis SETNX before writing wing.geo.
          Region claims use TTL (default: 600s) and are renewed on every heartbeat.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {swarmNodes.map(node => {
            const regionParams = {
              PLANFORM_CORE: ['root_chord', 'tip_chord', 'semi_span', 'sweep_angle', 'taper_ratio'],
              TWIST: ['twist_root', 'twist_tip', 'washout'],
              THICKNESS: ['thickness_root', 'thickness_tip'],
              CAMBER: ['camber_root', 'camber_tip', 'camber_pos_root', 'camber_pos_tip'],
            };
            const params = regionParams[node.region as keyof typeof regionParams] || [];
            return (
              <div key={node.region} className="bg-slate-800/50 rounded-lg p-4 border border-blue-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold text-blue-400">{node.region.replace(/_/g, ' ')}</span>
                  <span className="text-lg">{regionIcons[node.region]}</span>
                </div>
                <div className="text-xs text-slate-400 mb-1">Claimed by: <span className="text-slate-200">{node.node_id}</span></div>
                <div className="text-xs text-slate-400 mb-3">Parameters:</div>
                <div className="space-y-1">
                  {params.map(p => (
                    <div key={p} className="text-xs text-slate-500 font-mono flex items-center gap-1">
                      <div className={`w-1.5 h-1.5 rounded-full ${node.status === 'ACTIVE' ? 'bg-emerald-400' : 'bg-red-400'}`} />
                      {p}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Swarm Protocol Details */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-4">Swarm Protocol Details</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="text-xs font-semibold text-slate-400 mb-2 uppercase">Redis Keys</h5>
            <div className="space-y-2 font-mono text-xs">
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-red-400">aeroloop:run:{'{run_id}'}:global_best_M</span>
                <span className="text-slate-500 ml-2">→ {runMetrics.best_M.toFixed(4)}</span>
              </div>
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-red-400">aeroloop:run:{'{run_id}'}:region:{'{region}'}</span>
                <span className="text-slate-500 ml-2">→ node_id (SETNX)</span>
              </div>
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-red-400">aeroloop:run:{'{run_id}'}:node:{'{node_id}'}:solve_lock</span>
                <span className="text-slate-500 ml-2">→ exclusive lock</span>
              </div>
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-red-400">aeroloop:run:{'{run_id}'}:node:{'{node_id}'}:heartbeat</span>
                <span className="text-slate-500 ml-2">→ timestamp</span>
              </div>
            </div>
          </div>
          <div>
            <h5 className="text-xs font-semibold text-slate-400 mb-2 uppercase">API Endpoints</h5>
            <div className="space-y-2 font-mono text-xs">
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-emerald-400">POST</span> <span className="text-slate-300">/api/v1/swarm/register</span>
              </div>
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-blue-400">PATCH</span> <span className="text-slate-300">/api/v1/swarm/heartbeat</span>
              </div>
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-emerald-400">POST</span> <span className="text-slate-300">/api/v1/swarm/experiment</span>
              </div>
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-blue-400">GET</span> <span className="text-slate-300">/api/v1/swarm/global-best</span>
              </div>
              <div className="bg-slate-800/50 rounded p-2 border border-slate-700/30">
                <span className="text-amber-400">DELETE</span> <span className="text-slate-300">/api/v1/swarm/deregister</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
