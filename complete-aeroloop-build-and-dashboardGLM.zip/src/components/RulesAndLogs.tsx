import { useState } from 'react';
import { Shield, FileText, AlertCircle, CheckCircle2, BookOpen, GitCommit } from 'lucide-react';
import { constitutionalRules, eventLog, decisionLog, gitLog, wikiArticles } from '../data/mockData';

// ═══════════════════════════════════════════════════════════════
// CONSTITUTIONAL RULES TAB
// ═══════════════════════════════════════════════════════════════

function RulesTab() {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white flex items-center gap-2"><Shield className="w-5 h-5 text-amber-400" /> Constitutional Law — Inviolable Rules</h3>
        <p className="text-sm text-slate-400 mt-1">
          These rules are constitutional. No agent, no stage requirement, and no operator command may override them.
          Violations detectable at runtime must halt the loop immediately and emit a LOOP_HALT event.
        </p>
      </div>

      <div className="space-y-4">
        {constitutionalRules.map(rule => (
          <div key={rule.id} className={`bg-slate-800/60 rounded-xl p-5 border ${
            rule.status === 'enforced' ? 'border-emerald-500/30' : rule.status === 'violated' ? 'border-red-500/30' : 'border-slate-700/50'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                {rule.status === 'enforced' ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                )}
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-xs text-amber-400 font-bold">{rule.id}</span>
                    <span className="text-sm font-bold text-white">{rule.title}</span>
                  </div>
                  <p className="text-sm text-slate-400 mb-2">{rule.description}</p>
                  <p className="text-xs text-slate-500">{rule.details}</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-bold border flex-shrink-0 ${
                rule.status === 'enforced' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-red-500/20 text-red-400 border-red-500/30'
              }`}>
                {rule.status.toUpperCase()}
              </span>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-700/30 flex items-center justify-between text-xs text-slate-500">
              <span>Last checked: {new Date(rule.last_checked).toLocaleString()}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Commit Format Reference */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-3">Git Commit Formats (RULE-060 / RULE-061)</h4>
        <div className="space-y-4">
          <div>
            <div className="text-xs text-slate-400 mb-1 font-semibold">KEEP Commit:</div>
            <code className="block text-xs text-emerald-400 bg-slate-900/50 p-3 rounded-lg border border-slate-700/30 break-all">
              exp({'{N}'}): M={'{M_new:.4f}'} delta={'{delta_M:+.4f}'} L/D={'{ld:.2f}'} [KEEP] mutation: {'{parameter_id}'}={'{old_val}'}→{'{new_val}'} mesh: {'{cell_count}'} cells | solve: {'{wall_time_s:.1f}'}s | convg: {'{residual_orders:.1f}'}ord
            </code>
          </div>
          <div>
            <div className="text-xs text-slate-400 mb-1 font-semibold">GEP Commit (RULE-061):</div>
            <code className="block text-xs text-orange-400 bg-slate-900/50 p-3 rounded-lg border border-slate-700/30">
              chore(gep): generation {'{N}'} evolved at exp {'{experiment_n}'} | run_id: {'{run_id}'} | fitness_before → fitness_after
            </code>
          </div>
          <div>
            <div className="text-xs text-slate-400 mb-1 font-semibold">Wiki Commit (RULE-061):</div>
            <code className="block text-xs text-pink-400 bg-slate-900/50 p-3 rounded-lg border border-slate-700/30">
              docs(wiki): batch {'{start_n}'}–{'{end_n}'} compiled | {'{n}'} articles | run_id: {'{run_id}'}
            </code>
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// EVENT LOG TAB
// ═══════════════════════════════════════════════════════════════

function EventsTab() {
  const severityColors: Record<string, string> = {
    info: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
    warning: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    error: 'text-red-400 bg-red-500/10 border-red-500/30',
    critical: 'text-red-500 bg-red-600/10 border-red-600/30',
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white flex items-center gap-2"><FileText className="w-5 h-5 text-blue-400" /> Event Log (GLOBAL-LOG-001)</h3>
        <p className="text-sm text-slate-400 mt-1">
          Structured event stream from all agents. Events emitted via Redis pub/sub and persisted to decision_log.jsonl.
        </p>
      </div>

      <div className="space-y-3">
        {eventLog.map((event, idx) => (
          <div key={idx} className={`rounded-lg p-4 border ${severityColors[event.severity]}`}>
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono text-xs font-bold">{event.event_type}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${severityColors[event.severity]}`}>
                    {event.severity.toUpperCase()}
                  </span>
                </div>
                <p className="text-sm text-slate-300">{event.message}</p>
                <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                  <span>Source: {event.source}</span>
                  {event.details && (
                    <span className="font-mono text-slate-600">
                      {JSON.stringify(event.details)}
                    </span>
                  )}
                </div>
              </div>
              <span className="text-xs text-slate-500 flex-shrink-0">{new Date(event.timestamp).toLocaleString()}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// DECISION LOG TAB
// ═══════════════════════════════════════════════════════════════

function DecisionsTab() {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white">Decision Log</h3>
        <p className="text-sm text-slate-400 mt-1">
          Keep/Revert decisions from the last 50 experiments. RULE-008: KEEP iff M_new &gt; M_best (beat-the-best).
        </p>
      </div>

      <div className="bg-slate-800/60 rounded-xl border border-slate-700/50 overflow-hidden">
        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-slate-800">
              <tr className="border-b border-slate-700/50">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Time</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Exp #</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Decision</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Reason</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">M</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">Best M</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400">ΔM</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Parameter</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400">Strategy</th>
              </tr>
            </thead>
            <tbody>
              {decisionLog.map((d, idx) => (
                <tr key={idx} className="border-b border-slate-700/30 hover:bg-slate-800/40">
                  <td className="px-4 py-2 text-xs text-slate-500">{new Date(d.timestamp).toLocaleTimeString()}</td>
                  <td className="px-4 py-2 text-center font-mono text-slate-300">{d.experiment_n}</td>
                  <td className="px-4 py-2 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      d.decision === 'KEEP' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-600/20 text-slate-400 border-slate-600/30'
                    }`}>
                      {d.decision}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-xs text-slate-400">{d.reason}</td>
                  <td className="px-4 py-2 text-center font-mono text-xs text-slate-300">{d.metric_M.toFixed(4)}</td>
                  <td className="px-4 py-2 text-center font-mono text-xs text-slate-400">{d.best_M.toFixed(4)}</td>
                  <td className={`px-4 py-2 text-center font-mono text-xs ${d.delta_M > 0 ? 'text-emerald-400' : d.delta_M < 0 ? 'text-red-400' : 'text-slate-500'}`}>
                    {d.delta_M > 0 ? '+' : ''}{d.delta_M.toFixed(4)}
                  </td>
                  <td className="px-4 py-2 text-xs text-slate-300">{d.parameter_id}</td>
                  <td className="px-4 py-2 text-xs text-slate-400">{d.strategy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// GIT LOG TAB
// ═══════════════════════════════════════════════════════════════

function GitLogTab() {
  const typeColors: Record<string, string> = {
    KEEP: 'text-emerald-400',
    GEP: 'text-orange-400',
    WIKI: 'text-pink-400',
    initial: 'text-blue-400',
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white flex items-center gap-2"><GitCommit className="w-5 h-5 text-emerald-400" /> Git Log</h3>
        <p className="text-sm text-slate-400 mt-1">
          RULE-003: KEEP commits only. REVERT produces NO commit (only git checkout geometry/wing.geo).
          Pre-commit hook enforces one-mutable-file law. Commit-msg hook enforces format (RULE-060).
        </p>
      </div>

      <div className="space-y-2">
        {gitLog.slice().reverse().map((entry, idx) => (
          <div key={idx} className="bg-slate-800/60 rounded-lg p-4 border border-slate-700/50 hover:bg-slate-800/80 transition-colors">
            <div className="flex items-start gap-3">
              <div className="flex flex-col items-center">
                <div className="w-3 h-3 rounded-full bg-slate-600 border-2 border-slate-500 mt-1" />
                {idx < gitLog.length - 1 && <div className="w-0.5 h-full bg-slate-700 mt-1" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono text-xs text-amber-400 font-bold">{entry.hash}</span>
                  <span className={`text-xs font-bold ${typeColors[entry.type]}`}>[{entry.type}]</span>
                  <span className="text-xs text-slate-500">{entry.author}</span>
                  <span className="text-xs text-slate-600 ml-auto">{new Date(entry.timestamp).toLocaleString()}</span>
                </div>
                <p className="text-xs text-slate-300 font-mono break-all leading-relaxed">{entry.message}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// WIKI TAB
// ═══════════════════════════════════════════════════════════════

function WikiTab() {
  const typeIcons: Record<string, string> = {
    sensitivity: '📊',
    batch_summary: '📋',
    interaction: '🔗',
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white flex items-center gap-2"><BookOpen className="w-5 h-5 text-pink-400" /> Wiki Compilation (Stage 6)</h3>
        <p className="text-sm text-slate-400 mt-1">
          Triggered every 10 experiments. Compiles sensitivity analysis, batch summaries, and interaction articles.
          Wiki commit format: docs(wiki): batch start–end compiled | n articles (RULE-061).
        </p>
      </div>

      <div className="space-y-3">
        {wikiArticles.map(article => (
          <div key={article.id} className="bg-slate-800/60 rounded-lg p-4 border border-slate-700/50 hover:bg-slate-800/80 transition-colors">
            <div className="flex items-start gap-3">
              <span className="text-xl">{typeIcons[article.type]}</span>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium text-white">{article.title}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    article.type === 'sensitivity' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                    article.type === 'batch_summary' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                    'bg-violet-500/20 text-violet-400 border-violet-500/30'
                  }`}>
                    {article.type.replace(/_/g, ' ')}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mb-1">{article.content_summary}</p>
                <div className="flex items-center gap-3 text-xs text-slate-500">
                  <span>Experiments: {article.experiment_range}</span>
                  <span>Created: {new Date(article.created_at).toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// MAIN EXPORT — Rules & Logs container with sub-tabs
// ═══════════════════════════════════════════════════════════════

export default function RulesAndLogs() {
  const [subTab, setSubTab] = useState<'rules' | 'events' | 'decisions' | 'gitlog' | 'wiki'>('rules');

  const tabs = [
    { id: 'rules' as const, label: 'Constitutional Rules', icon: <Shield className="w-4 h-4" /> },
    { id: 'events' as const, label: 'Event Log', icon: <FileText className="w-4 h-4" /> },
    { id: 'decisions' as const, label: 'Decision Log', icon: <AlertCircle className="w-4 h-4" /> },
    { id: 'gitlog' as const, label: 'Git Log', icon: <GitCommit className="w-4 h-4" /> },
    { id: 'wiki' as const, label: 'Wiki Articles', icon: <BookOpen className="w-4 h-4" /> },
  ];

  return (
    <div>
      <div className="flex items-center gap-1 mb-6 bg-slate-800/60 rounded-xl p-1.5 border border-slate-700/50 overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setSubTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
              subTab === tab.id
                ? 'bg-slate-700 text-white'
                : 'text-slate-400 hover:text-slate-300 hover:bg-slate-700/50'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>
      {subTab === 'rules' && <RulesTab />}
      {subTab === 'events' && <EventsTab />}
      {subTab === 'decisions' && <DecisionsTab />}
      {subTab === 'gitlog' && <GitLogTab />}
      {subTab === 'wiki' && <WikiTab />}
    </div>
  );
}
