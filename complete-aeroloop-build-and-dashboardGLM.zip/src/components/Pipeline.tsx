import { CheckCircle2, Circle, Loader2, AlertTriangle, SkipForward, ArrowRight } from 'lucide-react';
import { currentPipeline, runMetrics } from '../data/mockData';

const stageColors: Record<string, string> = {
  completed: 'border-emerald-500/50 bg-emerald-500/10',
  active: 'border-blue-500/50 bg-blue-500/10 animate-pulse',
  pending: 'border-slate-600/50 bg-slate-800/50',
  failed: 'border-red-500/50 bg-red-500/10',
  skipped: 'border-slate-700/50 bg-slate-900/30',
};

const stageIcons: Record<string, React.ReactNode> = {
  completed: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
  active: <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />,
  pending: <Circle className="w-5 h-5 text-slate-500" />,
  failed: <AlertTriangle className="w-5 h-5 text-red-400" />,
  skipped: <SkipForward className="w-5 h-5 text-slate-600" />,
};

const agentColors: Record<string, string> = {
  LoopOrchestrator: 'text-cyan-400',
  GeometryMutationAgent: 'text-violet-400',
  BoundsCheckAgent: 'text-violet-300',
  MeshAgent: 'text-amber-400',
  MeshQualityAgent: 'text-amber-300',
  SolverAgent: 'text-red-400',
  ExtractionAgent: 'text-teal-400',
  MetricAgent: 'text-teal-300',
  KeepRevertAgent: 'text-emerald-400',
  WikiCompilerAgent: 'text-pink-400',
  KnowledgeGraphAgent: 'text-indigo-400',
  SurrogateAgent: 'text-indigo-300',
  GEPOrchestrator: 'text-orange-400',
  SwarmSyncAgent: 'text-blue-400',
};

export default function Pipeline() {
  const currentExp = runMetrics.total_experiments;
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800/80 to-slate-900/80 rounded-xl p-5 border border-slate-700/50">
        <h3 className="text-lg font-bold text-white">Pipeline Stage Monitor</h3>
        <p className="text-sm text-slate-400 mt-1">
          Current Experiment: <span className="text-white font-medium">#{currentExp}</span> — Stage 3 (CFD Solve) in progress
        </p>
        <p className="text-xs text-slate-500 mt-1">
          RULE-007: Stages must traverse 0→1→2→3→4→5 in order. No skips except defined short-circuits.
        </p>
      </div>

      {/* Stage Flow */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-4">Core Pipeline (Stages 0–5)</h4>
        <div className="flex items-center gap-2 overflow-x-auto pb-4">
          {currentPipeline.filter(s => s.id <= 5).map((stage, idx) => (
            <div key={stage.id} className="flex items-center">
              <div className={`min-w-[180px] rounded-lg p-4 border-2 ${stageColors[stage.status]} transition-all`}>
                <div className="flex items-center gap-2 mb-2">
                  {stageIcons[stage.status]}
                  <span className="text-xs font-bold text-slate-300">Stage {stage.id}</span>
                </div>
                <div className="text-sm font-medium text-white mb-1">{stage.name}</div>
                <div className={`text-xs ${agentColors[stage.agent] || 'text-slate-400'}`}>{stage.agent}</div>
                {stage.duration_ms > 0 && (
                  <div className="text-xs text-slate-500 mt-2">
                    {stage.duration_ms < 1000 ? `${stage.duration_ms}ms` : `${(stage.duration_ms / 1000).toFixed(1)}s`}
                  </div>
                )}
                {stage.status === 'active' && (
                  <div className="mt-2 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full animate-[pulse_2s_ease-in-out_infinite]" style={{ width: '60%' }} />
                  </div>
                )}
              </div>
              {idx < 5 && (
                <ArrowRight className="w-5 h-5 text-slate-600 flex-shrink-0 mx-1" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Background Stages */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-4">Background Stages (6–9) — Non-blocking</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {currentPipeline.filter(s => s.id >= 6).map(stage => (
            <div key={stage.id} className={`rounded-lg p-4 border-2 ${stageColors[stage.status]}`}>
              <div className="flex items-center gap-2 mb-2">
                {stageIcons[stage.status]}
                <span className="text-xs font-bold text-slate-300">Stage {stage.id}</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-700 text-slate-400">BG</span>
              </div>
              <div className="text-sm font-medium text-white mb-1">{stage.name}</div>
              <div className={`text-xs ${agentColors[stage.agent] || 'text-slate-400'}`}>{stage.agent}</div>
              <div className="text-xs text-slate-500 mt-2">{stage.description}</div>
              {stage.id === 8 && (
                <div className="mt-2 text-xs text-orange-400/70">
                  Triggers every 500 experiments (next: exp-500)
                </div>
              )}
              {stage.id === 6 && (
                <div className="mt-2 text-xs text-pink-400/70">
                  Triggers every 10 experiments
                </div>
              )}
              {stage.id === 7 && (
                <div className="mt-2 text-xs text-indigo-400/70">
                  Triggers after every experiment
                </div>
              )}
              {stage.id === 9 && (
                <div className="mt-2 text-xs text-blue-400/70">
                  Heartbeat every 30s
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Failure Short-Circuits */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-4">Failure Short-Circuit Paths</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ShortCircuitCard from="Stage 1" to="Stage 5" label="BOUNDS_FAIL" description="Parameter value outside hard bounds → REVERT" color="violet" />
          <ShortCircuitCard from="Stage 2" to="Stage 5" label="MESH_FAIL" description="GMSH failure or quality below threshold → REVERT" color="amber" />
          <ShortCircuitCard from="Stage 3" to="Stage 5" label="SOLVE_TIMEOUT / SOLVE_FAIL" description="Kill timer or SU2 divergence → REVERT" color="red" />
        </div>
        <p className="text-xs text-slate-500 mt-3">
          All short-circuits terminate at Stage 5 (Keep/Revert Decision) with a REVERT outcome. 
          Working tree is always restored via <code className="text-slate-400">git checkout geometry/wing.geo</code> (RULE-003).
        </p>
      </div>

      {/* Agent Registry Summary */}
      <div className="bg-slate-800/60 rounded-xl p-6 border border-slate-700/50">
        <h4 className="text-sm font-semibold text-slate-300 mb-4">Agent Registry</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { name: 'LoopOrchestrator', role: 'Orchestrator', stage: '0', desc: 'Stage state machine. Owns core BullMQ queue.' },
            { name: 'SwarmOrchestrator', role: 'Orchestrator', stage: '9', desc: 'Multi-node region claims and heartbeats.' },
            { name: 'GEPOrchestrator', role: 'Orchestrator', stage: '8', desc: 'Genome evolution lifecycle. Blocks queue during evolution.' },
            { name: 'GeometryMutationAgent', role: 'Core', stage: '1', desc: 'THE ONLY agent allowed to write wing.geo.' },
            { name: 'BoundsCheckAgent', role: 'Core', stage: '1', desc: 'Validates parameter values against registry.' },
            { name: 'MeshAgent', role: 'Core', stage: '2', desc: 'Runs GMSH pipeline. Uploads mesh to S3.' },
            { name: 'MeshQualityAgent', role: 'Core', stage: '2', desc: 'Validates mesh against quality thresholds.' },
            { name: 'SolverAgent', role: 'Core', stage: '3', desc: 'Runs SU2 with dual kill timers. Uploads results.' },
            { name: 'ExtractionAgent', role: 'Core', stage: '4', desc: 'Parses SU2 outputs. Computes CL, CD, L/D.' },
            { name: 'MetricAgent', role: 'Core', stage: '4', desc: 'Computes composite M. Pure function.' },
            { name: 'KeepRevertAgent', role: 'Core', stage: '5', desc: 'Applies RULE-003 and RULE-008. Writes DB record.' },
            { name: 'WikiCompilerAgent', role: 'Background', stage: '6', desc: 'Compiles sensitivity & batch summary articles.' },
            { name: 'KnowledgeGraphAgent', role: 'Background', stage: '7', desc: 'Updates sensitivities, discovers interactions.' },
            { name: 'SurrogateAgent', role: 'Background', stage: '7', desc: 'Trains GPR surrogate model (after 50 exp).' },
            { name: 'SwarmSyncAgent', role: 'Background', stage: '9', desc: 'Heartbeat, push records, pull global_best.' },
          ].map(agent => (
            <div key={agent.name} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/30">
              <div className="flex items-center justify-between mb-1">
                <span className={`text-xs font-medium ${agentColors[agent.name] || 'text-slate-400'}`}>{agent.name}</span>
                <div className="flex gap-1">
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-700 text-slate-400">S{agent.stage}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                    agent.role === 'Orchestrator' ? 'bg-cyan-900/30 text-cyan-400' :
                    agent.role === 'Core' ? 'bg-emerald-900/30 text-emerald-400' :
                    'bg-slate-700/50 text-slate-400'
                  }`}>{agent.role}</span>
                </div>
              </div>
              <p className="text-xs text-slate-500">{agent.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ShortCircuitCard({ from, to, label, description, color }: { from: string; to: string; label: string; description: string; color: string }) {
  const colorClasses: Record<string, string> = {
    violet: 'border-violet-500/30 bg-violet-500/5',
    amber: 'border-amber-500/30 bg-amber-500/5',
    red: 'border-red-500/30 bg-red-500/5',
  };
  return (
    <div className={`rounded-lg p-4 border ${colorClasses[color]}`}>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xs font-bold text-slate-300">{from}</span>
        <ArrowRight className="w-3 h-3 text-slate-500" />
        <span className="text-xs font-bold text-slate-300">{to}</span>
      </div>
      <div className="text-sm font-medium text-white mb-1">{label}</div>
      <p className="text-xs text-slate-400">{description}</p>
    </div>
  );
}
