import { useState } from 'react';
import {
  LayoutDashboard,
  GitBranch,
  FlaskConical,
  Triangle,
  Brain,
  Dna,
  Radio,
  Shield,
  Plane,
  Menu,
  X,
} from 'lucide-react';
import Overview from './components/Overview';
import Pipeline from './components/Pipeline';
import Experiments from './components/Experiments';
import Geometry from './components/Geometry';
import KnowledgeGraphComp from './components/KnowledgeGraph';
import GEP from './components/GEP';
import Swarm from './components/Swarm';
import RulesAndLogs from './components/RulesAndLogs';
import { runConfig, runMetrics } from './data/mockData';

type TabId = 'overview' | 'pipeline' | 'experiments' | 'geometry' | 'knowledge' | 'gep' | 'swarm' | 'rules';

const navItems: { id: TabId; label: string; icon: React.ReactNode; description: string }[] = [
  { id: 'overview', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" />, description: 'KPIs, metric trajectory, health' },
  { id: 'pipeline', label: 'Pipeline', icon: <GitBranch className="w-4 h-4" />, description: 'Stage 0–9 monitor' },
  { id: 'experiments', label: 'Experiments', icon: <FlaskConical className="w-4 h-4" />, description: 'Filterable experiment table' },
  { id: 'geometry', label: 'Geometry', icon: <Triangle className="w-4 h-4" />, description: 'Parameter registry & bounds' },
  { id: 'knowledge', label: 'Knowledge Graph', icon: <Brain className="w-4 h-4" />, description: 'Sensitivities & interactions' },
  { id: 'gep', label: 'GEP Genome', icon: <Dna className="w-4 h-4" />, description: 'Genome evolver (Stage 8)' },
  { id: 'swarm', label: 'Swarm', icon: <Radio className="w-4 h-4" />, description: 'Multi-node coordination' },
  { id: 'rules', label: 'Rules & Logs', icon: <Shield className="w-4 h-4" />, description: 'Constitutional law & event logs' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 flex">
      {/* Sidebar overlay for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-slate-900/95 border-r border-slate-800 z-50 flex flex-col transition-transform duration-200 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}>
        {/* Logo */}
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Plane className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">AeroLoop</h1>
              <p className="text-[10px] text-slate-500 font-medium">CFD Wing Optimisation</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => { setActiveTab(item.id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                activeTab === item.id
                  ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                  : 'text-slate-400 hover:text-slate-300 hover:bg-slate-800/50 border border-transparent'
              }`}
            >
              {item.icon}
              <div className="text-left">
                <div className="font-medium">{item.label}</div>
                <div className="text-[10px] text-slate-500">{item.description}</div>
              </div>
            </button>
          ))}
        </nav>

        {/* Run Status Footer */}
        <div className="p-3 border-t border-slate-800">
          <div className="bg-slate-800/50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-500">Run Status</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                RUNNING
              </span>
            </div>
            <div className="text-xs text-slate-400 font-mono">{runConfig.run_id.slice(0, 16)}…</div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-xs text-slate-500">Best M</span>
              <span className="text-sm font-bold text-emerald-400">{runMetrics.best_M.toFixed(4)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500">Experiments</span>
              <span className="text-xs font-bold text-white">{runMetrics.total_experiments}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500">Kept</span>
              <span className="text-xs font-bold text-emerald-400">{runMetrics.kept_count} ({((runMetrics.kept_count / runMetrics.total_experiments) * 100).toFixed(1)}%)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500">Consec Fails</span>
              <span className={`text-xs font-bold ${runMetrics.consecutive_fails >= 3 ? 'text-red-400' : 'text-slate-300'}`}>
                {runMetrics.consecutive_fails}/3
              </span>
            </div>
          </div>
          <div className="text-center mt-2">
            <span className="text-[10px] text-slate-600">Spec v1.0 — Built from Aeroloopspecnew.md</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur border-b border-slate-800 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-slate-400 hover:text-white">
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <div>
              <h2 className="text-sm font-bold text-white">
                {navItems.find(n => n.id === activeTab)?.label}
              </h2>
              <p className="text-[10px] text-slate-500">
                {navItems.find(n => n.id === activeTab)?.description} — {runConfig.label}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-3 text-xs text-slate-500">
              <span>Mach {runConfig.mach}</span>
              <span>α {runConfig.alpha}°</span>
              <span>Re {runConfig.reynolds.toExponential(1)}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs text-emerald-400 font-medium">Live</span>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-4 md:p-6 max-w-[1600px] mx-auto">
          {activeTab === 'overview' && <Overview />}
          {activeTab === 'pipeline' && <Pipeline />}
          {activeTab === 'experiments' && <Experiments />}
          {activeTab === 'geometry' && <Geometry />}
          {activeTab === 'knowledge' && <KnowledgeGraphComp />}
          {activeTab === 'gep' && <GEP />}
          {activeTab === 'swarm' && <Swarm />}
          {activeTab === 'rules' && <RulesAndLogs />}
        </div>
      </main>
    </div>
  );
}
