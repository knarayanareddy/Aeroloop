import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { Flame, Snowflake, Link2, TrendingUp, AlertTriangle } from 'lucide-react';
import { KNOWLEDGE_NODES, KNOWLEDGE_EDGES } from '../data/mockData';

const KnowledgeGraph: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [view, setView] = useState<'graph' | 'sensitivity' | 'radar'>('graph');

  const selectedNodeData = selectedNode ? KNOWLEDGE_NODES.find(n => n.parameter_id === selectedNode) : null;
  const relatedEdges = selectedNode ? KNOWLEDGE_EDGES.filter(e => e.source === selectedNode || e.target === selectedNode) : [];

  // Sensitivity chart data
  const sensitivityData = KNOWLEDGE_NODES
    .sort((a, b) => b.sensitivity - a.sensitivity)
    .map(n => ({ name: n.parameter_id.replace(/_/g, ' '), sensitivity: n.sensitivity, impact: n.impact_on_metric }));

  // Radar data for selected node
  const radarData = selectedNodeData ? [
    { metric: 'Sensitivity', value: selectedNodeData.sensitivity },
    { metric: 'Impact', value: selectedNodeData.impact_on_metric * 20 },
    { metric: 'Experiments', value: selectedNodeData.experiment_count / 5 },
    { metric: 'Interactions', value: selectedNodeData.interactions.length * 15 },
    { metric: 'Confidence', value: Math.min(1, selectedNodeData.experiment_count / 50) },
  ] : [];

  // Positions for graph visualization
  const nodePositions = KNOWLEDGE_NODES.map((node, i) => {
    const angle = (i / KNOWLEDGE_NODES.length) * 2 * Math.PI - Math.PI / 2;
    const radius = 120;
    return { ...node, x: 200 + radius * Math.cos(angle), y: 200 + radius * Math.sin(angle) };
  });

  return (
    <div className="space-y-6 max-w-[1600px]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Knowledge Graph</h2>
          <p className="text-slate-500 mt-1">Parameter sensitivity analysis, interaction discovery, and dead/hot zone classification</p>
        </div>
        <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
          {(['graph', 'sensitivity', 'radar'] as const).map(v => (
            <button key={v} onClick={() => setView(v)} className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${view === v ? 'bg-white shadow text-blue-600' : 'text-slate-500'}`}>
              {v === 'graph' ? 'Graph View' : v === 'sensitivity' ? 'Sensitivity Chart' : 'Radar Analysis'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Visualization */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5">
          {view === 'graph' && (
            <div>
              <h3 className="font-semibold text-slate-900 mb-3">Parameter Interaction Graph</h3>
              <div className="relative" style={{ height: 450 }}>
                <svg width="100%" height="100%" viewBox="0 0 400 420">
                  {/* Edges */}
                  {KNOWLEDGE_EDGES.map((edge, i) => {
                    const source = nodePositions.find(n => n.parameter_id === edge.source);
                    const target = nodePositions.find(n => n.parameter_id === edge.target);
                    if (!source || !target) return null;
                    return (
                      <g key={i}>
                        <line
                          x1={source.x} y1={source.y} x2={target.x} y2={target.y}
                          stroke={selectedNode && (edge.source === selectedNode || edge.target === selectedNode) ? '#3b82f6' : '#cbd5e1'}
                          strokeWidth={edge.interaction_strength * 3}
                          opacity={selectedNode && (edge.source === selectedNode || edge.target === selectedNode) ? 0.8 : 0.3}
                        />
                        <text
                          x={(source.x + target.x) / 2}
                          y={(source.y + target.y) / 2 - 5}
                          textAnchor="middle"
                          fontSize="6"
                          fill={selectedNode ? '#3b82f6' : '#94a3b8'}
                        >
                          {edge.interaction_strength.toFixed(2)}
                        </text>
                      </g>
                    );
                  })}
                  {/* Nodes */}
                  {nodePositions.map(node => {
                    const isSelected = selectedNode === node.parameter_id;
                    const nodeRadius = 8 + node.sensitivity * 15;
                    return (
                      <g key={node.parameter_id} onClick={() => setSelectedNode(isSelected ? null : node.parameter_id)} className="cursor-pointer">
                        <circle
                          cx={node.x} cy={node.y} r={nodeRadius}
                          fill={node.hot_zone ? '#ef4444' : node.dead_zone ? '#94a3b8' : '#3b82f6'}
                          fillOpacity={isSelected ? 0.9 : 0.4}
                          stroke={isSelected ? '#1e40af' : node.hot_zone ? '#ef4444' : node.dead_zone ? '#94a3b8' : '#3b82f6'}
                          strokeWidth={isSelected ? 3 : 1.5}
                        />
                        <text x={node.x} y={node.y + nodeRadius + 12} textAnchor="middle" fontSize="7" fill="#334155" fontWeight="500">
                          {node.parameter_id.replace(/_/g, ' ')}
                        </text>
                      </g>
                    );
                  })}
                  {/* Legend */}
                  <g transform="translate(10, 400)">
                    <circle cx="8" cy="5" r="5" fill="#ef4444" fillOpacity="0.5" stroke="#ef4444" strokeWidth="1" />
                    <text x="18" y="8" fontSize="7" fill="#64748b">Hot Zone</text>
                    <circle cx="78" cy="5" r="5" fill="#3b82f6" fillOpacity="0.5" stroke="#3b82f6" strokeWidth="1" />
                    <text x="88" y="8" fontSize="7" fill="#64748b">Active</text>
                    <circle cx="138" cy="5" r="5" fill="#94a3b8" fillOpacity="0.5" stroke="#94a3b8" strokeWidth="1" />
                    <text x="148" y="8" fontSize="7" fill="#64748b">Dead Zone</text>
                  </g>
                </svg>
              </div>
            </div>
          )}
          {view === 'sensitivity' && (
            <div>
              <h3 className="font-semibold text-slate-900 mb-3">Parameter Sensitivity Ranking</h3>
              <ResponsiveContainer width="100%" height={420}>
                <BarChart data={sensitivityData} layout="vertical" margin={{ left: 80 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis type="number" domain={[0, 1]} tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis type="category" dataKey="name" width={140} tick={{ fontSize: 10 }} stroke="#94a3b8" />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                  <Bar dataKey="sensitivity" fill="#3b82f6" radius={[0, 4, 4, 0]} name="Sensitivity" />
                  <Bar dataKey="impact" fill="#8b5cf6" radius={[0, 4, 4, 0]} name="Impact on M (×20)" fillOpacity={0.5} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
          {view === 'radar' && selectedNodeData && (
            <div>
              <h3 className="font-semibold text-slate-900 mb-3">Parameter Radar: {selectedNodeData.parameter_id.replace(/_/g, ' ')}</h3>
              <ResponsiveContainer width="100%" height={420}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="#e2e8f0" />
                  <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 1]} />
                  <Radar name={selectedNodeData.parameter_id} dataKey="value" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          )}
          {view === 'radar' && !selectedNodeData && (
            <div className="flex items-center justify-center h-96 text-slate-400">
              Select a parameter from the right panel to view its radar analysis
            </div>
          )}
        </div>

        {/* Node Details */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <h3 className="font-semibold text-slate-900 mb-3 text-sm">Parameters ({KNOWLEDGE_NODES.length})</h3>
            <div className="space-y-1.5 max-h-[400px] overflow-y-auto">
              {KNOWLEDGE_NODES.sort((a, b) => b.sensitivity - a.sensitivity).map(node => (
                <button
                  key={node.parameter_id}
                  onClick={() => { setSelectedNode(selectedNode === node.parameter_id ? null : node.parameter_id); if (view === 'graph') setView('graph'); }}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-sm transition-colors ${
                    selectedNode === node.parameter_id ? 'bg-blue-50 border border-blue-200' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                    node.hot_zone ? 'bg-red-500' : node.dead_zone ? 'bg-slate-300' : 'bg-blue-500'
                  }`} />
                  <span className="flex-1 font-medium text-slate-700 truncate">{node.parameter_id.replace(/_/g, ' ')}</span>
                  <span className="text-xs text-slate-400 font-mono">{node.sensitivity.toFixed(2)}</span>
                </button>
              ))}
            </div>
          </div>

          {selectedNodeData && (
            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                {selectedNodeData.hot_zone ? <Flame className="w-4 h-4 text-red-500" /> : selectedNodeData.dead_zone ? <Snowflake className="w-4 h-4 text-slate-400" /> : <TrendingUp className="w-4 h-4 text-blue-500" />}
                {selectedNodeData.parameter_id.replace(/_/g, ' ')}
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  selectedNodeData.hot_zone ? 'bg-red-100 text-red-700' : selectedNodeData.dead_zone ? 'bg-slate-100 text-slate-500' : 'bg-blue-100 text-blue-700'
                }`}>
                  {selectedNodeData.hot_zone ? 'HOT ZONE' : selectedNodeData.dead_zone ? 'DEAD ZONE' : 'ACTIVE'}
                </span>
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-500">Sensitivity</span><span className="font-medium text-slate-700">{selectedNodeData.sensitivity.toFixed(3)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Impact on M</span><span className="font-medium text-slate-700">{selectedNodeData.impact_on_metric.toFixed(4)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Experiments</span><span className="font-medium text-slate-700">{selectedNodeData.experiment_count}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Interactions</span><span className="font-medium text-slate-700">{selectedNodeData.interactions.length}</span></div>
              </div>
              {relatedEdges.length > 0 && (
                <div className="mt-3 pt-3 border-t border-slate-100">
                  <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1"><Link2 className="w-3 h-3" /> Interactions</h4>
                  <div className="space-y-1">
                    {relatedEdges.map((edge, i) => (
                      <div key={i} className="flex items-center justify-between text-xs">
                        <span className="text-slate-600">{edge.source === selectedNode ? edge.target : edge.source}</span>
                        <span className="font-medium text-blue-600">{edge.interaction_strength.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {selectedNodeData.dead_zone && (
                <div className="mt-3 p-2 bg-slate-50 rounded-lg flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-slate-500">Dead zone declared — mutation budget should be reallocated to more sensitive parameters.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default KnowledgeGraph;
