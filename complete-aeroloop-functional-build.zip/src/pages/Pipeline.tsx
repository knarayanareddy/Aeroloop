import React from 'react';
import { CheckCircle2, Circle, Loader2, XCircle, ArrowRight, Clock, GitBranch, Shield, Zap } from 'lucide-react';
import { useAeroLoopStore } from '../store';

const stageIcons: Record<string, React.ReactNode> = {
  completed: <CheckCircle2 className="w-5 h-5 text-green-500" />,
  running: <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />,
  pending: <Circle className="w-5 h-5 text-slate-300" />,
  failed: <XCircle className="w-5 h-5 text-red-500" />,
};

const STAGE_DESCRIPTIONS = [
  { step: 'STEP 1', desc: 'Read wing.geo + last 10 git log messages', agent: 'LoopOrchestrator' },
  { step: 'STEP 2', desc: 'GeometryMutationAgent proposes ONE mutation', agent: 'GeometryMutationAgent' },
  { step: 'STEP 3', desc: 'PhysicsBoundsChecker validates mutation against registry', agent: 'PhysicsBoundsChecker' },
  { step: 'STEP 4', desc: 'GMSH generates mesh with y+ targeting', agent: 'MeshGeneratorAgent' },
  { step: 'STEP 5', desc: 'MeshQualityChecker validates mesh quality', agent: 'MeshQualityChecker' },
  { step: 'STEP 6', desc: 'SU2 RANS solve with kill timer active', agent: 'CFDSolverAgent' },
  { step: 'STEP 7', desc: 'ExtractPolarsAgent reads results', agent: 'PolarsExtractorAgent' },
  { step: 'STEP 8', desc: 'CompositeMetricAgent computes weighted score', agent: 'CompositeMetricAgent' },
  { step: 'STEP 9', desc: 'KeepRevertAgent decides + executes git action', agent: 'KeepRevertAgent' },
  { step: 'STEP 10', desc: 'WikiTrigger checks if wiki compilation needed', agent: 'WikiTrigger' },
  { step: 'STEP 11', desc: 'GEPTrigger checks if genome evolution needed', agent: 'GEPTrigger' },
  { step: 'STEP 12', desc: 'SwarmSync if in swarm mode', agent: 'SwarmSyncAgent' },
  { step: 'STEP 13', desc: 'Go to STEP 1', agent: 'LoopOrchestrator' },
];

const Pipeline: React.FC = () => {
  const { pipelineStages } = useAeroLoopStore();

  return (
    <div className="space-y-6 max-w-[1600px]">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Pipeline Stages</h2>
        <p className="text-slate-500 mt-1">13-step autoresearch loop — INVIOLABLE structure per CLAUDE.md Article III</p>
      </div>

      {/* State Machine */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <GitBranch className="w-5 h-5 text-blue-500" /> Loop State Machine
        </h3>
        <div className="flex flex-wrap items-center gap-2 text-sm">
          {['IDLE', 'INITIALIZING', 'LOOP_RUNNING', 'LOOP_PAUSED', 'LOOP_COMPLETE'].map((state, i) => (
            <React.Fragment key={state}>
              <span className={`px-3 py-1.5 rounded-lg font-medium ${
                state === 'LOOP_RUNNING' ? 'bg-green-100 text-green-700 ring-2 ring-green-400' :
                state === 'LOOP_PAUSED' ? 'bg-yellow-100 text-yellow-700' :
                'bg-slate-100 text-slate-600'
              }`}>
                {state}
              </span>
              {i < 4 && <ArrowRight className="w-4 h-4 text-slate-300" />}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* 13 Steps */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {STAGE_DESCRIPTIONS.map((step, i) => {
          const stageIdx = Math.min(Math.floor(i / 1.3), 9);
          const pipelineStage = pipelineStages[stageIdx] || pipelineStages[pipelineStages.length - 1];
          const isCurrentStep = i >= 1 && i <= 5 && pipelineStage.status === 'running';
          return (
            <div key={i} className={`bg-white rounded-xl border p-5 transition-all ${isCurrentStep ? 'border-blue-400 ring-2 ring-blue-100 shadow-md' : 'border-slate-200'}`}>
              <div className="flex items-start gap-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${
                  isCurrentStep ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
                }`}>
                  {step.step.split(' ')[1]}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{step.step}</span>
                    {isCurrentStep && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">ACTIVE</span>}
                  </div>
                  <p className="text-sm text-slate-700 mt-1">{step.desc}</p>
                  <div className="mt-2 flex items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> {step.agent}</span>
                    {pipelineStage && <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {pipelineStage.last_execution_time_s.toFixed(1)}s avg</span>}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Stage Details */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h3 className="font-semibold text-slate-900 flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500" /> Stage Agent Performance
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left py-3 px-5 font-medium text-slate-600">Stage</th>
                <th className="text-left py-3 px-5 font-medium text-slate-600">Agent</th>
                <th className="text-left py-3 px-5 font-medium text-slate-600">Status</th>
                <th className="text-left py-3 px-5 font-medium text-slate-600">Avg Time</th>
                <th className="text-left py-3 px-5 font-medium text-slate-600">Success Rate</th>
                <th className="text-left py-3 px-5 font-medium text-slate-600">Description</th>
              </tr>
            </thead>
            <tbody>
              {pipelineStages.map(stage => (
                <tr key={stage.stage} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-3 px-5">
                    <div className="flex items-center gap-2">
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        stage.status === 'running' ? 'bg-blue-100 text-blue-700' :
                        stage.status === 'completed' ? 'bg-green-100 text-green-700' :
                        stage.status === 'failed' ? 'bg-red-100 text-red-700' :
                        'bg-slate-100 text-slate-500'
                      }`}>{stage.stage}</span>
                      <span className="font-medium text-slate-900">{stage.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-5 text-slate-600 font-mono text-xs">{stage.agent}</td>
                  <td className="py-3 px-5">
                    <div className="flex items-center gap-2">
                      {stageIcons[stage.status]}
                      <span className="capitalize text-slate-700">{stage.status}</span>
                    </div>
                  </td>
                  <td className="py-3 px-5 text-slate-600">{stage.last_execution_time_s > 0 ? `${stage.last_execution_time_s.toFixed(1)}s` : '—'}</td>
                  <td className="py-3 px-5">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 bg-slate-100 rounded-full">
                        <div className={`h-full rounded-full ${stage.success_rate > 0.95 ? 'bg-green-400' : stage.success_rate > 0.85 ? 'bg-yellow-400' : 'bg-red-400'}`} style={{ width: `${stage.success_rate * 100}%` }} />
                      </div>
                      <span className="text-slate-600 text-xs">{(stage.success_rate * 100).toFixed(0)}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-5 text-slate-500 text-xs max-w-xs truncate">{stage.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Message Flow */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4">Message Protocol Flow</h3>
        <div className="flex flex-wrap gap-2">
          {['MUTATION_PROPOSAL', 'BOUNDS_VALID', 'MESH_COMPLETE', 'SOLVE_COMPLETE', 'METRICS_COMPUTED', 'EXPERIMENT_KEPT', 'EXPERIMENT_REVERTED', 'WIKI_COMPILE_TRIGGER', 'GEP_EVOLUTION_TRIGGER'].map(msg => (
            <span key={msg} className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs font-mono">
              {msg}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Pipeline;
