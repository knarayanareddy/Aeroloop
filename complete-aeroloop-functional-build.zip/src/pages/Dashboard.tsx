import React, { useState } from 'react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import {
  TrendingUp, Target, Zap, Clock, GitCommitVertical,
  ArrowUpRight, ArrowDownRight, Thermometer
} from 'lucide-react';
import { useAeroLoopStore } from '../store';
import { getMetricHistory, MACH_SWEEP_DATA, SPAN_LOADING_DATA } from '../data/mockData';

const COLORS = {
  keep: '#10b981',
  revert: '#ef4444',
  primary: '#3b82f6',
  secondary: '#8b5cf6',
  warning: '#f59e0b',
};

const MetricCard: React.FC<{
  title: string; value: string; delta?: string; deltaType?: 'up' | 'down';
  icon: React.ReactNode; subtitle?: string; color?: string;
}> = ({ title, value, delta, deltaType, icon, subtitle, color = 'blue' }) => {
  const colorMap: Record<string, string> = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-emerald-50 text-emerald-600',
    purple: 'bg-purple-50 text-purple-600',
    amber: 'bg-amber-50 text-amber-600',
    red: 'bg-red-50 text-red-600',
    cyan: 'bg-cyan-50 text-cyan-600',
  };
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-slate-500 font-medium">{title}</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
          {delta && (
            <div className={`flex items-center gap-1 mt-1 text-sm font-medium ${deltaType === 'up' ? 'text-emerald-600' : 'text-red-500'}`}>
              {deltaType === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              {delta}
            </div>
          )}
          {subtitle && <p className="text-xs text-slate-400 mt-1">{subtitle}</p>}
        </div>
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colorMap[color]}`}>
          {icon}
        </div>
      </div>
    </div>
  );
};

const Dashboard: React.FC = () => {
  const { run, experiments, swarmNodes, pipelineStages, logs, loopState } = useAeroLoopStore();
  const [chartTab, setChartTab] = useState<'metric' | 'ld' | 'drag' | 'span'>('metric');

  const metricHistory = getMetricHistory();
  const recentLogs = logs.slice(0, 10);

  // Compute stats
  const totalKept = run.kept;
  const totalReverted = run.reverted;
  const keepRate = ((totalKept / run.total_experiments) * 100).toFixed(1);
  const metricImprovement = ((run.best_metric - run.baseline_metric) / run.baseline_metric * 100).toFixed(1);
  const avgSolveTime = experiments.slice(-20).reduce((a, e) => a + e.solve_wall_time_s, 0) / 20;
  const totalComputeHours = experiments.reduce((a, e) => a + e.solve_wall_time_s, 0) / 3600;

  // Decision distribution
  const decisionData = [
    { name: 'Kept', value: totalKept, color: COLORS.keep },
    { name: 'Reverted', value: totalReverted, color: COLORS.revert },
  ];

  // Parameter frequency
  const paramFreq: Record<string, number> = {};
  experiments.forEach(e => { paramFreq[e.parameter_changed] = (paramFreq[e.parameter_changed] || 0) + 1; });
  const paramFreqData = Object.entries(paramFreq)
    .map(([name, count]) => ({ name: name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()), count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  // Metric chart data - sample every N points for readability
  const chartData = metricHistory.filter((_, i) => i % Math.max(1, Math.floor(metricHistory.length / 100)) === 0);

  return (
    <div className="space-y-6 max-w-[1600px]">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Optimization Dashboard</h2>
          <p className="text-slate-500 mt-1">Real-time CFD shape optimization monitoring — {run.name}</p>
        </div>
        <div className={`px-4 py-2 rounded-lg text-sm font-semibold ${
          loopState === 'LOOP_RUNNING' ? 'bg-green-100 text-green-700' :
          loopState === 'LOOP_PAUSED' ? 'bg-yellow-100 text-yellow-700' :
          'bg-slate-100 text-slate-700'
        }`}>
          {loopState.replace(/_/g, ' ')}
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <MetricCard
          title="Best Metric M"
          value={run.best_metric.toFixed(4)}
          delta={`${metricImprovement}% from baseline`}
          deltaType="up"
          icon={<Target className="w-5 h-5" />}
          color="blue"
        />
        <MetricCard
          title="L/D Ratio"
          value={experiments[experiments.length - 1]?.ld.toFixed(2) || '—'}
          delta="+3.2% vs baseline"
          deltaType="up"
          icon={<TrendingUp className="w-5 h-5" />}
          color="green"
        />
        <MetricCard
          title="Total Experiments"
          value={`${run.total_experiments}`}
          subtitle={`${run.target_experiments} target`}
          icon={<Zap className="w-5 h-5" />}
          color="purple"
        />
        <MetricCard
          title="Keep Rate"
          value={`${keepRate}%`}
          delta={`${totalKept} kept / ${totalReverted} reverted`}
          deltaType="up"
          icon={<GitCommitVertical className="w-5 h-5" />}
          color="amber"
        />
        <MetricCard
          title="Avg Solve Time"
          value={`${avgSolveTime.toFixed(0)}s`}
          subtitle={`${(avgSolveTime / 60).toFixed(1)} min average`}
          icon={<Clock className="w-5 h-5" />}
          color="cyan"
        />
        <MetricCard
          title="Compute Budget"
          value={`${totalComputeHours.toFixed(1)}h`}
          subtitle="GPU wall time"
          icon={<Thermometer className="w-5 h-5" />}
          color="red"
        />
      </div>

      {/* Main Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Large Metric Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900">Optimization Progress</h3>
            <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
              {(['metric', 'ld', 'drag', 'span'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setChartTab(tab)}
                  className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                    chartTab === tab ? 'bg-white shadow text-blue-600' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {tab === 'metric' ? 'Metric M' : tab === 'ld' ? 'L/D' : tab === 'drag' ? 'Wave Drag' : 'Span Loading'}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={320}>
            {chartTab === 'metric' ? (
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="metricGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="experiment_n" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <YAxis domain={['auto', 'auto']} tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Area type="monotone" dataKey="composite_metric" stroke="#3b82f6" fill="url(#metricGrad)" strokeWidth={2} name="Metric M" />
              </AreaChart>
            ) : chartTab === 'ld' ? (
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="experiment_n" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <YAxis domain={['auto', 'auto']} tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Line type="monotone" dataKey="ld" stroke="#10b981" strokeWidth={2} dot={false} name="L/D" />
              </LineChart>
            ) : chartTab === 'drag' ? (
              <LineChart data={MACH_SWEEP_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="sweep" tick={{ fontSize: 11 }} stroke="#94a3b8" label={{ value: 'LE Sweep (°)', position: 'insideBottom', offset: -5, fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" label={{ value: 'CD_wave', angle: -90, position: 'insideLeft', fontSize: 11 }} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Legend />
                <Line type="monotone" dataKey="cd_wave_m078" stroke="#3b82f6" strokeWidth={2} name="Mach 0.78" />
                <Line type="monotone" dataKey="cd_wave_m080" stroke="#f59e0b" strokeWidth={2} name="Mach 0.80" />
                <Line type="monotone" dataKey="cd_wave_m082" stroke="#ef4444" strokeWidth={2} name="Mach 0.82" />
              </LineChart>
            ) : (
              <AreaChart data={SPAN_LOADING_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="station" tick={{ fontSize: 11 }} stroke="#94a3b8" label={{ value: 'η (span station)', position: 'insideBottom', offset: -5, fontSize: 11 }} />
                <YAxis yAxisId="left" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Area yAxisId="left" type="monotone" dataKey="cl_local" stroke="#8b5cf6" fill="#8b5cf620" strokeWidth={2} name="CL local" />
                <Line yAxisId="right" type="monotone" dataKey="chord" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" name="Chord (m)" />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Decision Distribution */}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h3 className="font-semibold text-slate-900 mb-3">Decision Distribution</h3>
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={decisionData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" paddingAngle={2}>
                  {decisionData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Parameter Mutation Frequency */}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h3 className="font-semibold text-slate-900 mb-3">Most Mutated Parameters</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={paramFreqData} layout="vertical" margin={{ left: 0, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis type="number" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Bar dataKey="count" fill="#3b82f6" radius={[0, 4, 4, 0]} name="Experiments" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pipeline Status */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Pipeline Stages</h3>
          <div className="space-y-2">
            {pipelineStages.map(stage => (
              <div key={stage.stage} className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  stage.status === 'running' ? 'bg-blue-100 text-blue-700 ring-2 ring-blue-400 ring-offset-2' :
                  stage.status === 'completed' ? 'bg-green-100 text-green-700' :
                  stage.status === 'failed' ? 'bg-red-100 text-red-700' :
                  'bg-slate-100 text-slate-500'
                }`}>
                  {stage.stage}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-900">{stage.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      stage.status === 'running' ? 'bg-blue-100 text-blue-700' :
                      stage.status === 'completed' ? 'bg-green-100 text-green-700' :
                      stage.status === 'failed' ? 'bg-red-100 text-red-700' :
                      'bg-slate-100 text-slate-500'
                    }`}>
                      {stage.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 truncate">{stage.agent} • {stage.last_execution_time_s.toFixed(1)}s • {stage.success_rate * 100}% success</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Log */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Live Event Log</h3>
          <div className="space-y-1.5 max-h-96 overflow-y-auto">
            {recentLogs.map(log => (
              <div key={log.id} className="flex items-start gap-2 py-1.5 px-2 rounded hover:bg-slate-50 text-xs">
                <span className={`inline-block w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${
                  log.level === 'success' ? 'bg-green-500' :
                  log.level === 'error' ? 'bg-red-500' :
                  log.level === 'warn' ? 'bg-yellow-500' :
                  'bg-blue-500'
                }`} />
                <span className="text-slate-400 w-16 flex-shrink-0 font-mono">
                  {new Date(log.timestamp).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
                <span className="text-slate-600 flex-1">{log.message}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Swarm Summary */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4">Swarm Nodes</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {swarmNodes.map(node => (
            <div key={node.node_id} className="border border-slate-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-900">{node.node_id.split('-').slice(1).join('-')}</span>
                <span className={`w-2 h-2 rounded-full ${
                  node.status === 'SOLVING' ? 'bg-green-500 animate-pulse' :
                  node.status === 'IDLE' ? 'bg-blue-400' :
                  node.status === 'STALE' ? 'bg-red-400' : 'bg-slate-400'
                }`} />
              </div>
              <div className="text-xs text-slate-500 space-y-1">
                <div className="flex justify-between"><span>Status</span><span className="font-medium text-slate-700">{node.status}</span></div>
                <div className="flex justify-between"><span>Region</span><span className="font-medium text-slate-700">{node.current_region}</span></div>
                <div className="flex justify-between"><span>Best M</span><span className="font-medium text-slate-700">{node.local_best_metric.toFixed(4)}</span></div>
                <div className="flex justify-between"><span>Exp/h</span><span className="font-medium text-slate-700">{node.experiments_per_hour.toFixed(1)}</span></div>
                <div className="flex justify-between"><span>GPU</span><span className="font-medium text-slate-700">{node.gpu_available ? '✓' : '✗'}</span></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
