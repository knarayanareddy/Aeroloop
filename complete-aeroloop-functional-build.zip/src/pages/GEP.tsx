import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Dna, GitBranch, TrendingUp, Zap, Shuffle } from 'lucide-react';
import { GEP_GENOMES } from '../data/mockData';

const strategyColors: Record<string, string> = {
  LOCAL_SEARCH_FINE: '#3b82f6',
  LOCAL_SEARCH_COARSE: '#f59e0b',
  GLOBAL_SEARCH: '#ef4444',
  TOPOLOGY_WINGLET: '#8b5cf6',
  TOPOLOGY_LEADING_EDGE: '#10b981',
  TOPOLOGY_TRAILING_EDGE: '#06b6d4',
};

const GEP: React.FC = () => {
  const [selectedGenome, setSelectedGenome] = useState<string | null>(GEP_GENOMES[GEP_GENOMES.length - 1].genome_id);
  const genome = GEP_GENOMES.find(g => g.genome_id === selectedGenome);

  const fitnessData = GEP_GENOMES.map(g => ({
    generation: g.generation,
    fitness: g.fitness,
    step_size: g.step_size_multiplier,
    patience: g.patience,
    topology_prob: g.topology_probability * 100,
  }));

  return (
    <div className="space-y-6 max-w-[1600px]">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">GEP — Genome Evolution Protocol</h2>
        <p className="text-slate-500 mt-1">Evolves mutation strategy every 500 experiments — {GEP_GENOMES.length} generations completed</p>
      </div>

      {/* Fitness Evolution Chart */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4">Genome Fitness Over Generations</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={fitnessData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="generation" tick={{ fontSize: 11 }} stroke="#94a3b8" label={{ value: 'Generation', position: 'insideBottom', offset: -5 }} />
            <YAxis yAxisId="left" domain={[0.84, 0.92]} tick={{ fontSize: 11 }} stroke="#94a3b8" label={{ value: 'Fitness (Best M)', angle: -90, position: 'insideLeft' }} />
            <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tick={{ fontSize: 11 }} stroke="#94a3b8" label={{ value: 'Topo Prob %', angle: 90, position: 'insideRight' }} />
            <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
            <Line yAxisId="left" type="monotone" dataKey="fitness" stroke="#3b82f6" strokeWidth={3} dot={{ r: 6 }} name="Fitness" />
            <Line yAxisId="right" type="monotone" dataKey="topology_prob" stroke="#8b5cf6" strokeWidth={2} strokeDasharray="5 5" dot={{ r: 4 }} name="Topology %" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Genome Timeline */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <GitBranch className="w-5 h-5 text-blue-500" /> Genome Lineage
        </h3>
        <div className="space-y-4">
          {GEP_GENOMES.map(g => {
            const isSelected = selectedGenome === g.genome_id;
            const color = strategyColors[g.strategy] || '#64748b';
            return (
              <div
                key={g.genome_id}
                onClick={() => setSelectedGenome(g.genome_id)}
                className={`border rounded-xl p-4 cursor-pointer transition-all ${
                  isSelected ? 'border-blue-400 ring-2 ring-blue-100 shadow-md' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white" style={{ backgroundColor: color }}>
                      {g.generation}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-900">{g.genome_id}</span>
                      <span className="text-xs text-slate-400 ml-2">Created at Exp #{g.created_at_experiment}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 rounded-full text-xs font-semibold text-white" style={{ backgroundColor: color }}>
                      {g.strategy.replace(/_/g, ' ')}
                    </span>
                    <span className="text-lg font-bold text-slate-900">{g.fitness.toFixed(4)}</span>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400">Step Size</span>
                    <div className="font-medium text-slate-700">{g.step_size_multiplier.toFixed(1)}×</div>
                  </div>
                  <div>
                    <span className="text-slate-400">Patience</span>
                    <div className="font-medium text-slate-700">{g.patience} exp</div>
                  </div>
                  <div>
                    <span className="text-slate-400">Topology Prob</span>
                    <div className="font-medium text-slate-700">{(g.topology_probability * 100).toFixed(0)}%</div>
                  </div>
                  <div>
                    <span className="text-slate-400">Focus Params</span>
                    <div className="font-medium text-slate-700 truncate">{g.focus_parameters.slice(0, 2).join(', ')}</div>
                  </div>
                </div>
                {g.mutations_applied.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {g.mutations_applied.map((m, i) => (
                      <span key={i} className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-xs">{m}</span>
                    ))}
                  </div>
                )}
                {g.parent_ids.length > 0 && (
                  <div className="mt-2 text-xs text-slate-400 flex items-center gap-1">
                    <Shuffle className="w-3 h-3" /> Parents: {g.parent_ids.join(', ')}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Genome Detail */}
      {genome && (
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <Dna className="w-5 h-5 text-purple-500" /> Active Genome: {genome.genome_id}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="p-4 bg-slate-50 rounded-lg">
              <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Zap className="w-3 h-3" /> Strategy</div>
              <div className="text-sm font-bold text-slate-900">{genome.strategy.replace(/_/g, ' ')}</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg">
              <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><TrendingUp className="w-3 h-3" /> Step Size Multiplier</div>
              <div className="text-sm font-bold text-slate-900">{genome.step_size_multiplier.toFixed(1)}×</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg">
              <div className="text-xs text-slate-500 mb-1">Patience</div>
              <div className="text-sm font-bold text-slate-900">{genome.patience} experiments</div>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg">
              <div className="text-xs text-slate-500 mb-1">Topology Probability</div>
              <div className="text-sm font-bold text-slate-900">{(genome.topology_probability * 100).toFixed(0)}%</div>
            </div>
          </div>
          <div className="mt-4">
            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Focus Parameters</h4>
            <div className="flex flex-wrap gap-2">
              {genome.focus_parameters.map(p => (
                <span key={p} className="px-3 py-1 bg-blue-50 text-blue-700 rounded-lg text-sm font-medium">{p.replace(/_/g, ' ')}</span>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GEP;
