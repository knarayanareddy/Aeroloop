import React, { useState } from 'react';
import { BookOpen, FileText, ChevronRight, Search, Tag, Calendar, Beaker } from 'lucide-react';
import { WIKI_ARTICLES } from '../data/mockData';

const Wiki: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<string | null>(WIKI_ARTICLES[0]?.path || null);
  const [searchQuery, setSearchQuery] = useState('');
  const article = WIKI_ARTICLES.find(a => a.path === selectedArticle);

  const filtered = searchQuery
    ? WIKI_ARTICLES.filter(a =>
        a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.parameter_ids.some(p => p.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : WIKI_ARTICLES;

  return (
    <div className="space-y-6 max-w-[1600px]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Knowledge Wiki</h2>
          <p className="text-slate-500 mt-1">Compiled aerodynamic knowledge — auto-generated every 10 experiments by WikiCompilerAgent</p>
        </div>
        <div className="text-sm text-slate-500">
          {WIKI_ARTICLES.length} articles compiled
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Article List */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="p-4 border-b border-slate-200">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search articles, parameters..."
                className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
            {filtered.map(art => (
              <button
                key={art.path}
                onClick={() => setSelectedArticle(art.path)}
                className={`w-full text-left p-4 hover:bg-slate-50 transition-colors ${
                  selectedArticle === art.path ? 'bg-blue-50 border-l-2 border-blue-500' : ''
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-semibold text-slate-900">{art.title}</h4>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">{art.summary}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-300 flex-shrink-0 mt-1" />
                </div>
                <div className="flex items-center gap-3 mt-2 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(art.compiled_at).toLocaleDateString()}</span>
                  <span className="flex items-center gap-1"><Beaker className="w-3 h-3" /> Exp #{art.experiment_range[0]}–{art.experiment_range[1]}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Article Content */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 overflow-hidden">
          {article ? (
            <div>
              <div className="p-5 border-b border-slate-200 bg-slate-50">
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen className="w-5 h-5 text-blue-500" />
                  <h3 className="text-lg font-bold text-slate-900">{article.title}</h3>
                </div>
                <div className="flex items-center gap-4 text-xs text-slate-500">
                  <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> {article.path}</span>
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(article.compiled_at).toLocaleString()}</span>
                  <span className="flex items-center gap-1"><Beaker className="w-3 h-3" /> Experiments {article.experiment_range[0]}–{article.experiment_range[1]}</span>
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {article.parameter_ids.map(p => (
                    <span key={p} className="flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                      <Tag className="w-3 h-3" /> {p.replace(/_/g, ' ')}
                    </span>
                  ))}
                </div>
              </div>
              <div className="p-5 max-h-[500px] overflow-y-auto">
                <div className="prose prose-sm max-w-none">
                  {article.content.split('\n').map((line, i) => {
                    if (line.startsWith('# ')) return <h1 key={i} className="text-xl font-bold text-slate-900 mt-4 mb-2">{line.replace('# ', '')}</h1>;
                    if (line.startsWith('## ')) return <h2 key={i} className="text-lg font-bold text-slate-900 mt-4 mb-2">{line.replace('## ', '')}</h2>;
                    if (line.startsWith('### ')) return <h3 key={i} className="text-base font-bold text-slate-800 mt-3 mb-1">{line.replace('### ', '')}</h3>;
                    if (line.startsWith('| ') && line.endsWith('|')) {
                      const cells = line.split('|').filter(c => c.trim());
                      return (
                        <div key={i} className="grid gap-1 py-1 border-b border-slate-100" style={{ gridTemplateColumns: `repeat(${cells.length}, 1fr)` }}>
                          {cells.map((cell, j) => (
                            <span key={j} className={`text-xs px-1 ${i === 0 ? 'font-semibold text-slate-700 bg-slate-50' : 'text-slate-600'}`}>
                              {cell.trim()}
                            </span>
                          ))}
                        </div>
                      );
                    }
                    if (line.startsWith('- ')) return <div key={i} className="flex gap-2 text-sm text-slate-700 ml-2"><span>•</span><span>{line.replace('- ', '')}</span></div>;
                    if (line.trim() === '') return <div key={i} className="h-2" />;
                    return <p key={i} className="text-sm text-slate-700 leading-relaxed">{line}</p>;
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-96 text-slate-400">
              Select an article from the left panel
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Wiki;
