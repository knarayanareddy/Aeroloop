import React, { useState } from 'react';
import { RotateCcw, AlertTriangle, CheckCircle2, Save, Edit3, X } from 'lucide-react';
import { useAeroLoopStore } from '../store';
import { PARAMETER_REGISTRY, PENDING_MUTATION } from '../data/mockData';

const Geometry: React.FC = () => {
  const { wingParams, setWingParam, resetWingParams } = useAeroLoopStore();
  const [activeGroup, setActiveGroup] = useState<string>('all');
  const [editMode, setEditMode] = useState(false);

  const groups = ['all', ...new Set(PARAMETER_REGISTRY.map(p => p.group))];
  const filtered = activeGroup === 'all'
    ? PARAMETER_REGISTRY
    : PARAMETER_REGISTRY.filter(p => p.group === activeGroup);

  // Validation
  const violations = PARAMETER_REGISTRY.filter(def => {
    const val = wingParams[def.id];
    return val < def.min || val > def.max;
  });

  // Compute derived
  const taper = wingParams.tip_chord_m / wingParams.root_chord_m;
  const ar = (wingParams.semi_span_m * 2) ** 2 / (wingParams.ref_area_m2);

  return (
    <div className="space-y-6 max-w-[1600px]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Wing Geometry Editor</h2>
          <p className="text-slate-500 mt-1">The ONE mutable file — geometry/wing.geo — all parameters validated against physical bounds</p>
        </div>
        <div className="flex gap-2">
          <button onClick={resetWingParams} className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">
            <RotateCcw className="w-4 h-4" /> Reset to Current
          </button>
          <button onClick={() => setEditMode(!editMode)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            editMode ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}>
            {editMode ? <><X className="w-4 h-4" /> Cancel Edit</> : <><Edit3 className="w-4 h-4" /> Edit Geometry</>}
          </button>
          {editMode && (
            <button className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors">
              <Save className="w-4 h-4" /> Apply Mutation
            </button>
          )}
        </div>
      </div>

      {/* Validation Banner */}
      {violations.length > 0 ? (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-red-700">Physical Bounds Violated</h4>
            <p className="text-sm text-red-600 mt-1">{violations.map(v => `${v.label}: ${wingParams[v.id]} outside [${v.min}, ${v.max}]`).join(' • ')}</p>
            <p className="text-xs text-red-500 mt-1">PhysicsBoundsChecker will REJECT this geometry. Fix before applying.</p>
          </div>
        </div>
      ) : (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-green-500" />
          <span className="text-sm text-green-700 font-medium">All parameters within physical bounds — PhysicsBoundsChecker will PASS</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Wing Visualization */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Wing Planform</h3>
          <div className="relative">
            <svg viewBox="-2 -2 24 8" className="w-full h-auto">
              {/* Root chord */}
              <line x1="0" y1="0" x2="0" y2={wingParams.root_chord_m / 2} stroke="#3b82f6" strokeWidth="0.3" />
              {/* Leading edge sweep line */}
              <line
                x1="0" y1={wingParams.root_chord_m / 2}
                x2={wingParams.semi_span_m * 0.8} y2={wingParams.root_chord_m / 2 - (wingParams.root_chord_m / 2 - wingParams.tip_chord_m / 2) + Math.tan(wingParams.le_sweep_deg * Math.PI / 180) * wingParams.semi_span_m * 0.04}
                stroke="#3b82f6" strokeWidth="0.15" fill="none"
              />
              {/* Semi-span wing shape */}
              <polygon
                points={`
                  0,0
                  ${wingParams.semi_span_m * 0.8},${wingParams.root_chord_m / 2 - (wingParams.root_chord_m / 2 - wingParams.tip_chord_m / 2) + Math.tan(wingParams.le_sweep_deg * Math.PI / 180) * wingParams.semi_span_m * 0.04}
                  ${wingParams.semi_span_m * 0.8},${wingParams.tip_chord_m / 2 + Math.tan(wingParams.te_sweep_deg * Math.PI / 180) * wingParams.semi_span_m * 0.04}
                  0,${wingParams.root_chord_m / 2}
                `}
                fill="#3b82f620" stroke="#3b82f6" strokeWidth="0.15"
              />
              {/* Winglet */}
              {wingParams.winglet_height_m > 0 && (
                <line
                  x1={wingParams.semi_span_m * 0.8} y1={wingParams.root_chord_m / 2 - (wingParams.root_chord_m / 2 - wingParams.tip_chord_m / 2) + Math.tan(wingParams.le_sweep_deg * Math.PI / 180) * wingParams.semi_span_m * 0.04}
                  x2={wingParams.semi_span_m * 0.8 + wingParams.winglet_height_m * 0.3 * Math.cos(wingParams.winglet_cant_deg * Math.PI / 180)}
                  y2={wingParams.root_chord_m / 2 - (wingParams.root_chord_m / 2 - wingParams.tip_chord_m / 2) + Math.tan(wingParams.le_sweep_deg * Math.PI / 180) * wingParams.semi_span_m * 0.04 + wingParams.winglet_height_m * 0.15 * Math.sin(wingParams.winglet_cant_deg * Math.PI / 180)}
                  stroke="#8b5cf6" strokeWidth="0.2"
                />
              )}
              {/* Annotations */}
              <text x={wingParams.semi_span_m * 0.4} y="-0.5" textAnchor="middle" fontSize="0.8" fill="#64748b">Semi-span: {wingParams.semi_span_m.toFixed(1)}m</text>
              <text x="-1" y={wingParams.root_chord_m / 4} textAnchor="middle" fontSize="0.6" fill="#64748b" transform={`rotate(-90, -1, ${wingParams.root_chord_m / 4})`}>Root: {wingParams.root_chord_m.toFixed(2)}m</text>
              <text x={wingParams.semi_span_m * 0.8 + 1} y={wingParams.tip_chord_m / 4} textAnchor="middle" fontSize="0.6" fill="#64748b" transform={`rotate(-90, ${wingParams.semi_span_m * 0.8 + 1}, ${wingParams.tip_chord_m / 4})`}>Tip: {wingParams.tip_chord_m.toFixed(2)}m</text>
            </svg>
          </div>
          {/* Derived quantities */}
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="text-center p-2 bg-slate-50 rounded-lg">
              <div className="text-xs text-slate-500">Taper Ratio</div>
              <div className="text-lg font-bold text-slate-900">{taper.toFixed(3)}</div>
            </div>
            <div className="text-center p-2 bg-slate-50 rounded-lg">
              <div className="text-xs text-slate-500">Aspect Ratio</div>
              <div className="text-lg font-bold text-slate-900">{ar.toFixed(2)}</div>
            </div>
            <div className="text-center p-2 bg-slate-50 rounded-lg">
              <div className="text-xs text-slate-500">Ref Area</div>
              <div className="text-lg font-bold text-slate-900">{wingParams.ref_area_m2.toFixed(1)}m²</div>
            </div>
          </div>
        </div>

        {/* Parameter Editor */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200">
          {/* Group Tabs */}
          <div className="border-b border-slate-200 px-5 pt-4">
            <div className="flex gap-1 overflow-x-auto pb-2">
              {groups.map(g => (
                <button
                  key={g}
                  onClick={() => setActiveGroup(g)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    activeGroup === g ? 'bg-blue-100 text-blue-700' : 'text-slate-500 hover:bg-slate-100'
                  }`}
                >
                  {g === 'all' ? 'All Parameters' : g}
                </button>
              ))}
            </div>
          </div>

          <div className="p-5 space-y-4 max-h-[600px] overflow-y-auto">
            {filtered.map(def => {
              const val = wingParams[def.id];
              const isViolated = val < def.min || val > def.max;
              const pct = ((val - def.min) / (def.max - def.min)) * 100;
              return (
                <div key={def.id} className={`p-3 rounded-lg border ${isViolated ? 'border-red-200 bg-red-50' : 'border-slate-100'}`}>
                  <div className="flex items-center justify-between mb-1.5">
                    <div>
                      <span className="text-sm font-medium text-slate-900">{def.label}</span>
                      <span className="text-xs text-slate-400 ml-2">{def.unit && `(${def.unit})`}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {editMode ? (
                        <input
                          type="number"
                          value={val}
                          step={def.step}
                          min={def.min}
                          max={def.max}
                          onChange={e => setWingParam(def.id, parseFloat(e.target.value) || val)}
                          className="w-24 px-2 py-1 border border-slate-300 rounded text-sm font-mono text-right focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      ) : (
                        <span className={`text-sm font-mono font-medium ${isViolated ? 'text-red-600' : 'text-slate-700'}`}>
                          {typeof val === 'number' ? val.toFixed(def.step < 0.01 ? 4 : def.step < 0.1 ? 3 : def.step < 1 ? 2 : 1) : val}
                        </span>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 mb-2">{def.description}</p>
                  <div className="relative h-1.5 bg-slate-100 rounded-full">
                    <div
                      className={`absolute h-full rounded-full ${isViolated ? 'bg-red-400' : 'bg-blue-400'}`}
                      style={{ width: `${Math.max(0, Math.min(100, pct))}%` }}
                    />
                    <div className="absolute h-full w-0.5 bg-slate-300" style={{ left: '0%' }} />
                    <div className="absolute h-full w-0.5 bg-slate-300" style={{ left: '100%' }} />
                  </div>
                  <div className="flex justify-between text-xs text-slate-400 mt-0.5">
                    <span>{def.min}</span>
                    <span>{def.max}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Pending Mutation */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-5">
        <h3 className="font-semibold text-blue-900 mb-3">Pending Mutation (Next Experiment)</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <div className="text-xs text-blue-600 font-medium">Parameter</div>
            <div className="text-sm font-semibold text-blue-900">{PENDING_MUTATION.parameter.replace(/_/g, ' ')}</div>
          </div>
          <div>
            <div className="text-xs text-blue-600 font-medium">Change</div>
            <div className="text-sm text-blue-800">
              <span className="text-red-500">{PENDING_MUTATION.old_value}</span>
              <span className="mx-1">→</span>
              <span className="text-green-600 font-semibold">{PENDING_MUTATION.new_value}</span>
            </div>
          </div>
          <div>
            <div className="text-xs text-blue-600 font-medium">Expected Δ</div>
            <div className="text-sm font-semibold text-green-700">+{PENDING_MUTATION.expected_metric_delta}</div>
          </div>
          <div>
            <div className="text-xs text-blue-600 font-medium">Confidence</div>
            <div className="text-sm font-semibold text-blue-900">{(PENDING_MUTATION.confidence * 100).toFixed(0)}%</div>
          </div>
        </div>
        <p className="mt-3 text-sm text-blue-700 italic">{PENDING_MUTATION.reasoning}</p>
      </div>
    </div>
  );
};

export default Geometry;
