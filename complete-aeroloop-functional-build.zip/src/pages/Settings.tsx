import React, { useState } from 'react';
import { Save, Shield, Settings2, Cpu, Gauge, Beaker } from 'lucide-react';
import { useAeroLoopStore } from '../store';
import type { MetricWeights } from '../types';

const Settings: React.FC = () => {
  const { run, updateMetricWeights, updateRunConfig } = useAeroLoopStore();
  const [weights, setWeights] = useState<MetricWeights>({ ...run.metric_weights });
  const [mach, setMach] = useState(run.mach);
  const [alpha, setAlpha] = useState(run.alpha_deg);
  const [killTimer, setKillTimer] = useState(run.cfd_max_wall_time_minutes);
  const [meshTemplate, setMeshTemplate] = useState(run.mesh_template);
  const [solver, setSolver] = useState(run.solver);
  const [targetExp, setTargetExp] = useState(run.target_experiments);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    // Renormalize weights
    const total = weights.w_ld + weights.w_buffet + weights.w_wave;
    const normalized = {
      w_ld: weights.w_ld / total,
      w_buffet: weights.w_buffet / total,
      w_wave: weights.w_wave / total,
    };
    updateMetricWeights(normalized);
    updateRunConfig({
      mach,
      alpha_deg: alpha,
      cfd_max_wall_time_minutes: killTimer,
      mesh_template: meshTemplate,
      solver,
      target_experiments: targetExp,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const weightSum = weights.w_ld + weights.w_buffet + weights.w_wave;
  const weightValid = Math.abs(weightSum - 1.0) < 0.001 && weights.w_ld >= 0.3;

  return (
    <div className="space-y-6 max-w-[1200px]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Run Configuration</h2>
          <p className="text-slate-500 mt-1">Metric weights locked per run per CLAUDE.md Article III Rule-25 — start a new run to change targets</p>
        </div>
        <div className="flex gap-2">
          <button onClick={handleSave} disabled={!weightValid} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            saved ? 'bg-green-600 text-white' : weightValid ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-slate-300 text-slate-500 cursor-not-allowed'
          }`}>
            <Save className="w-4 h-4" /> {saved ? 'Saved!' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Run Info */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <Beaker className="w-5 h-5 text-blue-500" /> Experiment Run
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Run ID</label>
            <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm font-mono text-slate-700 truncate">{run.run_id.substring(0, 20)}…</div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Run Name</label>
            <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm text-slate-700">{run.name}</div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Started At</label>
            <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm text-slate-700">{new Date(run.started_at).toLocaleString()}</div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Target Experiments</label>
            <input
              type="number"
              value={targetExp}
              onChange={e => setTargetExp(parseInt(e.target.value) || 500)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Metric Weights */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-amber-500" /> Composite Metric Weights
        </h3>
        <div className="space-y-6">
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700">
            <strong>Constitutional Law Rule-025:</strong> The composite metric is defined ONCE at run initialization and NEVER changes during a run. 
            An agent may not change the optimization target mid-run. Start a new run to change targets.
          </div>
          <div className="grid grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                w<sub>L/D</sub> — Lift-to-Drag Ratio
              </label>
              <input
                type="range"
                min={0.3}
                max={0.8}
                step={0.01}
                value={weights.w_ld}
                onChange={e => setWeights({ ...weights, w_ld: parseFloat(e.target.value) })}
                className="w-full accent-blue-600"
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>0.30</span>
                <span className="font-medium text-blue-600">{weights.w_ld.toFixed(2)}</span>
                <span>0.80</span>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                w<sub>buffet</sub> — Buffet Margin
              </label>
              <input
                type="range"
                min={0}
                max={0.5}
                step={0.01}
                value={weights.w_buffet}
                onChange={e => setWeights({ ...weights, w_buffet: parseFloat(e.target.value) })}
                className="w-full accent-purple-600"
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>0.00</span>
                <span className="font-medium text-purple-600">{weights.w_buffet.toFixed(2)}</span>
                <span>0.50</span>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                w<sub>wave</sub> — Wave Drag
              </label>
              <input
                type="range"
                min={0}
                max={0.5}
                step={0.01}
                value={weights.w_wave}
                onChange={e => setWeights({ ...weights, w_wave: parseFloat(e.target.value) })}
                className="w-full accent-green-600"
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>0.00</span>
                <span className="font-medium text-green-600">{weights.w_wave.toFixed(2)}</span>
                <span>0.50</span>
              </div>
            </div>
          </div>
          <div className={`px-4 py-2 rounded-lg text-sm ${weightValid ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
            Weight sum: {weightSum.toFixed(3)} {weightValid ? '✓ (sum ≈ 1.0, w_ld ≥ 0.3)' : '✗ Must sum to 1.0 and w_ld ≥ 0.3'}
          </div>
          {/* Metric formula */}
          <div className="bg-slate-50 rounded-lg p-4 font-mono text-sm text-slate-700">
            <div className="text-xs text-slate-400 mb-1">M = w_ld × norm(L/D) + w_buffet × norm(buffet_margin) + w_wave × norm(1 − CD_wave/CD_total)</div>
            <div className="text-xs text-slate-400 mt-1">
              M = {weights.w_ld.toFixed(2)} × L/D_norm + {weights.w_buffet.toFixed(2)} × buffet_norm + {weights.w_wave.toFixed(2)} × (1−CDw/CDt)_norm
            </div>
          </div>
        </div>
      </div>

      {/* CFD Configuration */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-purple-500" /> Solver Configuration
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Solver</label>
              <select
                value={solver}
                onChange={e => setSolver(e.target.value as 'SU2' | 'OpenFOAM')}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="SU2">SU2 (RANS)</option>
                <option value="OpenFOAM">OpenFOAM</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Mesh Template</label>
              <select
                value={meshTemplate}
                onChange={e => setMeshTemplate(e.target.value as 'coarse' | 'medium' | 'fine')}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="coarse">Coarse (y+ ~5, ~500k cells)</option>
                <option value="medium">Medium (y+ ~2, ~2M cells)</option>
                <option value="fine">Fine (y+ ~1, ~8M cells)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Kill Timer (minutes) — RULE-002</label>
              <input
                type="number"
                value={killTimer}
                onChange={e => setKillTimer(parseInt(e.target.value) || 8)}
                min={2}
                max={30}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-slate-400 mt-1">Hard wall-time limit for every CFD solve. Never removable per constitutional law.</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <Gauge className="w-5 h-5 text-cyan-500" /> Flight Conditions
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Mach Number</label>
              <input
                type="number"
                value={mach}
                onChange={e => setMach(parseFloat(e.target.value) || 0.785)}
                step={0.005}
                min={0.3}
                max={0.95}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-slate-400 mt-1">Cruise Mach number. Transonic regime: 0.72–0.88</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Angle of Attack (°)</label>
              <input
                type="number"
                value={alpha}
                onChange={e => setAlpha(parseFloat(e.target.value) || 2.8)}
                step={0.1}
                min={-2}
                max={8}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Reynolds Number (/m)</label>
              <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm text-slate-700">{(run.reynolds_per_m).toExponential(2)}</div>
              <p className="text-xs text-slate-400 mt-1">Based on altitude and flight speed</p>
            </div>
          </div>
        </div>
      </div>

      {/* Constitutional Rules Reference */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <Settings2 className="w-5 h-5 text-slate-500" /> Active Constitutional Rules
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { rule: 'RULE-001', desc: 'ONE mutable file: geometry/wing.geo', status: 'enforced' },
            { rule: 'RULE-002', desc: `Kill timer: ${killTimer} min (never removable)`, status: 'enforced' },
            { rule: 'RULE-003', desc: 'Git integrity: KEEP=commit, REVERT=checkout', status: 'enforced' },
            { rule: 'RULE-004', desc: 'Physical bounds checked before every mesh', status: 'enforced' },
            { rule: 'RULE-005', desc: 'Result provenance via SHA256 checksums', status: 'enforced' },
            { rule: 'RULE-006', desc: 'Swarm non-collision via Redis SETNX', status: 'enforced' },
            { rule: 'RULE-020', desc: '13-step loop structure is INVIOLABLE', status: 'enforced' },
            { rule: 'RULE-021', desc: 'ONE mutation per experiment', status: 'enforced' },
            { rule: 'RULE-025', desc: `Metric weights locked for this run (M=${run.baseline_metric.toFixed(4)} baseline)`, status: 'locked' },
          ].map(r => (
            <div key={r.rule} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
              <span className={`px-2 py-0.5 rounded text-xs font-bold ${r.status === 'enforced' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                {r.status === 'enforced' ? '✓' : '🔒'} {r.rule}
              </span>
              <span className="text-sm text-slate-600">{r.desc}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Settings;
