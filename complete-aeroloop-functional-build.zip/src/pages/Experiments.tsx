import React, { useState, useMemo } from 'react';
import { Search, ChevronDown, ChevronUp, Edit3, Save, X } from 'lucide-react';
import { useAeroLoopStore } from '../store';

const Experiments: React.FC = () => {
  const {
    experiments, experimentFilter, setExperimentFilter,
    experimentDecisionFilter, setExperimentDecisionFilter,
    editingExperiment, setEditingExperiment, experimentNotes, updateExperimentNote,
  } = useAeroLoopStore();
  const [sortField, setSortField] = useState<'experiment_n' | 'composite_metric' | 'solve_wall_time_s' | 'timestamp'>('experiment_n');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(0);
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [editNote, setEditNote] = useState('');
  const pageSize = 25;

  const filtered = useMemo(() => {
    let result = [...experiments];
    if (experimentFilter) {
      const q = experimentFilter.toLowerCase();
      result = result.filter(e =>
        e.parameter_changed.toLowerCase().includes(q) ||
        e.reasoning.toLowerCase().includes(q) ||
        e.region.toLowerCase().includes(q) ||
        e.node_id.toLowerCase().includes(q)
      );
    }
    if (experimentDecisionFilter && experimentDecisionFilter !== 'ALL') {
      result = result.filter(e => e.decision === experimentDecisionFilter);
    }
    result.sort((a, b) => {
      const av = a[sortField], bv = b[sortField];
      return sortDir === 'desc' ? (av > bv ? -1 : 1) : (av < bv ? -1 : 1);
    });
    return result;
  }, [experiments, experimentFilter, experimentDecisionFilter, sortField, sortDir]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const pageData = filtered.slice(page * pageSize, (page + 1) * pageSize);

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('desc'); }
  };

  const SortIcon: React.FC<{ field: typeof sortField }> = ({ field }) => {
    if (sortField !== field) return <ChevronDown className="w-3 h-3 text-slate-300" />;
    return sortDir === 'desc' ? <ChevronDown className="w-3 h-3 text-blue-500" /> : <ChevronUp className="w-3 h-3 text-blue-500" />;
  };

  return (
    <div className="space-y-6 max-w-[1600px]">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Experiment Registry</h2>
        <p className="text-slate-500 mt-1">Complete history of all {experiments.length} optimization experiments with SHA256 provenance</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={experimentFilter}
            onChange={e => { setExperimentFilter(e.target.value); setPage(0); }}
            placeholder="Search parameters, reasoning, regions..."
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
          {['ALL', 'KEEP', 'REVERT', 'TIMEOUT', 'MESH_FAILED'].map(f => (
            <button
              key={f}
              onClick={() => { setExperimentDecisionFilter(f); setPage(0); }}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                experimentDecisionFilter === f ? 'bg-white shadow text-blue-600' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {f === 'ALL' ? 'All' : f}
            </button>
          ))}
        </div>
        <span className="text-sm text-slate-500">{filtered.length} results</span>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left py-3 px-4 font-medium text-slate-600 cursor-pointer" onClick={() => toggleSort('experiment_n')}>
                  <span className="flex items-center gap-1">Exp # <SortIcon field="experiment_n" /></span>
                </th>
                <th className="text-left py-3 px-4 font-medium text-slate-600">Decision</th>
                <th className="text-left py-3 px-4 font-medium text-slate-600">Parameter</th>
                <th className="text-left py-3 px-4 font-medium text-slate-600">Change</th>
                <th className="text-left py-3 px-4 font-medium text-slate-600 cursor-pointer" onClick={() => toggleSort('composite_metric')}>
                  <span className="flex items-center gap-1">Metric M <SortIcon field="composite_metric" /></span>
                </th>
                <th className="text-left py-3 px-4 font-medium text-slate-600">L/D</th>
                <th className="text-left py-3 px-4 font-medium text-slate-600">CD</th>
                <th className="text-left py-3 px-4 font-medium text-slate-600">Region</th>
                <th className="text-left py-3 px-4 font-medium text-slate-600 cursor-pointer" onClick={() => toggleSort('solve_wall_time_s')}>
                  <span className="flex items-center gap-1">Time <SortIcon field="solve_wall_time_s" /></span>
                </th>
                <th className="text-left py-3 px-4 font-medium text-slate-600">Node</th>
                <th className="text-left py-3 px-4 font-medium text-slate-600 w-10"></th>
              </tr>
            </thead>
            <tbody>
              {pageData.map(exp => (
                <React.Fragment key={exp.experiment_n}>
                  <tr
                    className={`border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition-colors ${
                      expandedRow === exp.experiment_n ? 'bg-blue-50/50' : ''
                    }`}
                    onClick={() => setExpandedRow(expandedRow === exp.experiment_n ? null : exp.experiment_n)}
                  >
                    <td className="py-2.5 px-4 font-mono text-slate-700 font-medium">#{exp.experiment_n.toString().padStart(4, '0')}</td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        exp.decision === 'KEEP' ? 'bg-green-100 text-green-700' :
                        exp.decision === 'REVERT' ? 'bg-red-100 text-red-700' :
                        exp.decision === 'TIMEOUT' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-orange-100 text-orange-700'
                      }`}>
                        {exp.decision}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-700 font-medium">{exp.parameter_changed.replace(/_/g, ' ')}</td>
                    <td className="py-2.5 px-4 text-slate-600">
                      <span className="text-red-500">{exp.old_value.toFixed(3)}</span>
                      <span className="text-slate-400 mx-1">→</span>
                      <span className="text-blue-600">{exp.new_value.toFixed(3)}</span>
                    </td>
                    <td className="py-2.5 px-4">
                      <span className="font-medium text-slate-900">{exp.composite_metric.toFixed(4)}</span>
                      <span className={`ml-1 text-xs ${exp.metric_delta >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                        {exp.metric_delta >= 0 ? '+' : ''}{exp.metric_delta.toFixed(4)}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-700">{exp.ld.toFixed(2)}</td>
                    <td className="py-2.5 px-4 text-slate-600 font-mono text-xs">{exp.cd.toFixed(5)}</td>
                    <td className="py-2.5 px-4 text-slate-500 text-xs">{exp.region}</td>
                    <td className="py-2.5 px-4 text-slate-600">{exp.solve_wall_time_s.toFixed(0)}s</td>
                    <td className="py-2.5 px-4 text-slate-500 text-xs">{exp.node_id.split('-')[1]}</td>
                    <td className="py-2.5 px-4">
                      {expandedRow === exp.experiment_n ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                    </td>
                  </tr>
                  {expandedRow === exp.experiment_n && (
                    <tr>
                      <td colSpan={11} className="bg-slate-50 p-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          {/* Reasoning */}
                          <div className="md:col-span-2">
                            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Mutation Reasoning</h4>
                            <p className="text-sm text-slate-700 leading-relaxed">{exp.reasoning}</p>
                            <div className="mt-3 grid grid-cols-3 gap-3">
                              <div className="text-xs"><span className="text-slate-500">Strategy:</span> <span className="font-medium text-slate-700">{exp.strategy}</span></div>
                              <div className="text-xs"><span className="text-slate-500">Genome Gen:</span> <span className="font-medium text-slate-700">{exp.genome_generation}</span></div>
                              <div className="text-xs"><span className="text-slate-500">Mesh:</span> <span className="font-medium text-slate-700">{(exp.mesh_cell_count / 1e6).toFixed(2)}M cells, y+={exp.mesh_yp_avg}</span></div>
                            </div>
                          </div>
                          {/* Details */}
                          <div>
                            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Aerodynamic Coefficients</h4>
                            <div className="space-y-1 text-xs">
                              <div className="flex justify-between"><span className="text-slate-500">CL</span><span className="font-mono text-slate-700">{exp.cl.toFixed(4)}</span></div>
                              <div className="flex justify-between"><span className="text-slate-500">CD (total)</span><span className="font-mono text-slate-700">{exp.cd.toFixed(5)}</span></div>
                              <div className="flex justify-between"><span className="text-slate-500">CD_wave</span><span className="font-mono text-slate-700">{exp.cd_wave.toFixed(5)}</span></div>
                              <div className="flex justify-between"><span className="text-slate-500">CD_induced</span><span className="font-mono text-slate-700">{exp.cd_induced.toFixed(5)}</span></div>
                              <div className="flex justify-between"><span className="text-slate-500">CD_viscous</span><span className="font-mono text-slate-700">{exp.cd_viscous.toFixed(5)}</span></div>
                              <div className="flex justify-between"><span className="text-slate-500">CM_y</span><span className="font-mono text-slate-700">{exp.cm.toFixed(4)}</span></div>
                              <div className="flex justify-between"><span className="text-slate-500">Buffet margin</span><span className="font-mono text-slate-700">{exp.buffet_margin_deg.toFixed(2)}°</span></div>
                            </div>
                            {/* Provenance */}
                            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-3 mb-2">SHA256 Provenance</h4>
                            <div className="space-y-1 text-xs font-mono text-slate-500 break-all">
                              <div>geo: {exp.geometry_sha256.substring(0, 24)}…</div>
                              <div>mesh: {exp.mesh_sha256.substring(0, 24)}…</div>
                              <div>res: {exp.results_sha256.substring(0, 24)}…</div>
                            </div>
                          </div>
                          {/* Operator Note */}
                          <div className="md:col-span-3">
                            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Operator Note</h4>
                            {editingExperiment === exp.experiment_n ? (
                              <div className="flex gap-2">
                                <input
                                  type="text"
                                  value={editNote}
                                  onChange={e => setEditNote(e.target.value)}
                                  className="flex-1 px-3 py-1.5 border border-slate-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  placeholder="Add a note about this experiment..."
                                  autoFocus
                                />
                                <button onClick={() => { updateExperimentNote(exp.experiment_n, editNote); setEditingExperiment(null); }} className="p-1.5 bg-blue-600 text-white rounded hover:bg-blue-700">
                                  <Save className="w-4 h-4" />
                                </button>
                                <button onClick={() => setEditingExperiment(null)} className="p-1.5 bg-slate-200 text-slate-600 rounded hover:bg-slate-300">
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <span className="text-sm text-slate-600">{experimentNotes[exp.experiment_n] || <span className="italic text-slate-400">No note</span>}</span>
                                <button
                                  onClick={e => { e.stopPropagation(); setEditingExperiment(exp.experiment_n); setEditNote(experimentNotes[exp.experiment_n] || ''); }}
                                  className="p-1 text-slate-400 hover:text-blue-600"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 bg-slate-50">
          <span className="text-sm text-slate-500">
            Showing {page * pageSize + 1}–{Math.min((page + 1) * pageSize, filtered.length)} of {filtered.length}
          </span>
          <div className="flex gap-1">
            <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="px-3 py-1 text-sm border border-slate-200 rounded hover:bg-white disabled:opacity-50 disabled:cursor-not-allowed">Previous</button>
            <span className="px-3 py-1 text-sm text-slate-600">Page {page + 1} of {totalPages}</span>
            <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1} className="px-3 py-1 text-sm border border-slate-200 rounded hover:bg-white disabled:opacity-50 disabled:cursor-not-allowed">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Experiments;
