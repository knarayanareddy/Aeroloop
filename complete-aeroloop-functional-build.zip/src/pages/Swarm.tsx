import React from 'react';
import { Cpu, Wifi, WifiOff, MapPin, BarChart3, Clock, Monitor, Server } from 'lucide-react';
import { useAeroLoopStore } from '../store';
import { REGION_CLAIMS } from '../data/mockData';
import type { NodeStatus } from '../types';

const statusColors: Record<NodeStatus, string> = {
  SOLVING: 'bg-green-500',
  IDLE: 'bg-blue-400',
  GEP: 'bg-purple-500',
  OFFLINE: 'bg-slate-400',
  STALE: 'bg-red-400',
};

const Swarm: React.FC = () => {
  const { swarmNodes } = useAeroLoopStore();

  const totalExperiments = swarmNodes.reduce((a, n) => a + n.current_experiment_n, 0);
  const totalRate = swarmNodes.reduce((a, n) => a + n.experiments_per_hour, 0);
  const globalBest = Math.max(...swarmNodes.map(n => n.local_best_metric));

  return (
    <div className="space-y-6 max-w-[1600px]">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Swarm Coordination</h2>
        <p className="text-slate-500 mt-1">Multi-node design space partitioning — {swarmNodes.length} active nodes, non-collision enforced via Redis SETNX</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Server className="w-4 h-4 text-blue-500" />
            <span className="text-sm text-slate-500">Active Nodes</span>
          </div>
          <div className="text-2xl font-bold text-slate-900">{swarmNodes.filter(n => n.status !== 'STALE' && n.status !== 'OFFLINE').length} / {swarmNodes.length}</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="w-4 h-4 text-green-500" />
            <span className="text-sm text-slate-500">Total Experiments</span>
          </div>
          <div className="text-2xl font-bold text-slate-900">{totalExperiments}</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-purple-500" />
            <span className="text-sm text-slate-500">Combined Rate</span>
          </div>
          <div className="text-2xl font-bold text-slate-900">{totalRate.toFixed(1)} exp/h</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="w-4 h-4 text-amber-500" />
            <span className="text-sm text-slate-500">Global Best M</span>
          </div>
          <div className="text-2xl font-bold text-slate-900">{globalBest.toFixed(4)}</div>
        </div>
      </div>

      {/* Node Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {swarmNodes.map(node => (
          <div key={node.node_id} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-slate-900 flex items-center justify-center">
                    <Cpu className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">{node.node_id}</h3>
                    <p className="text-xs text-slate-400 font-mono">{node.hostname}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${statusColors[node.status]} ${node.status === 'SOLVING' ? 'animate-pulse' : ''}`} />
                  <span className="text-sm font-medium text-slate-700">{node.status}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Current Region</div>
                  <div className="text-sm font-semibold text-slate-900 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-blue-500" />
                    {node.current_region}
                  </div>
                </div>
                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="text-xs text-slate-500 mb-1">Local Best M</div>
                  <div className="text-sm font-semibold text-slate-900">{node.local_best_metric.toFixed(4)}</div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-3 text-center">
                <div>
                  <div className="text-xs text-slate-400">Experiments</div>
                  <div className="text-sm font-bold text-slate-700">{node.current_experiment_n}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Exp/h</div>
                  <div className="text-sm font-bold text-slate-700">{node.experiments_per_hour.toFixed(1)}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Cores</div>
                  <div className="text-sm font-bold text-slate-700">{node.core_count}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">GPU</div>
                  <div className="text-sm font-bold text-slate-700">{node.gpu_available ? '✓' : '✗'}</div>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1"><Monitor className="w-3 h-3" /> {node.memory_gb}GB RAM</span>
                <span>Last heartbeat: {new Date(node.last_heartbeat).toLocaleTimeString()}</span>
              </div>
            </div>
            {/* Progress bar */}
            <div className="h-1 bg-slate-100">
              <div
                className={`h-full ${
                  node.status === 'SOLVING' ? 'bg-green-500 animate-pulse' :
                  node.status === 'IDLE' ? 'bg-blue-400' :
                  node.status === 'GEP' ? 'bg-purple-500' : 'bg-slate-300'
                }`}
                style={{ width: `${(node.current_experiment_n / 500) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Region Heatmap */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4">Design Space Region Map</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {REGION_CLAIMS.map(region => {
            const owner = region.owner_node_id ? swarmNodes.find(n => n.node_id === region.owner_node_id) : null;
            return (
              <div key={region.region_name} className={`border rounded-lg p-4 ${owner ? 'border-blue-200 bg-blue-50' : 'border-slate-200 bg-slate-50'}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-slate-900">{region.region_name.replace(/_/g, ' ')}</span>
                  {owner ? (
                    <Wifi className="w-4 h-4 text-blue-500" />
                  ) : (
                    <WifiOff className="w-4 h-4 text-slate-300" />
                  )}
                </div>
                <div className="text-xs text-slate-500 space-y-1">
                  <div className="flex justify-between"><span>Owner</span><span className={owner ? 'text-blue-700 font-medium' : 'text-slate-400'}>{owner ? owner.node_id.split('-')[1] : 'Unclaimed'}</span></div>
                  <div className="flex justify-between"><span>Parameters</span><span className="font-medium text-slate-700">{region.parameter_count}</span></div>
                  <div className="flex justify-between"><span>Experiments</span><span className="font-medium text-slate-700">{region.experiments_in_region}</span></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Swarm;
