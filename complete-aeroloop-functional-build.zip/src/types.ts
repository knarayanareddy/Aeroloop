export type LoopState = 'IDLE' | 'INITIALIZING' | 'LOOP_RUNNING' | 'LOOP_PAUSED' | 'LOOP_COMPLETE' | 'MUTATING' | 'MESHING' | 'SOLVING' | 'EVALUATING' | 'DECIDING' | 'SYNCING' | 'WIKI_COMPILING' | 'GEP_EVOLVING';

export type Stage = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

export type Decision = 'KEEP' | 'REVERT' | 'TIMEOUT' | 'MESH_FAILED' | 'UNCONVERGED';

export type Strategy = 'LOCAL_SEARCH_FINE' | 'LOCAL_SEARCH_COARSE' | 'GLOBAL_SEARCH' | 'TOPOLOGY_WINGLET' | 'TOPOLOGY_LEADING_EDGE' | 'TOPOLOGY_TRAILING_EDGE';

export type NodeStatus = 'IDLE' | 'SOLVING' | 'GEP' | 'OFFLINE' | 'STALE';

export interface WingParameters {
  semi_span_m: number;
  root_chord_m: number;
  tip_chord_m: number;
  taper_ratio: number;
  le_sweep_deg: number;
  te_sweep_deg: number;
  dihedral_deg: number;
  twist_root_deg: number;
  twist_tip_deg: number;
  tc_ratio_root: number;
  tc_ratio_tip: number;
  camber_root: number;
  camber_tip: number;
  le_radius_root: number;
  le_radius_tip: number;
  winglet_cant_deg: number;
  winglet_height_m: number;
  winglet_sweep_deg: number;
  ar: number;
  mac_m: number;
  ref_area_m2: number;
}

export interface WingParameterDef {
  id: keyof WingParameters;
  label: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  group: string;
  description: string;
}

export interface ExperimentRecord {
  experiment_n: number;
  run_id: string;
  node_id: string;
  timestamp: string;
  stage: Stage;
  decision: Decision;
  parameter_changed: string;
  old_value: number;
  new_value: number;
  reasoning: string;
  cl: number;
  cd: number;
  ld: number;
  cm: number;
  cd_wave: number;
  cd_induced: number;
  cd_viscous: number;
  buffet_margin_deg: number;
  composite_metric: number;
  metric_delta: number;
  solve_wall_time_s: number;
  mesh_cell_count: number;
  mesh_yp_avg: number;
  geometry_sha256: string;
  mesh_sha256: string;
  results_sha256: string;
  strategy: Strategy;
  genome_generation: number;
  region: string;
}

export interface MetricWeights {
  w_ld: number;
  w_buffet: number;
  w_wave: number;
}

export interface ExperimentRun {
  run_id: string;
  name: string;
  status: LoopState;
  started_at: string;
  total_experiments: number;
  kept: number;
  reverted: number;
  baseline_metric: number;
  best_metric: number;
  current_metric: number;
  target_experiments: number;
  metric_weights: MetricWeights;
  kill_timer_minutes: number;
  cfd_max_wall_time_minutes: number;
  mesh_template: 'coarse' | 'medium' | 'fine';
  solver: 'SU2' | 'OpenFOAM';
  mach: number;
  alpha_deg: number;
  reynolds_per_m: number;
}

export interface SwarmNode {
  node_id: string;
  hostname: string;
  status: NodeStatus;
  current_region: string;
  local_best_metric: number;
  current_experiment_n: number;
  experiments_per_hour: number;
  core_count: number;
  memory_gb: number;
  gpu_available: boolean;
  last_heartbeat: string;
  registered_at: string;
}

export interface RegionClaim {
  region_name: string;
  owner_node_id: string | null;
  claim_time: string | null;
  parameter_count: number;
  experiments_in_region: number;
}

export interface GEPGenome {
  genome_id: string;
  generation: number;
  created_at_experiment: number;
  strategy: Strategy;
  step_size_multiplier: number;
  focus_parameters: string[];
  patience: number;
  topology_probability: number;
  fitness: number;
  parent_ids: string[];
  mutations_applied: string[];
}

export interface KnowledgeGraphNode {
  parameter_id: string;
  sensitivity: number;
  impact_on_metric: number;
  experiment_count: number;
  dead_zone: boolean;
  hot_zone: boolean;
  interactions: string[];
}

export interface KnowledgeGraphEdge {
  source: string;
  target: string;
  interaction_strength: number;
  discovered_at_experiment: number;
}

export interface WikiArticle {
  title: string;
  path: string;
  compiled_at: string;
  experiment_range: [number, number];
  summary: string;
  content: string;
  parameter_ids: string[];
}

export interface PipelineStage {
  stage: Stage;
  name: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  agent: string;
  last_execution_time_s: number;
  success_rate: number;
}

export interface MetricHistoryPoint {
  experiment_n: number;
  timestamp: string;
  composite_metric: number;
  ld: number;
  cd: number;
  cd_wave: number;
  decision: Decision;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  source: string;
  message: string;
  experiment_n?: number;
  node_id?: string;
}

export interface GeometryMutation {
  mutation_type: string;
  parameter: string;
  old_value: number;
  new_value: number;
  reasoning: string;
  expected_metric_delta: number;
  confidence: number;
}
