import type {
  ExperimentRecord, ExperimentRun, SwarmNode, RegionClaim,
  GEPGenome, KnowledgeGraphNode, KnowledgeGraphEdge, WikiArticle,
  PipelineStage, MetricHistoryPoint, LogEntry, WingParameters, WingParameterDef,
  GeometryMutation
} from '../types';

// ===== WING PARAMETER REGISTRY =====
export const PARAMETER_REGISTRY: WingParameterDef[] = [
  { id: 'semi_span_m', label: 'Semi-Span', unit: 'm', min: 10, max: 40, step: 0.1, group: 'Planform Core', description: 'Half wingspan from root to tip' },
  { id: 'root_chord_m', label: 'Root Chord', unit: 'm', min: 3, max: 12, step: 0.01, group: 'Planform Core', description: 'Chord length at wing root' },
  { id: 'tip_chord_m', label: 'Tip Chord', unit: 'm', min: 1, max: 6, step: 0.01, group: 'Planform Core', description: 'Chord length at wing tip' },
  { id: 'taper_ratio', label: 'Taper Ratio', unit: '', min: 0.15, max: 0.6, step: 0.01, group: 'Planform Core', description: 'Tip chord / Root chord ratio' },
  { id: 'le_sweep_deg', label: 'LE Sweep', unit: '°', min: 0, max: 45, step: 0.1, group: 'Planform Sweep', description: 'Leading edge sweep angle' },
  { id: 'te_sweep_deg', label: 'TE Sweep', unit: '°', min: -10, max: 20, step: 0.1, group: 'Planform Sweep', description: 'Trailing edge sweep angle' },
  { id: 'dihedral_deg', label: 'Dihedral', unit: '°', min: -5, max: 10, step: 0.1, group: 'Planform Sweep', description: 'Wing dihedral angle' },
  { id: 'twist_root_deg', label: 'Twist Root', unit: '°', min: -2, max: 4, step: 0.05, group: 'Twist', description: 'Geometric twist at root section' },
  { id: 'twist_tip_deg', label: 'Twist Tip (Washout)', unit: '°', min: -6, max: 0, step: 0.05, group: 'Twist', description: 'Geometric twist at tip (negative = washout)' },
  { id: 'tc_ratio_root', label: 't/c Root', unit: '', min: 0.06, max: 0.20, step: 0.001, group: 'Thickness', description: 'Thickness-to-chord ratio at root' },
  { id: 'tc_ratio_tip', label: 't/c Tip', unit: '', min: 0.06, max: 0.15, step: 0.001, group: 'Thickness', description: 'Thickness-to-chord ratio at tip' },
  { id: 'camber_root', label: 'Camber Root', unit: '', min: 0, max: 0.06, step: 0.001, group: 'Camber', description: 'Max camber ratio at root' },
  { id: 'camber_tip', label: 'Camber Tip', unit: '', min: 0, max: 0.04, step: 0.001, group: 'Camber', description: 'Max camber ratio at tip' },
  { id: 'le_radius_root', label: 'LE Radius Root', unit: '', min: 0.005, max: 0.04, step: 0.001, group: 'LE Shaping', description: 'Leading edge radius / chord at root' },
  { id: 'le_radius_tip', label: 'LE Radius Tip', unit: '', min: 0.005, max: 0.03, step: 0.001, group: 'LE Shaping', description: 'Leading edge radius / chord at tip' },
  { id: 'winglet_cant_deg', label: 'Winglet Cant', unit: '°', min: 0, max: 80, step: 1, group: 'Winglet', description: 'Winglet cant angle from vertical' },
  { id: 'winglet_height_m', label: 'Winglet Height', unit: 'm', min: 0, max: 3.5, step: 0.1, group: 'Winglet', description: 'Winglet span height' },
  { id: 'winglet_sweep_deg', label: 'Winglet Sweep', unit: '°', min: 20, max: 60, step: 1, group: 'Winglet', description: 'Winglet sweep angle' },
];

// ===== CURRENT WING GEOMETRY =====
export const CURRENT_WING: WingParameters = {
  semi_span_m: 17.28,
  root_chord_m: 7.82,
  tip_chord_m: 2.89,
  taper_ratio: 0.370,
  le_sweep_deg: 26.5,
  te_sweep_deg: 4.2,
  dihedral_deg: 5.5,
  twist_root_deg: 1.2,
  twist_tip_deg: -3.4,
  tc_ratio_root: 0.128,
  tc_ratio_tip: 0.098,
  camber_root: 0.028,
  camber_tip: 0.015,
  le_radius_root: 0.022,
  le_radius_tip: 0.012,
  winglet_cant_deg: 42,
  winglet_height_m: 2.1,
  winglet_sweep_deg: 38,
  ar: 9.42,
  mac_m: 5.62,
  ref_area_m2: 63.52,
};

// ===== EXPERIMENT RUN =====
export const CURRENT_RUN: ExperimentRun = {
  run_id: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890',
  name: 'Transonic Transport Wing Optimization — Run #7',
  status: 'LOOP_RUNNING',
  started_at: '2026-04-26T08:00:00Z',
  total_experiments: 247,
  kept: 89,
  reverted: 158,
  baseline_metric: 0.8542,
  best_metric: 0.9147,
  current_metric: 0.9121,
  target_experiments: 500,
  metric_weights: { w_ld: 0.55, w_buffet: 0.25, w_wave: 0.20 },
  kill_timer_minutes: 8,
  cfd_max_wall_time_minutes: 8,
  mesh_template: 'medium',
  solver: 'SU2',
  mach: 0.785,
  alpha_deg: 2.8,
  reynolds_per_m: 6.5e6,
};

// ===== GENERATE EXPERIMENT HISTORY =====
function generateExperiments(count: number): ExperimentRecord[] {
  const experiments: ExperimentRecord[] = [];
  const params = ['taper_ratio', 'le_sweep_deg', 'twist_tip_deg', 'tc_ratio_root', 'tc_ratio_tip', 'camber_root', 'camber_tip', 'le_radius_root', 'dihedral_deg', 'winglet_cant_deg', 'winglet_height_m', 'twist_root_deg', 'te_sweep_deg', 'le_radius_tip'];
  const strategies: Array<'LOCAL_SEARCH_FINE' | 'LOCAL_SEARCH_COARSE' | 'GLOBAL_SEARCH'> = ['LOCAL_SEARCH_FINE', 'LOCAL_SEARCH_COARSE', 'GLOBAL_SEARCH'];
  const regions = ['PLANFORM_CORE', 'PLANFORM_SWEEP', 'TWIST', 'THICKNESS', 'CAMBER', 'LE_SHAPING', 'WINGLET', 'GLOBAL'];
  const nodes = ['node-alpha-7f3a', 'node-beta-2c8d', 'node-gamma-9e1b', 'node-delta-4a6f'];

  let metric = 0.8542;
  let bestMetric = 0.8542;

  for (let i = 0; i < count; i++) {
    const improved = Math.random() < 0.36;
    const param = params[Math.floor(Math.random() * params.length)];
    const oldValue = parseFloat((Math.random() * 0.5 + 0.1).toFixed(4));
    const newValue = parseFloat((oldValue + (Math.random() - 0.5) * 0.1).toFixed(4));
    const delta = improved ? (Math.random() * 0.005 + 0.0001) : -(Math.random() * 0.003 + 0.0001);
    metric = improved ? metric + delta : metric - delta * 0.3;
    if (metric > bestMetric) bestMetric = metric;
    const cl = 0.48 + Math.random() * 0.06;
    const cd = 0.0220 + Math.random() * 0.004;
    const ld = cl / cd;

    experiments.push({
      experiment_n: i,
      run_id: CURRENT_RUN.run_id,
      node_id: nodes[Math.floor(Math.random() * nodes.length)],
      timestamp: new Date(Date.now() - (count - i) * 180000).toISOString(),
      stage: 5,
      decision: improved ? 'KEEP' : 'REVERT',
      parameter_changed: param,
      old_value: oldValue,
      new_value: newValue,
      reasoning: getReasoning(param, improved),
      cl: parseFloat(cl.toFixed(4)),
      cd: parseFloat(cd.toFixed(5)),
      ld: parseFloat(ld.toFixed(2)),
      cm: parseFloat((-0.08 + Math.random() * 0.04).toFixed(4)),
      cd_wave: parseFloat((0.003 + Math.random() * 0.004).toFixed(5)),
      cd_induced: parseFloat((cl * cl / (Math.PI * 9.42 * 0.85)).toFixed(5)),
      cd_viscous: parseFloat((0.014 + Math.random() * 0.003).toFixed(5)),
      buffet_margin_deg: parseFloat((2.5 + Math.random() * 3).toFixed(2)),
      composite_metric: parseFloat(metric.toFixed(6)),
      metric_delta: parseFloat(delta.toFixed(6)),
      solve_wall_time_s: parseFloat((180 + Math.random() * 240).toFixed(1)),
      mesh_cell_count: Math.floor(1800000 + Math.random() * 400000),
      mesh_yp_avg: parseFloat((0.8 + Math.random() * 0.8).toFixed(2)),
      geometry_sha256: generateHash(),
      mesh_sha256: generateHash(),
      results_sha256: generateHash(),
      strategy: strategies[Math.floor(Math.random() * strategies.length)],
      genome_generation: Math.floor(i / 50),
      region: regions[Math.floor(Math.random() * regions.length)],
    });
  }
  return experiments;
}

function getReasoning(param: string, _improved: boolean): string {
  const reasons: Record<string, string[]> = {
    taper_ratio: [
      'Reducing taper shifts load inboard, lowering induced drag at the cost of slightly higher root bending moment.',
      'Wiki article twist-sensitivity.md indicates interaction: taper+twist coupling yields 0.8% drag reduction at cruise CL.',
      'Increasing taper toward 0.40 shows diminishing returns from prior 3 experiments in this region.',
    ],
    le_sweep_deg: [
      'Knowledge graph indicates LE sweep is in a hot zone — sensitivity 0.72. Increasing sweep to delay drag divergence.',
      'Reducing sweep by 0.5° to evaluate wave drag trade-off at Mach 0.785.',
      'Sweep sensitivity plateau detected at 26.5°. Exploring ±1° range for local optimum.',
    ],
    twist_tip_deg: [
      'Increasing washout at section 3 reduces induced drag by ~0.8% at cruise CL=0.5 without significant wave drag penalty.',
      'Twist distribution optimization: shifting from linear to nonlinear washout profile per wiki recommendations.',
      'Tip twist at -3.4° shows optimal span loading. Fine-tuning within ±0.2° range.',
    ],
    tc_ratio_root: [
      'Root t/c of 0.128 provides adequate fuel volume. Testing slight reduction for lower wave drag.',
      'Thickness optimization bounded by structural minimum of 0.11. Exploring 0.124–0.132 range.',
      'Wave drag sensitivity to root thickness is 0.65 per knowledge graph. Perturbing by -0.004.',
    ],
    camber_root: [
      'Increasing root camber improves CL_max without significant cruise drag penalty per wiki article.',
      'Camber redistribution: increasing root, decreasing tip for more uniform spanwise loading.',
      'Root camber at 0.028 is near optimal. Testing minor perturbation for gradient direction.',
    ],
    winglet_cant_deg: [
      'Winglet cant angle of 42° balances induced drag reduction against profile drag addition.',
      'Testing increased cant to 45° based on GEP genome generation 4 recommendation.',
      'Winglet cant sensitivity moderate at 0.45. Exploring 40–50° range.',
    ],
  };
  const paramReasons = reasons[param] || ['Parameter perturbation based on knowledge graph sensitivity analysis.', 'Following GEP genome strategy for focused parameter exploration.', 'Local search refinement within current confidence interval.'];
  return paramReasons[Math.floor(Math.random() * paramReasons.length)];
}

function generateHash(): string {
  const chars = '0123456789abcdef';
  let hash = '';
  for (let i = 0; i < 64; i++) hash += chars[Math.floor(Math.random() * 16)];
  return hash;
}

export const EXPERIMENTS: ExperimentRecord[] = generateExperiments(247);

// ===== METRIC HISTORY =====
export function getMetricHistory(): MetricHistoryPoint[] {
  return EXPERIMENTS.map(e => ({
    experiment_n: e.experiment_n,
    timestamp: e.timestamp,
    composite_metric: e.composite_metric,
    ld: e.ld,
    cd: e.cd,
    cd_wave: e.cd_wave,
    decision: e.decision,
  }));
}

// ===== SWARM NODES =====
export const SWARM_NODES: SwarmNode[] = [
  {
    node_id: 'node-alpha-7f3a',
    hostname: 'aeroloop-gpu-01.internal',
    status: 'SOLVING',
    current_region: 'PLANFORM_CORE',
    local_best_metric: 0.9147,
    current_experiment_n: 247,
    experiments_per_hour: 14.2,
    core_count: 64,
    memory_gb: 256,
    gpu_available: true,
    last_heartbeat: new Date(Date.now() - 8000).toISOString(),
    registered_at: '2026-04-26T08:00:12Z',
  },
  {
    node_id: 'node-beta-2c8d',
    hostname: 'aeroloop-gpu-02.internal',
    status: 'SOLVING',
    current_region: 'TWIST',
    local_best_metric: 0.9102,
    current_experiment_n: 198,
    experiments_per_hour: 11.8,
    core_count: 64,
    memory_gb: 256,
    gpu_available: true,
    last_heartbeat: new Date(Date.now() - 12000).toISOString(),
    registered_at: '2026-04-26T08:01:45Z',
  },
  {
    node_id: 'node-gamma-9e1b',
    hostname: 'aeroloop-gpu-03.internal',
    status: 'IDLE',
    current_region: 'THICKNESS',
    local_best_metric: 0.9068,
    current_experiment_n: 156,
    experiments_per_hour: 9.4,
    core_count: 32,
    memory_gb: 128,
    gpu_available: true,
    last_heartbeat: new Date(Date.now() - 15000).toISOString(),
    registered_at: '2026-04-26T08:02:30Z',
  },
  {
    node_id: 'node-delta-4a6f',
    hostname: 'aeroloop-cpu-01.internal',
    status: 'SOLVING',
    current_region: 'WINGLET',
    local_best_metric: 0.9015,
    current_experiment_n: 134,
    experiments_per_hour: 6.1,
    core_count: 128,
    memory_gb: 512,
    gpu_available: false,
    last_heartbeat: new Date(Date.now() - 20000).toISOString(),
    registered_at: '2026-04-26T08:03:15Z',
  },
];

// ===== REGION CLAIMS =====
export const REGION_CLAIMS: RegionClaim[] = [
  { region_name: 'PLANFORM_CORE', owner_node_id: 'node-alpha-7f3a', claim_time: new Date(Date.now() - 3600000).toISOString(), parameter_count: 5, experiments_in_region: 62 },
  { region_name: 'PLANFORM_SWEEP', owner_node_id: null, claim_time: null, parameter_count: 3, experiments_in_region: 38 },
  { region_name: 'TWIST', owner_node_id: 'node-beta-2c8d', claim_time: new Date(Date.now() - 2400000).toISOString(), parameter_count: 2, experiments_in_region: 45 },
  { region_name: 'THICKNESS', owner_node_id: 'node-gamma-9e1b', claim_time: new Date(Date.now() - 1800000).toISOString(), parameter_count: 2, experiments_in_region: 33 },
  { region_name: 'CAMBER', owner_node_id: null, claim_time: null, parameter_count: 2, experiments_in_region: 28 },
  { region_name: 'LE_SHAPING', owner_node_id: null, claim_time: null, parameter_count: 2, experiments_in_region: 21 },
  { region_name: 'WINGLET', owner_node_id: 'node-delta-4a6f', claim_time: new Date(Date.now() - 1200000).toISOString(), parameter_count: 3, experiments_in_region: 15 },
  { region_name: 'GLOBAL', owner_node_id: null, claim_time: null, parameter_count: 19, experiments_in_region: 5 },
];

// ===== GEP GENOMES =====
export const GEP_GENOMES: GEPGenome[] = [
  {
    genome_id: 'gen-g0-0001',
    generation: 0,
    created_at_experiment: 0,
    strategy: 'LOCAL_SEARCH_FINE',
    step_size_multiplier: 1.0,
    focus_parameters: ['taper_ratio', 'twist_tip_deg', 'tc_ratio_root'],
    patience: 10,
    topology_probability: 0.0,
    fitness: 0.8542,
    parent_ids: [],
    mutations_applied: ['INITIAL'],
  },
  {
    genome_id: 'gen-g1-0002',
    generation: 1,
    created_at_experiment: 50,
    strategy: 'LOCAL_SEARCH_COARSE',
    step_size_multiplier: 1.8,
    focus_parameters: ['le_sweep_deg', 'taper_ratio', 'camber_root'],
    patience: 12,
    topology_probability: 0.0,
    fitness: 0.8789,
    parent_ids: ['gen-g0-0001'],
    mutations_applied: ['strategy→COARSE', 'step_size→1.8'],
  },
  {
    genome_id: 'gen-g2-0003',
    generation: 2,
    created_at_experiment: 100,
    strategy: 'LOCAL_SEARCH_FINE',
    step_size_multiplier: 0.7,
    focus_parameters: ['twist_tip_deg', 'tc_ratio_tip', 'camber_tip'],
    patience: 8,
    topology_probability: 0.0,
    fitness: 0.8956,
    parent_ids: ['gen-g1-0002', 'gen-g0-0001'],
    mutations_applied: ['strategy→FINE', 'crossover_focus_params'],
  },
  {
    genome_id: 'gen-g3-0004',
    generation: 3,
    created_at_experiment: 150,
    strategy: 'LOCAL_SEARCH_COARSE',
    step_size_multiplier: 2.2,
    focus_parameters: ['winglet_cant_deg', 'winglet_height_m', 'le_sweep_deg'],
    patience: 15,
    topology_probability: 0.05,
    fitness: 0.9078,
    parent_ids: ['gen-g2-0003'],
    mutations_applied: ['step_size→2.2', 'topology_prob→0.05', 'focus→winglet'],
  },
  {
    genome_id: 'gen-g4-0005',
    generation: 4,
    created_at_experiment: 200,
    strategy: 'GLOBAL_SEARCH',
    step_size_multiplier: 2.8,
    focus_parameters: ['le_sweep_deg', 'taper_ratio', 'tc_ratio_root', 'twist_tip_deg'],
    patience: 20,
    topology_probability: 0.08,
    fitness: 0.9147,
    parent_ids: ['gen-g3-0004', 'gen-g2-0003'],
    mutations_applied: ['strategy→GLOBAL', 'step_size→2.8', 'crossover_all'],
  },
];

// ===== KNOWLEDGE GRAPH =====
export const KNOWLEDGE_NODES: KnowledgeGraphNode[] = [
  { parameter_id: 'taper_ratio', sensitivity: 0.82, impact_on_metric: 0.034, experiment_count: 62, dead_zone: false, hot_zone: true, interactions: ['twist_tip_deg', 'tc_ratio_root'] },
  { parameter_id: 'le_sweep_deg', sensitivity: 0.72, impact_on_metric: 0.028, experiment_count: 38, dead_zone: false, hot_zone: true, interactions: ['taper_ratio', 'tc_ratio_root'] },
  { parameter_id: 'twist_tip_deg', sensitivity: 0.68, impact_on_metric: 0.022, experiment_count: 45, dead_zone: false, hot_zone: false, interactions: ['taper_ratio', 'twist_root_deg'] },
  { parameter_id: 'tc_ratio_root', sensitivity: 0.65, impact_on_metric: 0.019, experiment_count: 33, dead_zone: false, hot_zone: false, interactions: ['le_sweep_deg', 'tc_ratio_tip'] },
  { parameter_id: 'tc_ratio_tip', sensitivity: 0.45, impact_on_metric: 0.012, experiment_count: 21, dead_zone: false, hot_zone: false, interactions: ['tc_ratio_root'] },
  { parameter_id: 'camber_root', sensitivity: 0.58, impact_on_metric: 0.018, experiment_count: 28, dead_zone: false, hot_zone: false, interactions: ['twist_tip_deg'] },
  { parameter_id: 'camber_tip', sensitivity: 0.32, impact_on_metric: 0.008, experiment_count: 18, dead_zone: true, hot_zone: false, interactions: ['camber_root'] },
  { parameter_id: 'dihedral_deg', sensitivity: 0.15, impact_on_metric: 0.003, experiment_count: 12, dead_zone: true, hot_zone: false, interactions: [] },
  { parameter_id: 'le_radius_root', sensitivity: 0.48, impact_on_metric: 0.014, experiment_count: 22, dead_zone: false, hot_zone: false, interactions: ['le_radius_tip', 'tc_ratio_root'] },
  { parameter_id: 'le_radius_tip', sensitivity: 0.28, impact_on_metric: 0.006, experiment_count: 14, dead_zone: true, hot_zone: false, interactions: ['le_radius_root'] },
  { parameter_id: 'winglet_cant_deg', sensitivity: 0.52, impact_on_metric: 0.016, experiment_count: 15, dead_zone: false, hot_zone: false, interactions: ['winglet_height_m'] },
  { parameter_id: 'winglet_height_m', sensitivity: 0.41, impact_on_metric: 0.011, experiment_count: 12, dead_zone: false, hot_zone: false, interactions: ['winglet_cant_deg'] },
  { parameter_id: 'twist_root_deg', sensitivity: 0.38, impact_on_metric: 0.009, experiment_count: 16, dead_zone: false, hot_zone: false, interactions: ['twist_tip_deg'] },
  { parameter_id: 'te_sweep_deg', sensitivity: 0.12, impact_on_metric: 0.002, experiment_count: 8, dead_zone: true, hot_zone: false, interactions: ['le_sweep_deg'] },
];

export const KNOWLEDGE_EDGES: KnowledgeGraphEdge[] = [
  { source: 'taper_ratio', target: 'twist_tip_deg', interaction_strength: 0.78, discovered_at_experiment: 34 },
  { source: 'taper_ratio', target: 'tc_ratio_root', interaction_strength: 0.62, discovered_at_experiment: 56 },
  { source: 'le_sweep_deg', target: 'tc_ratio_root', interaction_strength: 0.71, discovered_at_experiment: 78 },
  { source: 'le_sweep_deg', target: 'taper_ratio', interaction_strength: 0.55, discovered_at_experiment: 92 },
  { source: 'twist_tip_deg', target: 'twist_root_deg', interaction_strength: 0.65, discovered_at_experiment: 41 },
  { source: 'tc_ratio_root', target: 'tc_ratio_tip', interaction_strength: 0.58, discovered_at_experiment: 67 },
  { source: 'le_radius_root', target: 'tc_ratio_root', interaction_strength: 0.52, discovered_at_experiment: 88 },
  { source: 'le_radius_root', target: 'le_radius_tip', interaction_strength: 0.45, discovered_at_experiment: 102 },
  { source: 'winglet_cant_deg', target: 'winglet_height_m', interaction_strength: 0.68, discovered_at_experiment: 156 },
  { source: 'camber_root', target: 'twist_tip_deg', interaction_strength: 0.42, discovered_at_experiment: 73 },
];

// ===== WIKI ARTICLES =====
export const WIKI_ARTICLES: WikiArticle[] = [
  {
    title: 'Twist Distribution Sensitivity Analysis',
    path: 'aerodynamics/twist-sensitivity.md',
    compiled_at: '2026-04-26T14:30:00Z',
    experiment_range: [1, 50],
    summary: 'Nonlinear twist distributions outperform linear by 1.2% L/D. Optimal washout at section 3 is -3.4° ± 0.3°. Strong coupling with taper ratio discovered.',
    content: `# Twist Distribution Sensitivity Analysis\n\n## Summary\nAnalysis of 50 experiments reveals that nonlinear twist distributions yield a **1.2% L/D improvement** over linear distributions at Mach 0.785, α=2.8°.\n\n## Key Findings\n\n### Optimal Washout Profile\n- **Section 1 (root):** 1.2° ± 0.1° — minimal deviation from baseline\n- **Section 2 (mid-span):** -0.8° ± 0.2° — slight negative twist begins\n- **Section 3 (outer):** -3.4° ± 0.3° — maximum washout concentrated here\n- **Section 4 (tip):** -3.2° ± 0.2° — slight reduction from section 3 peak\n\n### Taper Ratio Coupling\nThe optimal twist distribution is **strongly coupled** to taper ratio (interaction strength: 0.78). At taper=0.37, the optimal washout is -3.4°; at taper=0.42, it shifts to -2.8°. This interaction was discovered at experiment 34.\n\n### Drag Decomposition\n| Component | Baseline | Optimized | Change |\n|-----------|----------|-----------|--------|\n| CD_induced | 0.00891 | 0.00852 | -4.4% |\n| CD_wave | 0.00412 | 0.00398 | -3.4% |\n| CD_viscous | 0.01520 | 0.01518 | -0.1% |\n\n### Dead Zone Alert\nNo improvement found for twist_root_deg in range [0.8°, 1.6°]. Root twist is in a dead zone — recommend allocating mutation budget elsewhere.`,
    parameter_ids: ['twist_root_deg', 'twist_tip_deg', 'taper_ratio'],
  },
  {
    title: 'Leading Edge Sweep Impact on Wave Drag',
    path: 'aerodynamics/sweep-wave-drag.md',
    compiled_at: '2026-04-26T16:00:00Z',
    experiment_range: [51, 100],
    summary: 'LE sweep at 26.5° is near-optimal for Mach 0.785. Wave drag increases sharply above 28° due to earlier shock formation. Interaction with root thickness discovered.',
    content: `# Leading Edge Sweep Impact on Wave Drag\n\n## Summary\n38 experiments on LE sweep reveal a **sharp wave drag penalty** above 28° at Mach 0.785. The current value of 26.5° is within the optimal basin.\n\n## Wave Drag vs. LE Sweep\n| Sweep (°) | CD_wave | L/D | Metric M |\n|-----------|---------|-----|----------|\n| 24.0 | 0.00485 | 19.8 | 0.8734 |\n| 25.0 | 0.00432 | 20.1 | 0.8856 |\n| 26.0 | 0.00398 | 20.4 | 0.8978 |\n| 26.5 | 0.00382 | 20.5 | 0.9042 |\n| 27.0 | 0.00388 | 20.4 | 0.9018 |\n| 28.0 | 0.00441 | 20.0 | 0.8834 |\n| 30.0 | 0.00562 | 19.2 | 0.8512 |\n\n## Root Thickness Interaction\nAt tc_ratio_root=0.128, the optimal sweep is 26.5°. Increasing thickness to 0.132 shifts the optimum to 25.0° — the interaction strength is 0.71.\n\n## Recommendation\nLE sweep is in a **hot zone** (sensitivity 0.72). Fine-tune within ±0.5°. Do NOT increase above 28°.`,
    parameter_ids: ['le_sweep_deg', 'tc_ratio_root', 'tc_ratio_tip'],
  },
  {
    title: 'Winglet Geometry Optimization',
    path: 'aerodynamics/winglet-optimization.md',
    compiled_at: '2026-04-26T18:00:00Z',
    experiment_range: [151, 200],
    summary: 'Winglet cant 42° and height 2.1m provide 2.1% induced drag reduction. Toe-out angle of 3° further improves performance. GEP topology mutation enabled.',
    content: `# Winglet Geometry Optimization\n\n## Summary\nAfter 15 experiments focused on winglet parameters, the current configuration (cant=42°, height=2.1m) provides a **2.1% induced drag reduction** over the no-winglet baseline.\n\n## Parameter Sensitivity\n- **Cant angle:** Sensitivity 0.52. Optimal range 40–45°. Beyond 50°, profile drag dominates.\n- **Height:** Sensitivity 0.41. Optimal range 1.8–2.4m. Structural bending moment limits further increase.\n- **Sweep:** Sensitivity 0.22. Minimal impact at cruise conditions.\n\n## GEP Topology Discovery\nGEP generation 3 enabled topology mutations with probability 0.05. The winglet was added at experiment 162 and has been retained since.\n\n## Recommendations\n- Fine-tune cant within 40–44°\n- Test height increase to 2.3m with structural check\n- Winglet sweep is in a dead zone — deprioritize`,
    parameter_ids: ['winglet_cant_deg', 'winglet_height_m', 'winglet_sweep_deg'],
  },
  {
    title: 'Thickness & Camber Distribution Effects',
    path: 'aerodynamics/thickness-camber.md',
    compiled_at: '2026-04-26T19:30:00Z',
    experiment_range: [101, 150],
    summary: 'Root t/c of 0.128 balances fuel volume and wave drag. Camber redistribution (root 0.028, tip 0.015) optimizes spanwise loading. Tip camber in dead zone.',
    content: `# Thickness & Camber Distribution Effects\n\n## Summary\nCombined analysis of 55 experiments on thickness and camber parameters reveals optimal distributions that balance aerodynamic efficiency with structural feasibility.\n\n## Thickness Distribution\n- **Root t/c = 0.128:** Optimal for Mach 0.785 cruise. Below 0.120, wave drag increases sharply. Above 0.135, profile drag dominates.\n- **Tip t/c = 0.098:** Near-optimal. Range [0.095, 0.102] shows flat response — potential dead zone.\n\n## Camber Distribution\n- **Root camber = 0.028:** Strong impact on CL_max and cruise CL capability. Sensitivity 0.58.\n- **Tip camber = 0.015:** **Dead zone declared** at experiment 138. Sensitivity only 0.32. Reallocating budget.\n\n## Interaction: Thickness × Sweep\nRoot thickness and LE sweep show interaction strength 0.71. The optimum (t/c, sweep) pair shifts along a diagonal in parameter space.`,
    parameter_ids: ['tc_ratio_root', 'tc_ratio_tip', 'camber_root', 'camber_tip'],
  },
  {
    title: 'Composite Metric Convergence Analysis',
    path: 'aerodynamics/convergence-analysis.md',
    compiled_at: '2026-04-26T21:00:00Z',
    experiment_range: [201, 247],
    summary: 'Metric M has improved 7.1% from baseline (0.8542 → 0.9147). Convergence rate slowing — GEP recommends global search strategy. Plateau detection at 230+.',
    content: `# Composite Metric Convergence Analysis\n\n## Overview\nAfter 247 experiments across 4 swarm nodes, the composite metric has improved **7.1%** from baseline.\n\n## Convergence Timeline\n| Phase | Experiments | Metric Gain | Rate (per 50 exp) |\n|-------|-------------|-------------|-------------------|\n| Initial | 0–50 | +0.0247 | +0.0247 |\n| Exploration | 51–100 | +0.0167 | +0.0167 |\n| Refinement | 101–150 | +0.0122 | +0.0122 |\n| Fine-tune | 151–200 | +0.0069 | +0.0069 |\n| Plateau | 201–247 | +0.0022 | +0.0024 (projected) |\n\n## Plateau Detection\nThe convergence rate has dropped by **90%** from initial phase. The GEP evolver (generation 4) has switched to **GLOBAL_SEARCH** strategy with step_size_multiplier=2.8 to escape the current local optimum.\n\n## Per-Parameter Convergence\n- **Taper ratio:** Converged at 0.370 ± 0.005. Hot zone.\n- **LE sweep:** Converged at 26.5° ± 0.3°. Hot zone.\n- **Twist tip:** Still improving at -3.4° ± 0.2°. Active.\n- **Winglet parameters:** Newly added, still exploring. Active.\n\n## Prediction\nWith global search enabled, expected additional improvement of 1–2% over next 250 experiments.`,
    parameter_ids: ['taper_ratio', 'le_sweep_deg', 'twist_tip_deg', 'winglet_cant_deg'],
  },
];

// ===== PIPELINE STAGES =====
export const PIPELINE_STAGES: PipelineStage[] = [
  { stage: 0, name: 'Initialization', description: 'Load baseline geometry, configure metric, validate environment', status: 'completed', agent: 'InitAgent', last_execution_time_s: 12.4, success_rate: 1.0 },
  { stage: 1, name: 'Geometry Mutation', description: 'Propose one parameter change based on knowledge graph and wiki', status: 'running', agent: 'GeometryMutationAgent', last_execution_time_s: 8.2, success_rate: 0.94 },
  { stage: 2, name: 'Mesh Generation', description: 'GMSH auto-meshing with y+ targeting and quality validation', status: 'pending', agent: 'MeshGeneratorAgent', last_execution_time_s: 45.6, success_rate: 0.97 },
  { stage: 3, name: 'CFD Solve', description: 'SU2 RANS solve with kill timer enforcement', status: 'pending', agent: 'CFDSolverAgent', last_execution_time_s: 312.8, success_rate: 0.89 },
  { stage: 4, name: 'Results Extraction', description: 'Parse polars, compute wave drag, buffet margin, composite metric', status: 'pending', agent: 'PolarsExtractorAgent', last_execution_time_s: 3.1, success_rate: 0.99 },
  { stage: 5, name: 'Keep / Revert Decision', description: 'Compare metric to baseline, execute git commit or checkout', status: 'pending', agent: 'KeepRevertAgent', last_execution_time_s: 1.8, success_rate: 1.0 },
  { stage: 6, name: 'Wiki Compilation', description: 'Compile aerodynamic knowledge articles every 10 experiments', status: 'pending', agent: 'WikiCompilerAgent', last_execution_time_s: 142.5, success_rate: 0.92 },
  { stage: 7, name: 'Knowledge Graph Update', description: 'Update parameter sensitivity and interaction graph', status: 'pending', agent: 'KnowledgeGraphAgent', last_execution_time_s: 6.7, success_rate: 0.98 },
  { stage: 8, name: 'GEP Evolution', description: 'Genome Evolution Protocol — evolve mutation strategy every 500 experiments', status: 'pending', agent: 'GEPOrchestrator', last_execution_time_s: 0, success_rate: 1.0 },
  { stage: 9, name: 'Swarm Coordination', description: 'Multi-node design space partitioning and knowledge sync', status: 'completed', agent: 'SwarmSyncAgent', last_execution_time_s: 2.3, success_rate: 0.95 },
];

// ===== LIVE LOG ENTRIES =====
export function generateLogs(count: number): LogEntry[] {
  const entries: LogEntry[] = [];
  const templates = [
    { level: 'info' as const, source: 'GeometryMutationAgent', message: 'Proposed mutation: taper_ratio 0.370 → 0.365 (confidence: 0.72)' },
    { level: 'success' as const, source: 'PhysicsBoundsChecker', message: 'Bounds validation passed for all 19 parameters' },
    { level: 'info' as const, source: 'MeshGeneratorAgent', message: 'GMSH mesh complete: 2.14M cells, y+ avg=0.92' },
    { level: 'info' as const, source: 'CFDSolverAgent', message: 'SU2 RANS solve converged in 312 iterations (284.6s wall time)' },
    { level: 'success' as const, source: 'KeepRevertAgent', message: 'EXP(247): KEEP — taper_ratio 0.370→0.365 | M=0.9147 Δ=+0.0032' },
    { level: 'info' as const, source: 'KnowledgeGraphAgent', message: 'KG update: taper_ratio sensitivity 0.82 (hot zone confirmed)' },
    { level: 'warn' as const, source: 'WikiCompilerAgent', message: 'Wiki compilation triggered at experiment 240 — background mode' },
    { level: 'info' as const, source: 'SwarmSyncAgent', message: 'Node alpha claimed PLANFORM_CORE, node beta claimed TWIST' },
    { level: 'info' as const, source: 'GEPOrchestrator', message: 'GEP generation 4 active: GLOBAL_SEARCH, fitness=0.9147' },
    { level: 'error' as const, source: 'CFDSolverAgent', message: 'Solve timeout at 480s — kill timer activated, geometry reverted' },
    { level: 'warn' as const, source: 'MeshGeneratorAgent', message: 'Mesh quality warning: max non-orthogonality 74.2° (threshold 75°)' },
    { level: 'info' as const, source: 'KeepRevertAgent', message: 'EXP(244): REVERT — dihedral_deg 5.5→5.8 | M=0.9118 Δ=-0.0003' },
    { level: 'success' as const, source: 'SwarmSyncAgent', message: 'Global best updated: M=0.9147 by node-alpha-7f3a' },
    { level: 'info' as const, source: 'GeometryMutationAgent', message: 'Reading wiki article: twist-sensitivity.md before mutation proposal' },
    { level: 'warn' as const, source: 'SanityChecker', message: 'CD=0.0264 exceeds typical range for this configuration — logging warning' },
  ];
  const nodes = ['node-alpha-7f3a', 'node-beta-2c8d', 'node-gamma-9e1b', 'node-delta-4a6f'];

  for (let i = 0; i < count; i++) {
    const template = templates[Math.floor(Math.random() * templates.length)];
    entries.push({
      id: `log-${i}`,
      timestamp: new Date(Date.now() - (count - i) * 12000).toISOString(),
      level: template.level,
      source: template.source,
      message: template.message,
      experiment_n: Math.floor(Math.random() * 247),
      node_id: nodes[Math.floor(Math.random() * nodes.length)],
    });
  }
  return entries;
}

export const LIVE_LOGS: LogEntry[] = generateLogs(60);

// ===== PENDING MUTATION =====
export const PENDING_MUTATION: GeometryMutation = {
  mutation_type: 'parameter_change',
  parameter: 'twist_tip_deg',
  old_value: -3.4,
  new_value: -3.7,
  reasoning: 'Knowledge graph shows twist_tip_deg sensitivity at 0.68 with hot interaction to taper_ratio. Wiki article twist-sensitivity.md confirms optimal range [-3.7, -3.1] at current taper=0.370. Shifting toward lower bound for induced drag reduction.',
  expected_metric_delta: 0.0018,
  confidence: 0.71,
};

// ===== AERO DATA FOR CHARTS =====
export const MACH_SWEEP_DATA = [
  { sweep: 24, cd_wave_m078: 0.00485, cd_wave_m080: 0.00582, cd_wave_m082: 0.00821 },
  { sweep: 25, cd_wave_m078: 0.00432, cd_wave_m080: 0.00534, cd_wave_m082: 0.00756 },
  { sweep: 26, cd_wave_m078: 0.00398, cd_wave_m080: 0.00501, cd_wave_m082: 0.00712 },
  { sweep: 26.5, cd_wave_m078: 0.00382, cd_wave_m080: 0.00488, cd_wave_m082: 0.00695 },
  { sweep: 27, cd_wave_m078: 0.00388, cd_wave_m080: 0.00495, cd_wave_m082: 0.00702 },
  { sweep: 28, cd_wave_m078: 0.00441, cd_wave_m080: 0.00552, cd_wave_m082: 0.00768 },
  { sweep: 29, cd_wave_m078: 0.00512, cd_wave_m080: 0.00628, cd_wave_m082: 0.00852 },
  { sweep: 30, cd_wave_m078: 0.00562, cd_wave_m080: 0.00688, cd_wave_m082: 0.00921 },
];

export const CL_ALPHA_DATA = [
  { alpha: -2, cl: -0.12, cd: 0.0228 },
  { alpha: -1, cl: 0.06, cd: 0.0212 },
  { alpha: 0, cl: 0.24, cd: 0.0205 },
  { alpha: 1, cl: 0.42, cd: 0.0208 },
  { alpha: 2, cl: 0.60, cd: 0.0218 },
  { alpha: 2.8, cl: 0.50, cd: 0.0242 },
  { alpha: 3, cl: 0.78, cd: 0.0235 },
  { alpha: 4, cl: 0.96, cd: 0.0258 },
  { alpha: 5, cl: 1.14, cd: 0.0292 },
  { alpha: 6, cl: 1.30, cd: 0.0342 },
  { alpha: 7, cl: 1.42, cd: 0.0412 },
  { alpha: 8, cl: 1.48, cd: 0.0518 },
];

export const SPAN_LOADING_DATA = [
  { station: 0, cl_local: 0.42, chord: 7.82 },
  { station: 0.1, cl_local: 0.44, chord: 7.10 },
  { station: 0.2, cl_local: 0.47, chord: 6.38 },
  { station: 0.3, cl_local: 0.50, chord: 5.66 },
  { station: 0.4, cl_local: 0.52, chord: 4.94 },
  { station: 0.5, cl_local: 0.54, chord: 4.22 },
  { station: 0.6, cl_local: 0.55, chord: 3.80 },
  { station: 0.7, cl_local: 0.53, chord: 3.38 },
  { station: 0.8, cl_local: 0.48, chord: 3.10 },
  { station: 0.9, cl_local: 0.38, chord: 2.89 },
  { station: 0.95, cl_local: 0.22, chord: 2.50 },
  { station: 1.0, cl_local: 0.00, chord: 2.10 },
];
