import React from 'react';
import { Layout } from './components/Layout';
import { useAeroLoopStore } from './store';
import Dashboard from './pages/Dashboard';
import Experiments from './pages/Experiments';
import Geometry from './pages/Geometry';
import Pipeline from './pages/Pipeline';
import KnowledgeGraph from './pages/KnowledgeGraph';
import Swarm from './pages/Swarm';
import GEP from './pages/GEP';
import Wiki from './pages/Wiki';
import Settings from './pages/Settings';

const App: React.FC = () => {
  const { selectedPage } = useAeroLoopStore();

  const pages: Record<string, React.ReactNode> = {
    dashboard: <Dashboard />,
    experiments: <Experiments />,
    geometry: <Geometry />,
    pipeline: <Pipeline />,
    knowledge: <KnowledgeGraph />,
    swarm: <Swarm />,
    gep: <GEP />,
    wiki: <Wiki />,
    settings: <Settings />,
  };

  return (
    <Layout>
      {pages[selectedPage] || <Dashboard />}
    </Layout>
  );
};

export default App;
