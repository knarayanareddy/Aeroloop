import React from 'react';
import {
  LayoutDashboard, FlaskConical, Triangle, GitBranch, Network,
  Cpu, Dna, BookOpen, Settings, Play, Pause, SkipForward,
  ChevronLeft, ChevronRight, Plane, Activity
} from 'lucide-react';
import { useAeroLoopStore } from '../store';

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'experiments', label: 'Experiments', icon: FlaskConical },
  { id: 'geometry', label: 'Geometry', icon: Triangle },
  { id: 'pipeline', label: 'Pipeline', icon: GitBranch },
  { id: 'knowledge', label: 'Knowledge Graph', icon: Network },
  { id: 'swarm', label: 'Swarm', icon: Cpu },
  { id: 'gep', label: 'GEP Evolution', icon: Dna },
  { id: 'wiki', label: 'Wiki', icon: BookOpen },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export const Sidebar: React.FC = () => {
  const { selectedPage, setSelectedPage, sidebarCollapsed, toggleSidebar,
    loopState, isLoopRunning, pauseLoop, resumeLoop, runSingleExperiment,
    run } = useAeroLoopStore();

  return (
    <div className={`${sidebarCollapsed ? 'w-16' : 'w-64'} bg-slate-900 text-white flex flex-col transition-all duration-300 flex-shrink-0 min-h-screen`}>
      {/* Header */}
      <div className={`p-4 border-b border-slate-700 ${sidebarCollapsed ? 'px-2' : ''}`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
            <Plane className="w-5 h-5" />
          </div>
          {!sidebarCollapsed && (
            <div className="overflow-hidden">
              <h1 className="text-lg font-bold text-white leading-tight">AeroLoop</h1>
              <p className="text-xs text-slate-400">CFD Shape Optimizer</p>
            </div>
          )}
        </div>
      </div>

      {/* Loop Status */}
      {!sidebarCollapsed && (
        <div className="px-4 py-3 border-b border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <div className={`w-2 h-2 rounded-full ${isLoopRunning ? 'bg-green-400 animate-pulse' : 'bg-yellow-400'}`} />
            <span className="text-xs font-medium text-slate-300 uppercase tracking-wider">
              {loopState.replace(/_/g, ' ')}
            </span>
          </div>
          <div className="flex gap-1.5">
            {isLoopRunning ? (
              <button onClick={pauseLoop} className="flex items-center gap-1 px-2 py-1 bg-yellow-600 hover:bg-yellow-700 rounded text-xs font-medium transition-colors">
                <Pause className="w-3 h-3" /> Pause
              </button>
            ) : (
              <button onClick={resumeLoop} className="flex items-center gap-1 px-2 py-1 bg-green-600 hover:bg-green-700 rounded text-xs font-medium transition-colors">
                <Play className="w-3 h-3" /> Resume
              </button>
            )}
            <button onClick={runSingleExperiment} className="flex items-center gap-1 px-2 py-1 bg-blue-600 hover:bg-blue-700 rounded text-xs font-medium transition-colors">
              <SkipForward className="w-3 h-3" /> Step
            </button>
          </div>
          <div className="mt-2 text-xs text-slate-400">
            Exp #{run.total_experiments} / {run.target_experiments} • {run.kept} kept
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 py-2">
        {NAV_ITEMS.map(item => {
          const Icon = item.icon;
          const isActive = selectedPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setSelectedPage(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 transition-colors ${
                isActive
                  ? 'bg-blue-600/20 text-blue-400 border-r-2 border-blue-400'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              } ${sidebarCollapsed ? 'px-3 justify-center' : ''}`}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {!sidebarCollapsed && <span className="text-sm font-medium">{item.label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Collapse toggle */}
      <button
        onClick={toggleSidebar}
        className="p-3 border-t border-slate-700 hover:bg-slate-800 transition-colors flex items-center justify-center"
      >
        {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>
    </div>
  );
};

export const TopBar: React.FC = () => {
  const { run, isLoopRunning, currentExperimentN } = useAeroLoopStore();
  const elapsed = Date.now() - new Date(run.started_at).getTime();
  const hours = Math.floor(elapsed / 3600000);
  const minutes = Math.floor((elapsed % 3600000) / 60000);

  return (
    <div className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 flex-shrink-0">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-slate-500" />
          <span className="text-sm text-slate-600">Run: <span className="font-medium text-slate-900">{run.name}</span></span>
        </div>
        <div className="text-sm text-slate-500">
          Elapsed: <span className="font-medium text-slate-700">{hours}h {minutes}m</span>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isLoopRunning ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'}`} />
          <span className="text-sm font-medium text-slate-700">{isLoopRunning ? 'Running' : 'Paused'}</span>
        </div>
        <div className="px-3 py-1 bg-slate-100 rounded-full text-sm font-medium text-slate-700">
          #{currentExperimentN}
        </div>
      </div>
    </div>
  );
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
};
