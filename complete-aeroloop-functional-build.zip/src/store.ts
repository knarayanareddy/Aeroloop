import { create } from 'zustand';
import type {
  ExperimentRecord, ExperimentRun, SwarmNode, WingParameters,
  MetricWeights, LoopState, GEPGenome, PipelineStage, LogEntry
} from './types';
import {
  EXPERIMENTS, CURRENT_RUN, CURRENT_WING, SWARM_NODES,
  GEP_GENOMES, PIPELINE_STAGES, LIVE_LOGS, PARAMETER_REGISTRY,
} from './data/mockData';

interface AeroLoopStore {
  // Run state
  run: ExperimentRun;
  loopState: LoopState;
  currentExperimentN: number;
  isLoopRunning: boolean;

  // Geometry
  wingParams: WingParameters;
  setWingParam: (key: keyof WingParameters, value: number) => void;
  resetWingParams: () => void;

  // Experiments
  experiments: ExperimentRecord[];
  filteredExperiments: () => ExperimentRecord[];
  experimentFilter: string;
  setExperimentFilter: (filter: string) => void;
  experimentDecisionFilter: string;
  setExperimentDecisionFilter: (filter: string) => void;

  // Swarm
  swarmNodes: SwarmNode[];

  // GEP
  gepGenomes: GEPGenome[];

  // Pipeline
  pipelineStages: PipelineStage[];
  setPipelineStageStatus: (stage: number, status: PipelineStage['status']) => void;

  // Logs
  logs: LogEntry[];
  addLog: (log: Omit<LogEntry, 'id' | 'timestamp'>) => void;

  // Settings
  updateMetricWeights: (weights: MetricWeights) => void;
  updateRunConfig: (updates: Partial<ExperimentRun>) => void;

  // Run control
  startLoop: () => void;
  pauseLoop: () => void;
  resumeLoop: () => void;
  runSingleExperiment: () => void;

  // UI state
  selectedPage: string;
  setSelectedPage: (page: string) => void;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;

  // Editing
  editingExperiment: number | null;
  setEditingExperiment: (n: number | null) => void;
  updateExperimentNote: (n: number, note: string) => void;
  experimentNotes: Record<number, string>;
}

export const useAeroLoopStore = create<AeroLoopStore>((set, get) => ({
  // Run state
  run: CURRENT_RUN,
  loopState: 'LOOP_RUNNING',
  currentExperimentN: 247,
  isLoopRunning: true,

  // Geometry
  wingParams: { ...CURRENT_WING },
  setWingParam: (key, value) => {
    const def = PARAMETER_REGISTRY.find(p => p.id === key);
    if (def) {
      const clamped = Math.max(def.min, Math.min(def.max, value));
      set(state => ({
        wingParams: { ...state.wingParams, [key]: clamped }
      }));
    }
  },
  resetWingParams: () => set({ wingParams: { ...CURRENT_WING } }),

  // Experiments
  experiments: EXPERIMENTS,
  filteredExperiments: () => {
    const state = get();
    let filtered = state.experiments;
    if (state.experimentFilter) {
      const q = state.experimentFilter.toLowerCase();
      filtered = filtered.filter(e =>
        e.parameter_changed.toLowerCase().includes(q) ||
        e.reasoning.toLowerCase().includes(q) ||
        e.region.toLowerCase().includes(q) ||
        e.node_id.toLowerCase().includes(q)
      );
    }
    if (state.experimentDecisionFilter && state.experimentDecisionFilter !== 'ALL') {
      filtered = filtered.filter(e => e.decision === state.experimentDecisionFilter);
    }
    return filtered;
  },
  experimentFilter: '',
  setExperimentFilter: (filter) => set({ experimentFilter: filter }),
  experimentDecisionFilter: 'ALL',
  setExperimentDecisionFilter: (filter) => set({ experimentDecisionFilter: filter }),

  // Swarm
  swarmNodes: SWARM_NODES,

  // GEP
  gepGenomes: GEP_GENOMES,

  // Pipeline
  pipelineStages: PIPELINE_STAGES,
  setPipelineStageStatus: (stage, status) => set(state => ({
    pipelineStages: state.pipelineStages.map(s =>
      s.stage === stage ? { ...s, status } : s
    )
  })),

  // Logs
  logs: LIVE_LOGS,
  addLog: (log) => set(state => ({
    logs: [{
      ...log,
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
    }, ...state.logs].slice(0, 200)
  })),

  // Settings
  updateMetricWeights: (weights) => set(state => ({
    run: { ...state.run, metric_weights: weights }
  })),
  updateRunConfig: (updates) => set(state => ({
    run: { ...state.run, ...updates }
  })),

  // Run control
  startLoop: () => set({ loopState: 'LOOP_RUNNING', isLoopRunning: true }),
  pauseLoop: () => set({ loopState: 'LOOP_PAUSED', isLoopRunning: false }),
  resumeLoop: () => set({ loopState: 'LOOP_RUNNING', isLoopRunning: true }),
  runSingleExperiment: () => {
    const state = get();
    const newN = state.currentExperimentN + 1;
    const isKeep = Math.random() < 0.36;
    const metric = state.run.current_metric + (isKeep ? 0.001 : -0.0005);
    const newExp: ExperimentRecord = {
      experiment_n: newN,
      run_id: state.run.run_id,
      node_id: 'node-alpha-7f3a',
      timestamp: new Date().toISOString(),
      stage: 5,
      decision: isKeep ? 'KEEP' : 'REVERT',
      parameter_changed: 'twist_tip_deg',
      old_value: -3.4,
      new_value: isKeep ? -3.7 : -3.5,
      reasoning: 'Single-step experiment triggered by operator.',
      cl: 0.50 + Math.random() * 0.04,
      cd: 0.0230 + Math.random() * 0.003,
      ld: 20.5 + Math.random() * 2,
      cm: -0.07 + Math.random() * 0.03,
      cd_wave: 0.0035 + Math.random() * 0.002,
      cd_induced: 0.0082 + Math.random() * 0.001,
      cd_viscous: 0.0148 + Math.random() * 0.002,
      buffet_margin_deg: 3.0 + Math.random() * 2,
      composite_metric: metric,
      metric_delta: isKeep ? 0.001 : -0.0005,
      solve_wall_time_s: 250 + Math.random() * 150,
      mesh_cell_count: 1900000 + Math.floor(Math.random() * 300000),
      mesh_yp_avg: 0.9 + Math.random() * 0.6,
      geometry_sha256: 'sha256:' + Math.random().toString(16).substring(2, 18),
      mesh_sha256: 'sha256:' + Math.random().toString(16).substring(2, 18),
      results_sha256: 'sha256:' + Math.random().toString(16).substring(2, 18),
      strategy: 'LOCAL_SEARCH_FINE',
      genome_generation: Math.floor(newN / 50),
      region: 'PLANFORM_CORE',
    };
    set({
      experiments: [...state.experiments, newExp],
      currentExperimentN: newN,
      run: {
        ...state.run,
        total_experiments: newN,
        kept: state.run.kept + (isKeep ? 1 : 0),
        reverted: state.run.reverted + (isKeep ? 0 : 1),
        current_metric: metric,
        best_metric: Math.max(state.run.best_metric, metric),
      },
    });
    get().addLog({
      level: isKeep ? 'success' : 'info',
      source: 'KeepRevertAgent',
      message: `EXP(${newN}): ${isKeep ? 'KEEP' : 'REVERT'} — twist_tip_deg | M=${metric.toFixed(4)} Δ=${isKeep ? '+' : ''}${(isKeep ? 0.001 : -0.0005).toFixed(4)}`,
      experiment_n: newN,
      node_id: 'node-alpha-7f3a',
    });
  },

  // UI state
  selectedPage: 'dashboard',
  setSelectedPage: (page) => set({ selectedPage: page }),
  sidebarCollapsed: false,
  toggleSidebar: () => set(state => ({ sidebarCollapsed: !state.sidebarCollapsed })),

  // Editing
  editingExperiment: null,
  setEditingExperiment: (n) => set({ editingExperiment: n }),
  updateExperimentNote: (n, note) => set(state => ({
    experimentNotes: { ...state.experimentNotes, [n]: note }
  })),
  experimentNotes: {},
}));
